   <?php 
   ob_start();
   session_start();
      include 'func/connect2.php';
   if (isset ($_POST['shahr'])){
		$conecct->exec("SET CHARACTER SET UTF8");
		$re=$conecct->prepare("select * from ciity where cityid=?");
		$re->bindValue(1,$_POST['shahr']);
		$re->execute();
		echo "<select id='moasese' name='moasese' style='margin-left:50px; margin-right:50px; width:300px; height:30px; border:1px solid #bfbfbf;>";
		echo "  <option value='0'  selected='selected'>سایر</option>" ;				
		while($rows2=$re->fetch(PDO::FETCH_ASSOC)){
		echo "  <option value='".checkparam($rows2['id'])."'  selected='selected'>".checkparam($rows2['establishmentname'])."</option>" ;				
		}
		echo "</select>";
   } 
 
      if (isset ($_POST['Reshte'])){
		$conecct->exec("SET CHARACTER SET UTF8");
		$re=$conecct->prepare("select * from reshte where discipname like ?");
		$re->bindValue(1,$_POST['Reshte']);
		$re->execute();
		$rows2=$re->fetch(PDO::FETCH_ASSOC);
		
		echo "<select id='gerayesh' name='gerayesh' style='margin-left:50px; width:300px; height:30px; border:1px solid #bfbfbf;'>";
		echo "  <option value='".checkparam($rows2['skill1'])."' selected='selected'>".checkparam($rows2['skill1'])."</option>" ;				
		echo "  <option value='".checkparam($rows2['skill2'])."' selected='selected'>".checkparam($rows2['skill2'])."</option>" ;				
		echo "  <option value='".checkparam($rows2['skill3'])."' selected='selected'>".checkparam($rows2['skill3'])."</option>" ;
				
		echo "</select>";
		  
   }
   
   if (isset( $_POST['uc'])) {
if (preg_match("/\\s/",$_POST['uc'])) {
           	   echo "وجود فضای خالی ";	
       }else {
	$r=$conecct->prepare("select * from user where username=?");
	  $r->bindValue(1,$_POST['uc']);$r->execute();
	  if ($r->rowCount()>0)
	   echo "این نام کاربری قبلا ثبت شده است ";	
       }
   }
   