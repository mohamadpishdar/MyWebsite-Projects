<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>درباره ما</title>
</head>

<body >

<?php
include('head.php');
?> 
<div style="display:inline-block; width:300px; height:auto;  ackground-color:#6C9; float:left; margin:4px;"></div>


<div style=" display:inline-block; background:#CCCCCC; width:700px; height:800px; border:#999999; float:left; margin:4px;">
<p align="justify" style="margin:5px; margin-top:20px;" dir="rtl">
<font face="B Koodak" style=" font-size:24px; color:#000000; " dir="rtl">
این وبسایت فعالیت خود را در اردیبهشت ماه 96 آغاز کرده است و فعالیت های آن مبتنی بر پرسش و پاسخ های علمی در تمامی رشته های و گرایشات میباشد .هدف این وبسایت گسترش علم و  فرهنگ همکاری در نقاط مختلف ایران و سایر فارسی زبانان در سایر کشورها میباشد .این وبسایت اعضای خود را با مطرح کردن پروژه و یا موضوعی که در آن دچار ابهام هستند و نیاز به کمک و یا پیدا کردن افراد متخصص در آن ضمینه  دارند یاری میرساند و امید دارد بتواند ابزاری مفید برای تسریع  فعالیت علمی  کاربران و ارتباطات مفید بین آنها باشد.





</font>



</p>


</div>

<div style="display:inline-block; width:200px; height:auto;  ackground-color:#6C9; float:left; margin:4px;"></div>
<div style="clear:both;"></div>
<?php
include('foot.php');
?>
</body>
</html>
