<?php 
ob_start();
session_start();
include 'func/funcs.php';
include 'func/connect2.php';
 $_SESSION['adm']=0;
 $_SESSION['msg1']='';
 if (isset($_POST['captcha'])){
  if (strcmp(strtoupper($_POST['captcha']),$_SESSION['captcha'])!=0)
 {
	 $_SESSION['msg1']="در وارد کردن تصویر امنیتی دقت نمایید";
 }
 else {
	 if (isset($_POST['us'])){
		 if ($_SESSION['adm']!=1){
			 $re=$conecct->prepare("select * from admin where username=? and password=?");
			 $re->bindValue(1,$_POST['us']);
			// $passn=hash_value($_POST['pass']);
			  $re->bindValue(2,$_POST['pass']);
			  $re->execute();
$rr=$re->fetch(PDO::FETCH_ASSOC);
  $re1=$conecct->prepare("update admin set lastlogin=? where username=? and password=?");
   $re1->bindValue(1,getCurentDate());
 $re1->bindValue(2,$_POST['us']);
$re1->bindValue(3,$_POST['pass']);
$re1->execute();
 if ( $re->rowCount()== 1){
setcookie("usernameadmin", $_POST['us'], time() + (86400 * 30), "/"); // 86400 = 1 day
setcookie("passwordadmin", $_POST['pass'], time() + (86400 * 30), "/"); // 86400 = 1 day
$_SESSION['adm']=1;
 header("location:admin/dashboard.php?id=".$rr['lastname']);
 }
 else 
  $_SESSION['msg1']="لطفا در وارد  کردن نام کاربری یا کلمه ی عبور دقت کنید ";
 }
  }
    }
     }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
  <style type="text/css" media="screen">
		@import url(style.css );
		@import url(tab.css );
	body,td,th {
	color: #000;
	font-family: Tahoma, Geneva, sans-serif;
}
   </style>
<style type="text/css">
.about .about_body .text ul table tr td #form1 {
	text-align: center;
}
</style>
<title>ورود مدیر</title>
</head>
<body>
<table align="center">
<tr>
<td>
<div class="about"><div class="about_top"></div><div class="about_body">	
        	<div class="menu_title">
		  <h6>فرم ورود مدیر</h6></div><div class="text">		<ul>
          <form action="" method="post" >
            <table width="100%" border="1">
              <tr>
                <td colspan="2"><?php echo $_SESSION['msg1'] ?>&nbsp;</td>
                </tr>
              <tr>
                <td>نام کاربری :</td>
                <td><label for="us"></label>

                <input type="text" name="us" id="us" /></td>
              </tr>
              <tr>
                <td>کلمه ی عبور :</td>
                <td><input type="password" name="pass" id="pass" /></td>
              </tr>
              <tr>
                <td colspan="2"><img src="func/captcha.php"/>&nbsp;</td>
              </tr>
              <tr>
                <td colspan="2"><label for="captcha"></label>
                  <input type="text" name="captcha" id="captcha" /></td>
              </tr>
              <tr>
                <td colspan="2"><input name="Reset" type="reset" class="dddd" id="button" value="پاک کردن" />
                  <input name="button2" type="submit" class="dddd" id="button2" value="ورود" /></td>
              </tr>
            </table>
            </form>

          </ul>
		    <p align="center">&nbsp;</p>
</div></div><div class="about_bottom"></div></div>
</td></tr></table>
</body>
</html>