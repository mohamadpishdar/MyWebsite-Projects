 <div id="topNav">
		 <ul>
		 	<li>
		 		<a href="#menuProfile" class="menu"><?php echo $_GET['id'] ;?></a>
		 		
		 		<div id="menuProfile" class="menu-container menu-dropdown">
					<div class="menu-content">
						<ul class="">
							<li><a href="javascript:;">تنظیمات پروفایل</a></li>
							
							
						</ul>
					</div>
				</div>
	 		</li>
		 	<li><a href="logout.php">خروج</a></li>
		 </ul>
  </div> <!-- #topNav -->