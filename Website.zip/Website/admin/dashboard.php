 <?php
 ob_start();
session_start();
include('../func/connect2.php');
if (isset($_SESSION['adm'])==false ){  
	header('location:../admin123login.php');
}
if(isset($_COOKIE["usernameadmin"])) {
$j=$conecct->prepare("select * from admin where username=? and password=? ");
$j->bindValue(1,$_COOKIE["usernameadmin"]);
$j->bindValue(2,$_COOKIE["passwordadmin"]);
$j->execute(); 
$j1=$j->fetch(PDO::FETCH_ASSOC);
}
else 
	header('location:../admin123login.php');


?>
<!doctype html>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->

<head>
<style type="text/css">
@font-face {
  font-family: 'KoodakBold';
  src: url('fonts/KoodakBold.eot?#') format('eot'),  
       url('fonts/KoodakBold.woff') format('woff'),
       url('fonts/KoodakBold.ttf') format('truetype');
  font-style:normal;
  font-weight:normal;
}

body{

font-family: "B Koodak", "B Yekan", Courier, Fixedsys, Tahoma;
}
</style>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> <!--<![endif]-->

	<title>اعضای جدید</title>

	<meta charset="utf-8" />
	<meta name="description" content="" />
	<meta name="author" content="" />		
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
	<link rel="stylesheet" href="stylesheets/all.css" type="text/css" />
	
	<!--[if gte IE 9]>
	<link rel="stylesheet" href="stylesheets/ie9.css" type="text/css" />
	<![endif]-->
	
	<!--[if gte IE 8]>
	<link rel="stylesheet" href="stylesheets/ie8.css" type="text/css" />
	<![endif]-->
	
</head>

<body>

<div id="wrapper">
	
	<div id="header"><a href="javascript:;" id="reveal-nav">
		<span class="reveal-bar"></span>
		<span class="reveal-bar"></span>
		<span class="reveal-bar"></span>
	</a></div> <!-- #header -->
	
	<div id="search">
		<form>
			<input type="text" name="search" placeholder="Search..." id="searchField" />
		</form>		
	</div> <!-- #search -->
	
	<div id="sidebar">		
		<?php
		include 'nav.php'
		?>		
	</div> <!-- #sidebar -->
	
	<div id="content">		
		
		<div id="contentHeader">
			<h1>&nbsp;</h1>
		</div> <!-- #contentHeader -->	
		
		<div class="container">
			
			
		  <div class="grid-17"><!-- .widget --><!-- .widget -->
				
				
				
				
				
				
				
			<div class="widget widget-table">
					
					<div class="widget-header">
						<span class="icon-list"></span>
						<h3 class="icon aperture"><p align="right">اعلانات </p></h3>
					</div> <!-- .widget-header -->
					
					<div class="widget-content" align="right">
	
																								
			
<?php 
if (isset($_SESSION['payam']) && $_SESSION['payam']!=''){
echo  $_SESSION['payam'];
 $_SESSION['payam']='';
}
else 
echo 'در حال حاضر موردی وجود ندارد';
?>
						
					</div> <!-- .widget-content -->
					
			  </div> <!-- .widget --><!-- .widget -->
				
				
				
				
			</div> 
			<!-- .grid --><!-- .grid -->
			
		</div> 
		<!-- .container -->
		
	</div> <!-- #content -->
	
 <?php 
 include 'topnav.php'
 ?>
  <!-- .quickNav -->
	
	
</div> <!-- #wrapper -->

<div id="footer"></div>

<script src="javascripts/all.js"></script>

</body>

</html>
