<?php
include '../func/connect2.php';
include '../func/funcs.php';
$re1=$conecct->prepare("delete from admin where id1=?");
$re1->bindValue(1,$_GET['id1']);
$re1->execute();
header('location:peaple.php?id='.$_GET['id']);
?>