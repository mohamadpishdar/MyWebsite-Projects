

<!doctype html>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->

<head>
<style type="text/css">
@font-face {
  font-family: 'KoodakBold';
  src: url('fonts/KoodakBold.eot?#') format('eot'),  
       url('fonts/KoodakBold.woff') format('woff'),
       url('fonts/KoodakBold.ttf') format('truetype');
  font-style:normal;
  font-weight:normal;
}

body{

font-family: "B Koodak", "B Yekan", Courier, Fixedsys, Tahoma;
}
</style>
	<title>رزومه کاربر</title>

	<meta charset="utf-8" />
	<meta name="description" content="" />
	<meta name="author" content="" />		
	<meta name="viewport" content="width=device-width,initial-scale=1" />
	
		
	<link rel="stylesheet" href="stylesheets/all.css" type="text/css" />
	
	<!--[if gte IE 9]>
	<link rel="stylesheet" href="stylesheets/ie9.css" type="text/css" />
	<![endif]-->
	
	<!--[if gte IE 8]>
	<link rel="stylesheet" href="stylesheets/ie8.css" type="text/css" />
	<![endif]-->
	
</head>

<body>

<div id="wrapper">
	
	<div id="header"><a href="javascript:;" id="reveal-nav">
		<span class="reveal-bar"></span>
		<span class="reveal-bar"></span>
		<span class="reveal-bar"></span>
	</a>
  </div> <!-- #header -->
	
  <div id="search">
		<form>
			<input type="text" name="search" placeholder="Search..." id="searchField" />
		</form>		
	</div> <!-- #search -->
	
	<div id="sidebar">		
		
		<ul id="mainNav">			
			<li id="navDashboard" class="nav active">
				<span class="icon-home"></span>
				<a href="dashboard.php">کاربران جدید</a>				
			</li>
						
			<li id="navPages" class="nav">
				<span class="icon-document-alt-stroke"></span>
				<a href="javascript:;">مدیریت</a>				
				
				<ul class="subNav">
					
					<li><a href="people.php">لیست مدیران</a></li>
					
					<li><a href="form1.php">مدیر جدید</a></li>
                   
				</ul>						
				
		<li id="navTables" class="nav">
				<span class="icon-list"></span>
			
				
				<a href="">مدیریت سوالات</a>				
				
				<ul class="subNav">
					
					<li><a href="newquestion.php">سوالات جدید</a></li>
					
					<li><a href="blockequestion.php">سوالات بلاک شده</a></li>
                   
				</ul>						
				
			</li>
       
           <li id="navInterface" class="nav">
				<span class="icon-equalizer"></span>
			
				
				<a href="">مدیریت کاربران</a>				
				
				<ul class="subNav">
					
					<li><a href="user.php">لیست کاربران</a></li>
					
					<li><a href="blockuser.php">کاربران بلاک شده</a></li>
                    <li><a href="usersearch.php">جستجوی کاربر</a></li>

                   
				</ul>						
				
			</li>
			
				<li id="navType" class="nav">
				<span class="icon-mail-alt"></span>
				<a href="message.php">پیغام های دریافتی</a>	
			</li>
            
				<li id="navType" class="nav">
				<span class="icon-chat"></span>
				<a href="moshavere.php">مشاوره</a>	
			</li>
		</ul>
				
	</div> <!-- #sidebar -->
	
	<div id="content">		
		
		<div id="contentHeader"></div> <!-- #contentHeader -->	
		
		<div class="container">
				
				<div class="grid-24"><!-- .box -->
					
				  <br /><!-- .box -->
							
				
				<br /><!-- .widget -->
					
					
					
					
					
			  <div class="widget widget-table">
					
						<div class="widget-header">
							<span class="icon-list"></span>
							<h3 class="icon chart">
							  <p align="right">رزومه کاربر</p></h3>		
						</div>
					
						<div class="widget-content">
                        
						
							<table class="table table-bordered table-striped data-table">
						<thead>
							<tr>
                          
                            <th width="8%">مهارت3</th>
                            <th width="6%">مهارت2</th>
                            <th width="7%">مهارت1</th>
                            <th width="14%">موسسه</th>
								<th width="17%">رشته تحصیلی</th>
								<th width="10%">درخاست مشاوره</th>
								<th width="13%">وضعیت رزومه</th>
								<th width="10%">ایمیل</th>
							</tr>
						</thead>
<?php
include('../func/connect2.php');
?>	                        
						<tbody>
							<tr class="gradeA">
                            
					 <?php 
	  $re1=$conecct->query("select * from user where block=1 ");
	  while ($row=$re1->fetch(PDO::FETCH_ASSOC)) {
		  echo '			
								<td>'.$row['skill3'].'</td>
								<td class="center">'.$row['skill2'].'</td>
                                <td>'.$row['skill3'].'</td>
								<td>'.$row['moasese'].'</td>
								<td>'.$row['catid'].'</td>
								<td class="center">'.$row['moshavere'].'</td>
                                <td class="center">'.$row['resume'].'</td>
                                <td class="center">'.$row['email'].'</td>
							</tr>';
	  }
	  ?>
																					
						</tbody>
					</table>
						</div> <!-- .widget-content -->
					
				</div> <!-- .widget -->
					
					
								
					
				
				
				
				
				
				
				
			</div> <!-- .grid -->
			
			
				
			
			
		</div> <!-- .container -->
		
	</div> <!-- #content -->
	
	<div id="topNav">
		 <ul>
		 	<li>
		 		<a href="#menuProfile" class="menu">محمد پیشدار</a>
		 		
		 		<div id="menuProfile" class="menu-container menu-dropdown">
					<div class="menu-content">
						<ul class="">
							<li><a href="javascript:;">تنظیمات پروفایل</a></li>
							
							
					  </ul>
					</div>
				</div>
	 		</li>
		 	<li><a href="index.html">خروج</a></li>
		 </ul>
</div> <!-- #topNav --><!-- .quickNav -->
	
	
</div> <!-- #wrapper -->

<div id="footer">
	Copyright &copy; 2012, MadeByAmp Themes.
</div>


<script src="javascripts/all.js"></script>

</body>

</html>