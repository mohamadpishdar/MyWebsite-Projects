<style type="text/css">
@font-face {
  font-family: 'KoodakBold';
  src: url('fonts/KoodakBold.eot?#') format('eot'),  
       url('fonts/KoodakBold.woff') format('woff'),
       url('fonts/KoodakBold.ttf') format('truetype');
  font-style:normal;
  font-weight:normal;
}

body{

font-family: "B Koodak", "B Yekan", Courier, Fixedsys, Tahoma;
}
</style>
<ul id="mainNav">			
		
						
			<li id="navPages" class="nav">
				<span class="icon-document-alt-stroke"></span>
				<a href="javascript:;">مدیریت</a>				
				
				<ul class="subNav">
					
					<li><a href="people.php?id=<?php echo $_GET['id']; ?>">لیست مدیران</a></li>
					
					<li><a href="form1.php?id=<?php echo $_GET['id']; ?>">مدیر جدید</a></li>
                   
				</ul>						
				
		<li id="navTables" class="nav">
				<span class="icon-list"></span>
			
				
				<a href="">مدیریت سوالات</a>				
				
				<ul class="subNav">
					
					<li><a href="newquestion.php?id=<?php echo $_GET['id']; ?>">سوالات جدید</a></li>
					
                   
				</ul>						
				
			</li>
       
           <li id="navInterface" class="nav">
				<span class="icon-equalizer"></span>
			
				
				<a href="">مدیریت کاربران</a>				
				
				<ul class="subNav">
					
					<li><a href="user.php?id=<?php echo $_GET['id']; ?>">لیست کاربران</a></li>
					<li><a href="euser.php?id=<?php echo $_GET['id']; ?>">کاربران جدید منتظر تایید</a></li>
					<li><a href="blockuser.php?id=<?php echo $_GET['id']; ?>">کاربران بلاک شده</a></li>
                    <li><a href="usersearch.php?id=<?php echo $_GET['id']; ?>">جستجوی کاربر</a></li>

                   
				</ul>						
				
			</li>
			
			
			
		
				<li id="navType" class="nav">
				<span class="icon-mail-alt"></span>
				<a href="message.php?id=<?php echo $_GET['id']; ?>">پیغام های دریافتی</a>	
			</li>
            
				<li id="navType" class="nav">
				<span class="icon-chat"></span>
				<a href="moshavere.php?id=<?php echo $_GET['id']; ?>">مشاوره</a>	
			</li>
				<li id="navType" class="nav">
				<span class="icon-chat"></span>
				<a href="https://tak2.mihanhosting.net:2096/cpsess6965531399/webmail/paper_lantern/index.html?login=1&post_login=57321251558302">ایمیل</a>	
			</li>
			
			
			
		
		</ul>