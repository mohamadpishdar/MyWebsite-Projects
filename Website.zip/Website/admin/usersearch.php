

<!doctype html>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->

<head>
<style type="text/css">
@font-face {
  font-family: 'KoodakBold';
  src: url('fonts/KoodakBold.eot?#') format('eot'),  
       url('fonts/KoodakBold.woff') format('woff'),
       url('fonts/KoodakBold.ttf') format('truetype');
  font-style:normal;
  font-weight:normal;
}

body{

font-family: "B Koodak", "B Yekan", Courier, Fixedsys, Tahoma;
}
</style>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> <!--<![endif]-->

	<title>جستجوی کاربر</title>

	<meta charset="utf-8" />
	<meta name="description" content="" />
	<meta name="author" content="" />		
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
	<link rel="stylesheet" href="stylesheets/all.css" type="text/css" />
	
	<!--[if gte IE 9]>
	<link rel="stylesheet" href="stylesheets/ie9.css" type="text/css" />
	<![endif]-->
	
	<!--[if gte IE 8]>
	<link rel="stylesheet" href="stylesheets/ie8.css" type="text/css" />
	<![endif]-->
	
</head>

<body>

<div id="wrapper">
	
	<div id="header">
				
		
		<a href="javascript:;" id="reveal-nav">
			<span class="reveal-bar"></span>
			<span class="reveal-bar"></span>
			<span class="reveal-bar"></span>
		</a>
	</div> <!-- #header -->
	
	<div id="search">
		<form>
			<input type="text" name="search" placeholder="Search..." id="searchField" />
		</form>		
	</div> 
	<!-- #search -->
	
	<div id="sidebar">		
		
		<ul id="mainNav">			
			<li id="navDashboard" class="nav active">
				<span class="icon-home"></span>
				<a href="dashboard.php">کاربران جدید</a>				
			</li>
						
			<li id="navPages" class="nav">
				<span class="icon-document-alt-stroke"></span>
				<a href="javascript:;">مدیریت</a>				
				
				<ul class="subNav">
					
					<li><a href="people.php">لیست مدیران</a></li>
					
					<li><a href="form1.php">مدیر جدید</a></li>
                   
				</ul>						
				
			</li>	
			
			<li id="navTables" class="nav">
				<span class="icon-list"></span>
			
				
				<a href="">مدیریت سوالات</a>				
				
				<ul class="subNav">
					
					<li><a href="newquestion.php">سوالات جدید</a></li>
					
					<li><a href="blockequestion.php">سوالات بلاک شده</a></li>
                   
				</ul>						
				
			</li>
              <li id="navInterface" class="nav">
				<span class="icon-equalizer"></span>
			
				
				<a href="">مدیریت کاربران</a>				
				
				<ul class="subNav">
					
					<li><a href="user.php">لیست کاربران</a></li>
					
					<li><a href="blockuser.php">کاربران بلاک شده</a></li>
                    <li><a href="usersearch.php">جستجوی کاربر</a></li>

                   
				</ul>						
				
			</li>
			
				<li id="navType" class="nav">
				<span class="icon-mail-alt"></span>
				<a href="message.php">پیغام های دریافتی</a>	
			</li>
            
				<li id="navType" class="nav">
				<span class="icon-chat"></span>
				<a href="moshavere.php">مشاوره</a>	
			</li>
		</ul>
				
	</div> <!-- #sidebar -->
	
	<div id="content">		
		
		<div id="contentHeader"></div> 
		<!-- #contentHeader -->	
		
		<div class="container">
			
			
			<div class="grid-17"><!-- .widget --><!-- .widget --><!-- .widget -->	
				
				
				
				
				
				
		  <div class="widget">
					
					<div class="widget-header">
						<span class="icon-article"></span>
						<h3 class="icon compass">جستجوی کاربر</h3>					
					</div>
					
					<div class="widget-content">
						
						<form id="sampleForm" class="form uniformForm validateForm">					
						
							<fieldset>
								
								<div class="field-group">
									<label><p align="center">:نام و نام خانوادگی </p></label>
				
									<div class="field">
										<input type="text" name="fname" id="fname" size="10" class="" />			
										<label for="fname">نام خانوادگی</label>
									</div>
									
									<div class="field">
										<input type="text" name="lname" id="lname" size="12" class="" />			
										<label for="lname">نام</label>
									</div>
								</div> <!-- .field-group -->
								
								<div class="field-group">
									
									<label for="email"><p align="center">:نام کاربری</p></label>
									
									<div class="field">
										<input type="text" name="email" id="email" size="36" />
										
									</div> <!-- .field -->
									
								</div> <!-- .field-group -->
                                <div class="field-group">
									
									<label for="email"><p align="center">:ایمیل </p></label>
									
									<div class="field">
										<input type="text" name="email" id="email" size="36" />
										
									</div> <!-- .field -->
									
								</div>
                                <div class="field-group">
									
									<label for="email">
						      <p align="center">سوال:</p></label>
									
									<div class="field">
										<input type="password" name="email" id="email" size="36" />
										
									</div> <!-- .field -->
									
								</div><!-- .field-group -->
								
							  <div class="field-group control-group inline">	
									<label>
								<p align="center">گروه آموزشی: </p></label>
			
								<select name="dastresi" id="dastresi">
          <option>علوم پزشکی</option>
          <option>فنی مهندسی</option>
          <option>علوم انسانی</option>
          <option>هنر</option>
        </select>		
								</div> <!-- .field-group -->
                                
                                <div class="field-group control-group inline">	
									<label>
								<p align="center">شهر:</p></label>
			
								<select name="dastresi" id="dastresi">
          <option>همدان</option>
          <option>تهران</option>
          <option>تبریز</option>
          <option>قزوین</option>
        </select>		
								</div>
                                				<div class="field-group control-group inline">	
									<label>
									<p align="center">:رشته </p></label>
			
								<select name="dastresi" id="dastresi">
          <option>فناوری</option>
          <option>برق2</option>
          <option>مکانیک</option>
           <option>حسابداری</option>
        </select>		
								</div><!-- .field-group -->
							</fieldset>
							
							<div class="actions">
								<button type="submit" class="btn btn-primary">جستجو</button>
							</div>
						
						</form>
						
						
						
					</div> <!-- .widget-content -->
					
			  </div> <!-- .widget -->
				
				
				
				
			</div> <!-- .grid --><!-- .grid -->
			
	  </div> <!-- .container -->
		
	</div> <!-- #content -->
	
	 <?php 
 include 'topnav.php'
 ?>
	
	<div id="quickNav">
		<ul>
			<li class="quickNavMail">
				<a href="#menuAmpersand" class="menu"><span class="icon-book"></span></a>		
				
				<span class="alert">3</span>		

				<div id="menuAmpersand" class="menu-container quickNavConfirm">
					<div class="menu-content cf">							
						
						<div class="qnc qnc_confirm">
							
							<h3>Confirm</h3>
					
							<div class="qnc_item">
								<div class="qnc_content">
									<span class="qnc_title">Confirm #1</span>
									<span class="qnc_preview">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do.</span>
									<span class="qnc_time">3 hours ago</span>
								</div> <!-- .qnc_content --></div>

	
</div> <!-- #wrapper -->

<div id="footer"></div>

<script src="javascripts/all.js"></script>

</body>

</html>