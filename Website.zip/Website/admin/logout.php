<?php 
session_start();
ob_start();
$_SESSION['adm']=0;
if (isset($_COOKIE['usernameadmin'])) {
    unset($_COOKIE['usernameadmin']);
    setcookie('usernameadmin', null, -1, '/');
}
header('location:../index.php');
?>