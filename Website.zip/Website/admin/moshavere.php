 <?php
 ob_start();
session_start();
include('../func/connect2.php');
if (isset($_SESSION['adm'])==false ){  
	header('location:../admin123login.php');
}
if(isset($_COOKIE["usernameadmin"])) {
$j=$conecct->prepare("select * from admin where username=? and password=? ");
$j->bindValue(1,$_COOKIE["usernameadmin"]);
$j->bindValue(2,$_COOKIE["passwordadmin"]);
$j->execute(); 
$j1=$j->fetch(PDO::FETCH_ASSOC);
}
else 
	header('location:../admin123login.php');

if ($j1['dastresi']<3){
?>
<!doctype html>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->

<head>
<style type="text/css">
@font-face {
  font-family: 'KoodakBold';
  src: url('fonts/KoodakBold.eot?#') format('eot'),  
       url('fonts/KoodakBold.woff') format('woff'),
       url('fonts/KoodakBold.ttf') format('truetype');
  font-style:normal;
  font-weight:normal;
}

body{

font-family: "B Koodak", "B Yekan", Courier, Fixedsys, Tahoma;
}
</style>
	<title>لیست مشاوره</title>

	<meta charset="utf-8" />
	<meta name="description" content="" />
	<meta name="author" content="" />		
	<meta name="viewport" content="width=device-width,initial-scale=1" />
	
		
	<link rel="stylesheet" href="stylesheets/all.css" type="text/css" />
	
	<!--[if gte IE 9]>
	<link rel="stylesheet" href="stylesheets/ie9.css" type="text/css" />
	<![endif]-->
	
	<!--[if gte IE 8]>
	<link rel="stylesheet" href="stylesheets/ie8.css" type="text/css" />
	<![endif]-->
	
</head>

<body>

<div id="wrapper">
	
	<div id="header"><a href="javascript:;" id="reveal-nav">
		<span class="reveal-bar"></span>
		<span class="reveal-bar"></span>
		<span class="reveal-bar"></span>
	</a>
  </div> <!-- #header -->
	
  <div id="search">
		<form>
			<input type="text" name="search" placeholder="Search..." id="searchField" />
		</form>		
	</div> <!-- #search -->
	
	<div id="sidebar">		
		
		<?php
		include 'nav.php'
		?>
				
	</div> <!-- #sidebar -->
	
	<div id="content">		
		
		<div id="contentHeader"></div> <!-- #contentHeader -->	
		
		<div class="container">
				
				<div class="grid-24"><!-- .box -->
					
				  <br /><!-- .box -->
							
				
				<br /><!-- .widget -->
					
					
					
					
					
			  <div class="widget widget-table">
					
						<div class="widget-header">
							<span class="icon-list"></span>
							<h3 class="icon chart"><p align="right">لیست مشاوره ها</p></h3>		
						</div>
					
						<div class="widget-content">
							
							<table class="table table-bordered table-striped data-table">
						<thead>
							<tr>
                            
                            <th width="14%">حذف</th>
								<th width="17%">مبلغ مشاوره</th>
								<th width="10%">تاریخ</th>
								<th width="13%">مشاوره</th>
								<th width="10%">نام کاربری</th>
							</tr>
						</thead>

    <?php 
	$conecct->exec("SET CHARACTER SET UTF8");
	  $re1=$conecct->prepare("select * from moshavere");
      $re1->execute();;
	  while ($row=$re1->fetch(PDO::FETCH_ASSOC)) {
		 $re2=$conecct->prepare("select * from user where userid=?");
		 $re2->bindValue(1,$row['userid']);
      $re2->execute();
	  $row2=$re2->fetch(PDO::FETCH_ASSOC);	 
	   echo '              
						<tbody>
							<tr class="gradeA">
								<td><a href="delmoshavere.php?id1='.$row["d"].'&email='.$row2["email"].'&id='.$_GET['id'].'&question='.$row['matn'].'">حذف</a></td>
								<td>'.$row['hazine'].'</td>
								<td>'.$row['date'].'</td>
                                <td>'.$row['matn'].'</td>
								<td>'.$row2['username'].'</td>
	 				
							
							</tr>';}
                            ?>
																					
						</tbody>
					</table>
						</div> <!-- .widget-content -->
					
				</div> <!-- .widget -->
					
					
								
					
				
				
				
				
				
				
				
			</div> <!-- .grid -->
			
			
				
			
			
		</div> <!-- .container -->
		
	</div> <!-- #content -->
	
 <?php 
 include 'topnav.php'
 ?>
	
	
</div> <!-- #wrapper -->

<div id="footer">

</div>


<script src="javascripts/all.js"></script>

</body>

</html>
<?php 
}else
{$_SESSION['payam']="شما اجازه دسترسی به این قسمت را ندارید";
header('location:dashboard.php?id='.$_GET['id']);
}

?>