 <?php
 ob_start();
session_start();
include('../func/connect2.php');
if (isset($_SESSION['adm'])==false ){  
	header('location:../admin123login.php');
}
if(isset($_COOKIE["usernameadmin"])) {
$j=$conecct->prepare("select * from admin where username=? and password=? ");
$j->bindValue(1,$_COOKIE["usernameadmin"]);
$j->bindValue(2,$_COOKIE["passwordadmin"]);
$j->execute(); 
$j1=$j->fetch(PDO::FETCH_ASSOC);
}
else 
	header('location:../admin123login.php');

if ($j1['dastresi']<3){
?>

<!doctype html>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> <!--<![endif]-->

	<title>سوالات کاربر</title>

	<meta charset="utf-8" />
	<meta name="description" content="" />
	<meta name="author" content="" />		
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
	<link rel="stylesheet" href="stylesheets/all.css" type="text/css" />
	
	<!--[if gte IE 9]>
	<link rel="stylesheet" href="stylesheets/ie9.css" type="text/css" />
	<![endif]-->
	
	<!--[if gte IE 8]>
	<link rel="stylesheet" href="stylesheets/ie8.css" type="text/css" />
	<![endif]-->
	
</head>

<body>

<div id="wrapper">
	
	<div id="header"><a href="javascript:;" id="reveal-nav">
		<span class="reveal-bar"></span>
		<span class="reveal-bar"></span>
		<span class="reveal-bar"></span>
	</a></div> <!-- #header -->
	
	<div id="search">
		<form>
			<input type="text" name="search" placeholder="Search..." id="searchField" />
		</form>		
	</div> <!-- #search -->
	
	<div id="sidebar">		
		
		<?php
		include 'nav.php'
		?>
				
	</div> <!-- #sidebar -->
	
	<div id="content">		
		
		<div id="contentHeader">
			<h1>&nbsp;</h1>
		</div> <!-- #contentHeader -->	
		
		<div class="container">
			
			
		  <div class="grid-17"><!-- .widget --><!-- .widget -->
				
				
				
				
				
				
				
			<div class="widget widget-table" >
					
					<div class="widget-header">
						<span class="icon-list"></span>
						<h3 class="icon aperture"><p align="right">لیست سوالات جدید</p></h3>
					</div> <!-- .widget-header -->
					
					<div class="widget-content" align="right">
                 
						<table width="106%" class="table table-bordered table-striped data-table">
						<thead>
							<tr>
								<th width="10%">بلاک و  ایمیل</th>								
                                <th width="31%">متن سوال</th>
								<th width="13%">نام کاربری</th>
							
							</tr>
						</thead>
 
	                       
						<tbody>
                          <?php 
						  $conecct->exec("SET CHARACTER SET UTF8");
	  $re1=$conecct->prepare("select * from subject where userid=?");
	  $re1->bindValue(1,$_GET['id2']);
	  $re1->execute();
	  while ($row=$re1->fetch(PDO::FETCH_ASSOC)) {
		    $re2=$conecct->prepare("select * from user where userid=?");
			$re2->bindValue(1,$row['userid']);
            $re2->execute();
			$row2=$re2->fetch(PDO::FETCH_ASSOC);
		  echo ' 
							<tr class="gradeA">
								<td><a href="delquestion.php?id2='.$row['id'].'&id='.$row["userid"].'&question='.$row['question'].'">حذف</a></td>
                              <td>'.$row['question'].'</td>
								<td>'.$row2['username'].'</td>
							<td class="center"></td>
							</tr>';}
                            ?>
																						
						</tbody>
					</table>	

						
					</div> <!-- .widget-content -->
					
			  </div> <!-- .widget --><!-- .widget -->
				
				
				
				
			</div> 
			<!-- .grid --><!-- .grid -->
			
		</div> 
		<!-- .container -->
		
	</div> <!-- #content -->
	
 <?php 
 include 'topnav.php'
 ?>
	
	
</div> <!-- #wrapper -->

<div id="footer"></div>

<script src="javascripts/all.js"></script>

</body>

</html>
<?php 
}else{
$_SESSION['payam']="شما اجازه دسترسی به این قسمت را ندارید";
header('location:dashboard.php?id='.$_GET['id']);

}
?>