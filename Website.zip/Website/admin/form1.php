 <?php
ob_start();
session_start();
include('../func/connect2.php');
if (isset($_SESSION['adm'])==false ){  
	header('location:../admin123login.php');
}
if(isset($_COOKIE["usernameadmin"])) {
$j=$conecct->prepare("select * from admin where username=? and password=? ");
$j->bindValue(1,$_COOKIE["usernameadmin"]);
$j->bindValue(2,$_COOKIE["passwordadmin"]);
$j->execute(); 
$j1=$j->fetch(PDO::FETCH_ASSOC);
}
else 
	header('location:../admin123login.php');

if ($j1['dastresi']<1){
if ( isset($_POST['pass1']) && $_POST['pass1']!=''){

$payam=true;
$re=$conecct->prepare("INSERT INTO admin (`username`, `password`, `lastlogin`,`dastresi` ,`firstname`,`lastname`,`semat` , `contact`) VALUES (?,?,0,?,?,?,?,?)");
$re->bindValue(1,$_POST['user']);$re->bindValue(2,$_POST['pass1'] );$re->bindValue(3,$_POST['sath']);
$re->bindValue(4,$_POST['firstname']);$re->bindValue(5,$_POST['lastname']);
$re->bindValue(6,$_POST['semat']);$re->bindValue(7,$_POST['number']);
$re->execute();
	}
	

?>

<!doctype html>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->

<head>
<style type="text/css">
@font-face {
  font-family: 'KoodakBold';
  src: url('fonts/KoodakBold.eot?#') format('eot'),  
       url('fonts/KoodakBold.woff') format('woff'),
       url('fonts/KoodakBold.ttf') format('truetype');
  font-style:normal;
  font-weight:normal;
}

body{

font-family: "B Koodak", "B Yekan", Courier, Fixedsys, Tahoma;
}
</style>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> <!--<![endif]-->

	<title>مدیر جدید</title>
    
    <script language="javascript" >   
   function check ( x1,x2 ,x3,x4,x5,x6 ) 
{
if (x1=='' ){
alert("لطفا  نام کاربری را وارد کنید");
document.getElementById('user').focus();
return false ;
}	
	
if (x2=='' ){
alert("لطفا  کلمه ی عبور را وارد کنید");
document.getElementById('pass1').focus();
return false ;
}
if (x3!=x2 ){
alert("کلمه های عبور یکسان نیستند");
document.getElementById('pass1').focus();

return false ;
}
if (x4=='' ){
alert("لطفا شماره تماس را وارد نمایید");
document.getElementById('number').focus();

return false ;
}
if (x5=='' ){
alert("لطفا سمت را وارد نمایید");
document.getElementById('semat').focus();

return false ;
}
if (x6==''){
alert("لطفا نام خانوادگی را وارد نمایید");
document.getElementById('tasvir').focus();

return false ;
}
else 
return true ;

}
</script>
	<meta charset="utf-8" />
	<meta name="description" content="" />
	<meta name="author" content="" />		
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
	<link rel="stylesheet" href="stylesheets/all.css" type="text/css" />
	
	<!--[if gte IE 9]>
	<link rel="stylesheet" href="stylesheets/ie9.css" type="text/css" />
	<![endif]-->
	
	<!--[if gte IE 8]>
	<link rel="stylesheet" href="stylesheets/ie8.css" type="text/css" />
	<![endif]-->
	
</head>

<body>

<div id="wrapper">
	
	<div id="header">
				
		
		<a href="javascript:;" id="reveal-nav">
			<span class="reveal-bar"></span>
			<span class="reveal-bar"></span>
			<span class="reveal-bar"></span>
		</a>
	</div> <!-- #header -->
	
	

	
	<div id="sidebar">		
		
		<?php 
		include 'nav.php';
		?>
				
	</div> <!-- #sidebar -->
	
	<div id="content">		
		
		<div id="contentHeader"></div> 
		<!-- #contentHeader -->	
		
		<div class="container">
			
			
			<div class="grid-17"><!-- .widget --><!-- .widget --><!-- .widget -->	
				
				
				
				
				
				
		  <div class="widget">
					
					<div class="widget-header">
						<span class="icon-article"></span>
						<h3 class="icon compass">مدیر جدید</h3>					
					</div>
					
					<div class="widget-content">
						
						<form id="sampleForm" class="form uniformForm validateForm" action="" method="post" onSubmit="return check2(username.value ,pass1.value,pass2.value,number.value,semat.value,lastname.value)">>					
						<?php// if ($payam==true)echo "مدیر جدید با موفقیت ثبت گردید"; ?>
							<fieldset>
								
								<div class="field-group">
									
									<label for="name"><p align="center">:نام </p></label>
									
									<div class="field">
										<input type="text" name="firstname" id="firstname" size="36" />
										
									</div> <!-- .field -->
                                    <label for="name"><p align="center">: نام خانوادگی</p></label>
									
									<div class="field">
										<input type="text" name="lastname" id="lastname" size="36" />
										
									</div>
									
								</div> <!-- .field-group -->
								
								<div class="field-group">
									
									<label for="email"><p align="center">:نام کاربری</p></label>
									
									<div class="field">
										<input type="text" name="user" id="user" size="36" />
										
									</div> <!-- .field -->
									
								</div> <!-- .field-group -->
                                <div class="field-group">
									
									<label for="email"><p align="center">:رمز ورود </p></label>
									
									<div class="field">
										<input type="password" name="pass1" id="pass1" size="36" />
										
									</div> <!-- .field -->
									
								</div>
                                <div class="field-group">
									
									<p align="center">:تکرار رمز ورود </p></label>
									
									<div class="field">
										<input type="password" name="pass2" id="pass2" size="36" />
										
									</div> <!-- .field -->
									
								</div>
				
								<div class="field-group">
									<label><p align="center">:شماره تماس </p></label>
				
								<div class="field">
										<input type="text" name="number" id="number" size="36" />
										
								  </div>
								</div> <!-- .field-group -->
								
								<div class="field-group control-group inline">	
									<label><p align="center">:سطح دسترسی </p></label>
			
								<select name="sath" id="sath">
          <option>0</option>
          <option>1</option>
          <option>2</option>
        </select>		
								</div> <!-- .field-group -->
                                				<div class="field-group control-group inline">	
									<label><p align="center">:سمت </p></label>
			<div class="field">
										<input type="text" name="semat" id="semat" size="36" />
										
								  </div>		
								</div>
								
								
				
					
								</div> <!-- .field-group -->
							</fieldset>
							
							<div class="actions">
								<button type="submit" class="btn btn-primary" name="button" id="button">ثبت</button>
							</div>
						
						</form>
						
						
						
					</div> <!-- .widget-content -->
					
			  </div> <!-- .widget -->
				
				
				
				
			</div> <!-- .grid --><!-- .grid -->
			
	  </div> <!-- .container -->
		
	</div> <!-- #content -->
	
		<div id="topNav">
		 <ul>
		 	<li>
		 		<a href="#menuProfile" class="menu">محمد پیشدار</a>
		 		
		 		<div id="menuProfile" class="menu-container menu-dropdown">
					<div class="menu-content">
						<ul class="">
							<li><a href="javascript:;">تنظیمات پروفایل</a></li>
							
							
						</ul>
					</div>
				</div>
	 		</li>
		 	<li><a href="index.html">خروج</a></li>
		 </ul>
</div> <!-- #topNav --
	
	<div id="quickNav">
		<ul>
			<li class="quickNavMail">
				<a href="#menuAmpersand" class="menu"><span class="icon-book"></span></a>		
				
				<span class="alert">3</span>		

				<div id="menuAmpersand" class="menu-container quickNavConfirm">
					<div class="menu-content cf">							
						
						<div class="qnc qnc_confirm">
							
							<h3>Confirm</h3>
					
							<div class="qnc_item">
								<div class="qnc_content">
									<span class="qnc_title">Confirm #1</span>
									<span class="qnc_preview">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do.</span>
									<span class="qnc_time">3 hours ago</span>
								</div> <!-- .qnc_content --></div>

	
</div> <!-- #wrapper -->

<div id="footer"></div>

<script src="javascripts/all.js"></script>

</body>

</html>
<?php 
}else{
$_SESSION['payam']="شما اجازه دسترسی به این قسمت را ندارید";
header('location:dashboard.php?id='.$_GET['id']);
}

?>