

<!doctype html>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->

<head>
<style type="text/css">
@font-face {
  font-family: 'KoodakBold';
  src: url('fonts/KoodakBold.eot?#') format('eot'),  
       url('fonts/KoodakBold.woff') format('woff'),
       url('fonts/KoodakBold.ttf') format('truetype');
  font-style:normal;
  font-weight:normal;
}

body{

font-family: "B Koodak", "B Yekan", Courier, Fixedsys, Tahoma;
}
</style>
	<title>رزومه کاربر</title>

	<meta charset="utf-8" />
	<meta name="description" content="" />
	<meta name="author" content="" />		
	<meta name="viewport" content="width=device-width,initial-scale=1" />
	
		
	<link rel="stylesheet" href="stylesheets/all.css" type="text/css" />
	
	<!--[if gte IE 9]>
	<link rel="stylesheet" href="stylesheets/ie9.css" type="text/css" />
	<![endif]-->
	
	<!--[if gte IE 8]>
	<link rel="stylesheet" href="stylesheets/ie8.css" type="text/css" />
	<![endif]-->
	
</head>

<body>

<div id="wrapper">
	
	<div id="header"><a href="javascript:;" id="reveal-nav">
		<span class="reveal-bar"></span>
		<span class="reveal-bar"></span>
		<span class="reveal-bar"></span>
	</a>
  </div> <!-- #header -->
	
  <div id="search">
		<form>
			<input type="text" name="search" placeholder="Search..." id="searchField" />
		</form>		
	</div> <!-- #search -->
	
	<div id="sidebar">		
		
		<?php 
		include 'nav.php';
		?>
				
	</div> <!-- #sidebar -->
	
	<div id="content">		
		
		<div id="contentHeader"></div> <!-- #contentHeader -->	
		
		<div class="container">
				
				<div class="grid-24"><!-- .box -->
					
				  <br /><!-- .box -->
							
				
				<br /><!-- .widget -->
					
					
					
					
					
			  <div class="widget widget-table">
					
						<div class="widget-header">
							<span class="icon-list"></span>
							<h3 class="icon chart">
							  <p align="right">رزومه کاربر</p></h3>		
						</div>
					
						<div class="widget-content">
                        
						
							<table class="table table-bordered table-striped data-table">
						<thead>
							<tr>
                            <th width="8%">مهارت 3</th>
                            <th width="8%">مهارت 2</th>
                          <th width="8%">مهارت 1</th>
                            <th width="8%">مقاله</th>
                            <th width="6%">پژوهش</th>
                            <th width="14%">سابقه کار</th>
                            <th width="7%">آدرس</th>
								<th width="17%">رشته تحصیلی</th>
								<th width="13%">گرایش</th>
								<th width="10%">مهارت</th>
							</tr>
						</thead>
<?php
include('../func/connect2.php');
?>	                        
						<tbody>
							<tr class="gradeA">
                            
<?php 

$re1=$conecct->prepare("select * from resume where userid=?");
$re1->bindValue(1,$_GET['id']);
$re1->execute();	
         while ($row=$re1->fetch(PDO::FETCH_ASSOC)) {
$conecct->exec("SET CHARACTER SET UTF8");
$re2=$conecct->prepare("select * from user where userid=?");
$re2->bindValue(1,$_GET['id']);
$re2->execute();
$row2=$re2->fetch(PDO::FETCH_ASSOC);

		  echo '	
		                        <td>'.$row2['skill3'].'</td>
		  		                <td>'.$row2['skill2'].'</td>
		  		             	<td>'.$row2['skill1'].'</td>
								<td>'.$row['maghale'].'</td>
                                <td>'.$row['pajuhesh'].'</td>
								<td>'.$row['sabeghekar'].'</td>
								<td>'.$row['address'].'</td>
								<td class="center">'.$row['reshte'].'</td>
                                <td class="center">'.$row['grayesh'].'</td>
                                <td class="center">'.$row['maharat'].'</td>
							</tr>';
	  }
	  ?>
																					
						</tbody>
					</table>
						</div> <!-- .widget-content -->
					
				</div> <!-- .widget -->
					
					
								
					
				
				
				
				
				
				
				
			</div> <!-- .grid -->
			
			
				
			
			
		</div> <!-- .container -->
		
	</div> <!-- #content -->
	
	<div id="topNav">
		 <ul>
		 	<li>
		 		<a href="#menuProfile" class="menu">محمد پیشدار</a>
		 		
		 		<div id="menuProfile" class="menu-container menu-dropdown">
					<div class="menu-content">
						<ul class="">
							<li><a href="javascript:;">تنظیمات پروفایل</a></li>
							
							
					  </ul>
					</div>
				</div>
	 		</li>
		 	<li><a href="index.html">خروج</a></li>
		 </ul>
</div> <!-- #topNav --><!-- .quickNav -->
	
	
</div> <!-- #wrapper -->

<div id="footer">
	Copyright &copy; 2012, MadeByAmp Themes.
</div>


<script src="javascripts/all.js"></script>

</body>

</html>