<?php
include '../func/connect2.php';
include '../func/funcs.php';
$re1=$conecct->prepare("update user set block=1 where userid=?");
$re1->bindValue(1,$_GET['id2']);
$re1->execute();
$re2=$conecct->prepare("INSERT INTO message (`useridsrc` ,`useriddest` ,`time` ,`text` ,`seen`) VALUES (0,?,?,?,0)");
$re2->bindValue(1,$_GET['id2']);
$re2->bindValue(2,getCurentDate());
$re2->bindValue(3,"شما در اطلاعات کاربری خود قوانین را رعایت نکرده اید و حساب شما به حالت تعلیق در آمده است لطفا نسبت به بروز رسانی اطلاعات کاربری خود اقدام نموده و به آدرس Official@ask-question.ir یک ایمیل با عنوان فعال سازی مجدد حساب کاربری خود ارسال نمایید");
$re2->execute();
header('location:user.php?id='.$_GET['id']);
?>