<?php
include '../func/connect2.php';
include '../func/funcs.php';
$re1=$conecct->prepare("delete from subject where id=?");
$re1->bindValue(1,$_GET['id2']);
$re1->execute();
$re2=$conecct->prepare("INSERT INTO message (`useridsrc` ,`useriddest` ,`time` ,`text` ,`seen`) VALUES (0,?,?,?,0)");
$re2->bindValue(1,$_GET['id2']);
$re2->bindValue(2,getCurentDate());
$re2->bindValue(3,"اپراتو بازبینی سوال شما ".$_GET['question']."را به دلیل عدم رعایت قوانین کاربری حذف کرده است لطفا سوال خود را اصلاح نمایید");
$re2->execute();
header('location:newquestion.php?id='.$_GET['id']);
?>