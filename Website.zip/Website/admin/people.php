 <?php
 ob_start();
session_start();
include('../func/connect2.php');
if (isset($_SESSION['adm'])==false ){  
	header('location:../admin123login.php');
}
if(isset($_COOKIE["usernameadmin"])) {
$j=$conecct->prepare("select * from admin where username=? and password=? ");
$j->bindValue(1,$_COOKIE["usernameadmin"]);
$j->bindValue(2,$_COOKIE["passwordadmin"]);
$j->execute(); 
$j1=$j->fetch(PDO::FETCH_ASSOC);
}
else 
	header('location:../admin123login.php');

if ($j1['dastresi']<1){
?>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->

<head>

	<title>لیست اعضا</title>

	<meta charset="utf-8" />
	<meta name="description" content="" />
	<meta name="author" content="" />		
	<meta name="viewport" content="width=device-width,initial-scale=1" />
	
		
	<link rel="stylesheet" href="stylesheets/all.css" type="text/css" />
	
	<!--[if gte IE 9]>
	<link rel="stylesheet" href="stylesheets/ie9.css" type="text/css" />
	<![endif]-->
	
	<!--[if gte IE 8]>
	<link rel="stylesheet" href="stylesheets/ie8.css" type="text/css" />
	<![endif]-->
<style type="text/css">
@font-face {
  font-family: 'KoodakBold';
  src: url('fonts/KoodakBold.eot?#') format('eot'),  
       url('fonts/KoodakBold.woff') format('woff'),
       url('fonts/KoodakBold.ttf') format('truetype');
  font-style:normal;
  font-weight:normal;
}

body{

font-family: "B Koodak", "B Yekan", Courier, Fixedsys, Tahoma;
}
</style>	
</head>

<body>

<div id="wrapper">
	
	<div id="header"><a href="javascript:;" id="reveal-nav">
		<span class="reveal-bar"></span>
		<span class="reveal-bar"></span>
		<span class="reveal-bar"></span>
	</a>
  </div> <!-- #header -->
	
  <div id="search">
		<form>
			<input type="text" name="search" placeholder="Search..." id="searchField" />
		</form>		
	</div> <!-- #search -->
	
	<div id="sidebar">		
		
		<?php
		include 'nav.php'
		?>
				
	</div> <!-- #sidebar -->
	
	<div id="content">		
		
		<div id="contentHeader"></div> <!-- #contentHeader -->	
		
		<div class="container">
				
				<div class="grid-24"><!-- .box -->
					
				  <br /><!-- .box -->
							
				
				<br /><!-- .widget -->
					
					
					
					
					
			  <div class="widget widget-table">
					
						<div class="widget-header">
							<span class="icon-list"></span>
							<h3 class="icon chart"><p align="right">لیست کاربران</p></h3>		
						</div>
					
						<div class="widget-content">
							
							<table class="table table-bordered table-striped data-table">
						<thead>
							<tr>
                            <th width="7%">حذف</th>
                            <th width="8%">آخرین ورود</th>                  
                            <th width="7%">سمت</th>
                            <th width="14%">تماس</th>
								<th width="17%">سطح دسترسی</th>
								<th width="10%">نام کاربری</th>
								<th width="13%">نام خانوادگی</th>
								<th width="10%">نام</th>
							</tr>
						</thead>

    <?php 
	  $re1=$conecct->query("select * from admin ");
	  while ($row=$re1->fetch(PDO::FETCH_ASSOC)) {
		  echo '              
						<tbody>
							<tr class="gradeA">
								<td><a href="deladmin.php?id='.$_GET['id'].'&id1='.$row['id1'].'">حذف</a></td>
								<td>'.$row['lastlogin'].'</td>
                                <td>'.$row['semat'].'</td>
								<td>'.$row['contact'].'</td>
								<td>'.$row['dastresi'].'</td>
								<td class="center">'.$row['username'].'</td>
                                <td class="center">'.$row['lastname'].'</td>
                                <td class="center">'.$row['firstname'].'</td>
							</tr>';}
                            ?>
																					
						</tbody>
					</table>
						</div> <!-- .widget-content -->
					
				</div> <!-- .widget -->
					
					
								
					
				
				
				
				
				
				
				
			</div> <!-- .grid -->
			
			
				
			
			
		</div> <!-- .container -->
		
	</div> <!-- #content -->
	
	 <?php 
 include 'topnav.php'
 ?>
	
	
</div> <!-- #wrapper -->

<div id="footer">

</div>


<script src="javascripts/all.js"></script>

</body>

</html>

<?php 
}else{
$_SESSION['payam']="شما اجازه دسترسی به این قسمت را ندارید";
header('location:dashboard.php?id='.$_GET['id']);
}
 

?>