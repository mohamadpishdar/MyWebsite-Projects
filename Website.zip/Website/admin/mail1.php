<?php 
include "../PhpMailer/class.phpmailer.php";
include "../PhpMailer/class.smtp.php";
include "../PhpMailer/PHPMailerAutoload.php";
$mail = new PHPMailer(); // create a new object
$mail->IsSMTP(); // enable SMTP
$mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
$mail->SMTPAuth = true; // authentication enabled
$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail
$mail->Host = "tak2.mihanhosting.net";
$mail->Port = 465; // or 587
$mail->IsHTML(true);
$mail->Username = "official@ask-question.ir";
$mail->Password = "mahsayadegary1368";
$mail->CharSet="UTF-8";
$mail->SetFrom("official@ask-question.ir","مدیر پشتیبانی سایت");
$mail->Subject = "نظر جدید در رابطه با موضوع شما ";
$mail->Body = "<html><body> <br> پست شما از نظر اپراتور بازبینی به علت عدم رعایت قوانین کاربری حرف گردید لطفا پست خود را با رعایت قوانین مجددا ارسال نمایید\n  : ".$GET['question']."</br></body></html>";
$mail->AddAddress($_GET['email']);
$mail->Send();
header('location:moshavere.php?id='.$_GET['id']);


?>