<?php
include '../func/connect2.php';
$re1=$conecct->prepare("update user set block=0 where userid=?");
$re1->bindValue(1,$_GET['id1']);
$re1->execute();
header('location:euser.php?id='.$_GET['id']);
?>