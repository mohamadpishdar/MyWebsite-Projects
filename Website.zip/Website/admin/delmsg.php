<?php
include '../func/connect2.php';
$re1=$conecct->prepare("delete from tamas where id=?");
$re1->bindValue(1,$_GET['id']);
$re1->execute();
header('location:message.php?id='.$_GET['id1']);
?>