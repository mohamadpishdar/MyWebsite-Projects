<?php 
/**
 * MyBB 1.8 Persian Language Pack
 * Copyright 2014 My-BB.Ir Group & iora.ir, All Rights Reserved
 * 
 * Translate By: iora.ir & My-BB.Ir
 */

$l['php_info'] = "اطلاعات پی‌اچ‌پی";
$l['browser_no_iframe_support'] = "مرورگر شما از آی‌فریم(iFrames) پشتیبانی نمی‌کند.";