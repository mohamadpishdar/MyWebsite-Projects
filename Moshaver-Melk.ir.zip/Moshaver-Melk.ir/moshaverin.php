﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
﻿<?php 
include 'func/connect2.php';
?>
<head>
 <script src="sliderengine/jquery.js"></script>
    <script src="sliderengine/amazingslider.js"></script>
    <link rel="stylesheet" type="text/css" href="sliderengine/amazingslider-1.css">
    <script src="sliderengine/initslider-1.js"></script>

<title>مشاورین املاک ثبت شده در سایت</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
 <style type="text/css" media="screen">
		@import url(style.css );
		@import url(tab.css );
	body,td,th {
	color: #000;
	font-family: Tahoma, Geneva, sans-serif;	font-size: 12px;
}
   .middle .topmenu .content .content_bg .post .post_body table tr td p {
	text-align: right;
	font-family: Tahoma, Geneva, sans-serif;
				font-size: 12px;
}
 .middle .topmenu .content .content_bg .post .post_body table tr td {
	text-align: right;
	font-family: Tahoma, Geneva, sans-serif;
				font-size: 12px;


}
 a {
	text-align: right;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 13px;
}
 h1,h2,h3,h4,h5,h6 {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
}
 </style>
<script src="js/jcarousellite_1.0.1c4.js" type="text/javascript"></script>
<script type="text/javascript" src="js/01.js"></script>
<script type="text/javascript" src="js/02.js"></script>
<script type="text/javascript" src="js/03.js"></script>
<script type="text/javascript" src="js/general.js"></script>
<script type="text/javascript">
function getElementsByClassName(className, tag, elm){
	var testClass = new RegExp("(^|\\s)" + className + "(\\s|$)");
	var tag = tag || "*";
	var elm = elm || document;
	var elements = (tag == "*" && elm.all)? elm.all : elm.getElementsByTagName(tag);
	var returnElements = [];
	var current;
	var length = elements.length;
	for(var i=0; i<length; i++){
		current = elements[i];
		if(testClass.test(current.className)){
			returnElements.push(current);
		}
	}
	return returnElements;
}

function addClassName(elm, className){
    var currentClass = elm.className;
    if(!new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i").test(currentClass)){
        elm.className = currentClass + ((currentClass.length > 0)? " " : "") + className;
    }
    return elm.className;
}

function removeClassName(elm, className){
    var classToRemove = new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i");
    elm.className = elm.className.replace(classToRemove, "").replace(/^\s+|\s+$/g, "");
    return elm.className;
}

function activateThisColumn(column) {
	var table = document.getElementById('pricetable');
	
	// first, remove the 'on' class from all other th's
	var ths = table.getElementsByTagName('th');
	for (var g=0; g<ths.length; g++) {
		removeClassName(ths[g], 'on');
	}
	// then, remove the 'on' class from all other td's
	var tds = table.getElementsByTagName('td');
	for (var m=0; m<tds.length; m++) {
		removeClassName(tds[m], 'on');
	}
	
	// now, add the class 'on' to the selected th
	var newths = getElementsByClassName(column, 'th', table);
	for (var h=0; h<newths.length; h++) {
		addClassName(newths[h], 'on');
	}
	// and finally, add the class 'on' to the selected td
	var newtds = getElementsByClassName(column, 'td', table);
	for (var i=0; i<newtds.length; i++) {
		addClassName(newtds[i], 'on');
	}
}
</script>
</head>
<body>
<div class="top"></div>
<div class="base">
<div class="middle">
<div class="logo">&nbsp;  
</div>
<div class="topmenu">
<div class="right"></div>
<?php include 'topmenu.php'; ?>
<div class="left">  
</div><!--Top Menu -->
<div class="content">
<div class="content_top"></div>
<div class="content_bg">
<div id="right2">
		<div class="about"><div class="about_top"></div><div class="about_body">		<div class="menu_title">
		  <h6><img src="images/daste.png"  height="40" </h6></div><div class="text">		<ul>
        <?php 
$result2 = $conecct->query("select * from cat ");
			while (	$rows2=$result2->fetch(PDO::FETCH_ASSOC)){
			echo  '	<li><a href="index.php?at=0&cat='.checkparam($rows2['catid']).'" title="">'.checkparam($rows2['name']).'</a></li>';
			}
			?>
              <li><a href="index.php?flag=r" title="">رهن</a></li>	
            <li><a href="index.php?flag=e" title="">اجاره</a></li>	
            <li><a href="index.php?flag=er" title="">رهن و اجاره</a></li>
            <li><a href="index.php?flag=j" title="">جدید ترین آگهی ها</a></li>
            <li><a href="indx.php?flag=p" title="">پر بازدید ترین آگهی ها</a></li>
				</ul>
		</div></div><div class="about_bottom"></div></div><!--Menu -->
<p>`</p>
          <?php include 'login.php' ;	  
		  ?>          
      <p> <font color="" >.</font></p> 
          <div class="customers_title"><div class="menu_title">
	  <h6><img src="images/news.png"  height="40" </h6></div><div class="customers_icon"></div></div>
<div class="about">
<div class="content anyClass_01">
<ul>
<?php 
$result3 = $conecct->query("select * from news ");
			while (	$rows3=$result3->fetch(PDO::FETCH_ASSOC)){ 
echo "<li>
 <div class='bcontent'>
<div class='author'><a href='page.html' >".checkparam( $rows3['onvan'])."</a></div><div class='bcontent_top'></div>
<div class='bcontent_body'><div class='text'>"
.checkparam($rows3['matn'])."
 <br />
</div></div>
<div class='bcontent_bottom'></div>
</div>
</li>
";
}
?>
</ul>
</div>
</div>
<div class="box_bottom"></div>
<!--Customers box -->
</div><!--Right -->
<div class="post" >
<div class="post_body">
</form>
</div>
<div class="post_bottom"></div>
</div>
<div id="left2">
<?php 
		if (isset($_GET['at'])){
		$nnp=(checkGetParam($_GET['at'])-1)*8;
		$rows = $conecct->prepare("select * from moshaver limit ?, 8" );
		$rows->bindValue(1,$nnp, PDO::PARAM_INT);$rows->execute();
	}else {
$rows=$conecct->query("select * from moshaver  limit 0,5");
	}$tedadr=$conecct->query("select * from moshaver");
if ($rows->rowCount()==0){
	echo '
<div class="post" >هیچ مشاور املاکی در سایت ثبت نشده است</div>
';
}
while ($r=$rows->fetch(PDO::FETCH_ASSOC))
{    $conecct->exec("SET CHARACTER SET UTF8");
	$k=$conecct->prepare("select * from map where shahrid=? and mahaleid=?");
	$k->bindValue(1,$r['shahr']);$k->bindValue(2,$r['mahale']);
	$k->execute();
	$k1=$k->fetch(PDO::FETCH_ASSOC);

echo '
<div class="post" >
<div class="post_top"  ><font color="#fff" ><h2>  مشاور املاک : '.checkparam($r['name']).'</h2></font></div>
<div class="post_body">
  <table width="100%" border="1" bordercolor="#000000" cellpadding="10"   >
    <tr>
      <td bgcolor="#00FFCC" height="22" colspan="2"> <p>&nbsp;</p>
        <p>نام خانوادگی مسئول آژانس : '.checkparam($r['masul']).' </p>
        <p>پست الکترونیکی : '.checkparam($r['mail']).'  </p>
		  <p>شماره تماس : '.checkparam($r['tell']).' </p></td>
    </tr>
    <tr>
      <td bgcolor="#00FFCC"> محل فعالیت : '.checkparam($k1['shahr']).' '.checkparam($k1['mahale']).' '.checkparam($r['mantaghe']).' </td>
	  
	  ';  $rr = $conecct->prepare("select * from product where shparvande=?");
	  $rr->bindValue(1,$r['cod']);$rr->execute();
	  
   echo'   <td bgcolor="#00FFCC">  تعداد آگهی ها: '.$rr->rowCount().' </td>
      </tr>';
	  
	  

		echo '
  </table>

</div>
<div class="post_bottom"></div>
</div>';
}
 	if (isset($_GET['at']))
	echo 'صفحه ی  '. $_GET['at'];
	echo '<p>&nbsp;</p>';
$n=$rows->rowCount();		
$pages=ceil($n/8);	
$radifs=ceil($pages/10);
$tah=$pages;
$cradif=1;
$cpage=1;
$tah=$pages;
if (isset($_GET['at'])){
$cpage=checkGetParam($_GET['at']);
$cradif=ceil($cpage/10);
if ($cradif<$radifs){
	$tah=$cradif*10;
}
else {
	$tah=$pages;
}
	
}

if ($cradif<$radifs && $cradif>1){
		echo "<a class='paging' href=?at=".((($cradif-1)*10)+1)."> <-- قبلی  </a>    "  ;		
	}
for ($i=$cradif ; $i<=$tah ; $i++ )
{


	echo "<a  class='paging' href=?at=".$i ."> ".($i) ."</a> |  "  ;
}
	if ($cradif<$radifs){
		echo "<a  class='paging' href=?at=".((($cradif+1)*10)+1)."> ادامه --> </a>    "  ;
		
	}
	

?>
<p>.</p>
</div><!--Left -->

</div>
<div class="content_bottom">
<?php
include 'footer.php';
?>
</div>
</div><!--Conetnt -->   
</body>
</html>