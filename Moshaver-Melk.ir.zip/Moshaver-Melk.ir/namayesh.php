    <!DOCTYPE HTML>
    <html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>Google Maps</title>
        <style type="text/css">
          #map-canvas{
            width: 700px;
            height: 500px;
            margin: 0 auto;
          }
        </style>
            		<?php include 'func/connect2.php'; 
                    $conecct->exec("SET CHARACTER SET UTF8");		
  $re=$conecct->prepare("select  * from map where shahrid=? and mahaleid=?");
			 $re->bindValue(1,$_POST['shahr']); $re->bindValue(2,$_POST['mahale']);$re->execute();
$result=$re->fetch(PDO::FETCH_ASSOC);
?>
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
        <script type="text/javascript">
      function initialize() {
             var myLatlng = new google.maps.LatLng(<?php echo $result['mapid'];?>);		  
             var mapOptions = {
               zoom: 15,
               center: myLatlng,
               mapTypeId: google.maps.MapTypeId.ROADMAP
             }          
             var map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
             
             var contentString = '<div style="direction: rtl; text-align: right;font-family: Tahoma;">' +
                                        <?php echo"'<h4>".$result['shahr']." ,".$result['mahale']." </h4>' +
                                          '<h5></h5>' +
                                          '</div>'" ;?>; 
             
             var infowindow = new google.maps.InfoWindow({
               content: contentString
             });
             
             var marker = new google.maps.Marker({
               position: myLatlng,
               map: map,
               title: 'Takhte Jamshid'
             });
             
             infowindow.open(map, marker);
             google.maps.event.addListener(marker, 'click', function() {
               infowindow.open(map, marker);
             });
           }
        </script>
    </head>
    <body onload="initialize()">    
        <div id="map-canvas"></div>
    </body>
    </html>
