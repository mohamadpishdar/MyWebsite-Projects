﻿﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
 <script src="sliderengine/jquery.js"></script>
    <script src="sliderengine/amazingslider.js"></script>
    <link rel="stylesheet" type="text/css" href="sliderengine/amazingslider-1.css">
    <script src="sliderengine/initslider-1.js"></script>
<script language="javascript" src="ckeditor/ckeditor.js"></script>
<script language="javascript">
   function check ( x1,x2 ,x3 ) 
{
if (x1=='' ){
alert("لطفا  نام خودتان را وارد کنید");
document.getElementById('nam').focus();
return false ;
}	
	
if (x2=='' ){
alert("لطفا  موضوع را وارد کنید");
document.getElementById('moozoo').focus();
return false ;
}
if (x3=='' ){
alert(" لطفا ایمیل را وارد نمایید");
document.getElementById('email').focus();

return false ;
}
else 
return true ;

}
</script>
<title>تماس با ما</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	

 <style type="text/css" media="screen">
		@import url(style.css );
		@import url(tab.css );
	body,td,th {
	color: #000;
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
}
   .middle .topmenu .content .content_bg .post .post_body table tr td p {
	text-align: right;
}
 .middle .topmenu .content .content_bg .post .post_body table tr td {
	text-align: right;
}
 </style>
<script src="js/jcarousellite_1.0.1c4.js" type="text/javascript"></script>
<script type="text/javascript" src="js/01.js"></script>
<script type="text/javascript" src="js/02.js"></script>
<script type="text/javascript" src="js/03.js"></script>
<script type="text/javascript" src="js/general.js"></script>
<script type="text/javascript">
function getElementsByClassName(className, tag, elm){
	var testClass = new RegExp("(^|\\s)" + className + "(\\s|$)");
	var tag = tag || "*";
	var elm = elm || document;
	var elements = (tag == "*" && elm.all)? elm.all : elm.getElementsByTagName(tag);
	var returnElements = [];
	var current;
	var length = elements.length;
	for(var i=0; i<length; i++){
		current = elements[i];
		if(testClass.test(current.className)){
			returnElements.push(current);
		}
	}
	return returnElements;
}

function addClassName(elm, className){
    var currentClass = elm.className;
    if(!new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i").test(currentClass)){
        elm.className = currentClass + ((currentClass.length > 0)? " " : "") + className;
    }
    return elm.className;
}

function removeClassName(elm, className){
    var classToRemove = new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i");
    elm.className = elm.className.replace(classToRemove, "").replace(/^\s+|\s+$/g, "");
    return elm.className;
}

function activateThisColumn(column) {
	var table = document.getElementById('pricetable');
	
	// first, remove the 'on' class from all other th's
	var ths = table.getElementsByTagName('th');
	for (var g=0; g<ths.length; g++) {
		removeClassName(ths[g], 'on');
	}
	// then, remove the 'on' class from all other td's
	var tds = table.getElementsByTagName('td');
	for (var m=0; m<tds.length; m++) {
		removeClassName(tds[m], 'on');
	}
	
	// now, add the class 'on' to the selected th
	var newths = getElementsByClassName(column, 'th', table);
	for (var h=0; h<newths.length; h++) {
		addClassName(newths[h], 'on');
	}
	// and finally, add the class 'on' to the selected td
	var newtds = getElementsByClassName(column, 'td', table);
	for (var i=0; i<newtds.length; i++) {
		addClassName(newtds[i], 'on');
	}
}
</script>
</head>
<body>
<div class="top"></div>
<div class="base">
<div class="middle">
<div class="logo">&nbsp;  
</div>
<div class="topmenu">
<div class="right"></div>
<?php include 'topmenu.php'; ?>
<div class="left">
</div><!--Top Menu -->
<div class="content">
<div class="content_top"></div>
<div class="content_bg">
<div id="right2">
		<div class="about"><div class="about_top"></div><div class="about_body">		<div class="menu_title">
		  <h6>دسته بندی  </h6></div><div class="text">		<ul>
        <?php 
		include 'func/connect2.php';
		$r=$conecct->query("select * from cat" );

while ($rows =$r->fetch(PDO::FETCH_ASSOC )) 
			echo  '	<li><a href="index.php?at=0&cat='.checkparam($rows['catid']).'" title="">'.checkparam($rows['name']).'</a></li>';
			?>
              <li><a href="index.php?flag=r" title="">رهن</a></li>	
            <li><a href="index.php?flag=e" title="">اجاره</a></li>	
            <li><a href="index.php?flag=er" title="">رهن و اجاره</a></li>
            <li><a href="index.php?flag=j" title="">جدید ترین آگهی ها</a></li>
            <li><a href="indx.php?flag=p" title="">پر بازدید ترین آگهی ها</a></li>	
				</ul>
		</div></div><div class="about_bottom"></div></div><!--Menu -->
        <p>`</p>
        
          <?php include 'login.php' ;?>          
          <p> <font color="" >.</font></p>
          <div class="customers_title"><div class="customers_icon"></div></div>
<div class="content anyClass_01">
<ul>
<?php 
$result3 = $conecct->query("select * from news ");
			while (	$rows3=$result3->fetch(PDO::FETCH_ASSOC)){ 
echo "<li>
 <div class='bcontent'>
<div class='author'><a href='page.html' >".checkparam( $rows3['onvan'])."</a></div><div class='bcontent_top'></div>
<div class='bcontent_body'><div class='text'>"
.checkparam($rows3['matn'])."
 <br />
</div></div>
<div class='bcontent_bottom'></div>
</div>
</li>

";
}
?>
</ul>
</div>
<div class="box_bottom"></div>
<!--Customers box -->
</div><!--Right -->
<div class="post" >
<div class="post_body">
</form>
</div>
<div class="post_bottom"></div>
</div>
<div id="left2">
<form action="tamasq.php" method="post"  onsubmit="return check(nam.value , moozoo.value , email.value)" >
  <table width="100%" border="0" class="text">
    <tr>
      <td colspan="2"><?php if (isset($_SESSION['msg2'])) echo $_SESSION['msg2'] ; if (isset($_SESSION['check']) )echo "پیام شما با موفقیت ثبت گردید" ?></td>
      </tr>
    <tr>
      <td width="21%" bgcolor="#00CCFF">*نام شما</td>
      <td width="79%" bgcolor="#00CCFF"><label for="nam"></label>
        <input type="text" name="nam" id="nam" /></td>
    </tr>
    <tr>
      <td bgcolor="#00CCFF">*موضوع مربوطه :</td>
      <td bgcolor="#00CCFF"><label for="moozoo"></label><input type="text" name="moozoo" id="moozoo" /></td>
    </tr>
    <tr>
      <td bgcolor="#00CCFF"> *ایمیل شما :</td>
      <td bgcolor="#00CCFF"><label for="email"></label>
        <input name="email" type="text" id="email" /></td>
    </tr>
      <tr>
      <td bgcolor="#00CCFF">*متن مورد نظرشما :</td>
      <td bgcolor="#00CCFF"><label for="matn"></label>
        <textarea name="matn" id="matn" cols="45" rows="5" class="ckeditor"></textarea></td>
    </tr>
   
      <tr>
        <td colspan="2" bgcolor="#00CCFF">تصویر امنیتی زیر را وارد نمایید</td>
      </tr>
      <tr>
        <td colspan="2" bgcolor="#00CCFF">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="2" bgcolor="#00CCFF"><img src="func/captcha.php"/></td>
      </tr>
      <tr>
        <td colspan="2" bgcolor="#00CCFF"><input type="text" name="captcha" id="captcha" /></td>
      </tr>
      <tr>
      <td colspan="2" bgcolor="#00CCFF"><input class="dddd" type="submit" name="button"  id="button" value="ثبت" /></td>
      </tr>
  </table>
  </form></div><!--Left -->

</div>
<div class="content_bottom">
</div>
</div><!--Conetnt -->
<?php
include 'footer.php';
?>
</body>
</html>
