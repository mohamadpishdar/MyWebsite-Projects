<?php 
ob_start();
session_start();
include 'func/funcs.php';
  include 'func/connect2.php';
 $_SESSION['mosh']=0;
 $_SESSION['msg10']='';
 if (isset($_POST['captcha'])){
  if (strcmp(strtoupper($_POST['captcha']),$_SESSION['captcha'])!=0)
 {
	 $_SESSION['msg10']="در وارد کردن تصویر امنیتی دقت نمایید";	 
 } 
 else {
	 if (isset($_POST['us'])){
		 if ($_SESSION['mosh']!=1){
			 $re=$conecct->prepare("select * from moshaver where cod=? and pass=?");
			 $re->bindValue(1,(-1)*($_POST['us']));
			 $passn=hash_value($_POST['pass']);
			  $re->bindValue(2,$passn);
			  $re->execute();
$rr=$re->fetch(PDO::FETCH_ASSOC);
$_SESSION['cod']=$rr['cod'];
$_SESSION['shparvande']=$rr['cod'];
	$_SESSION['namemosh']=$rr['name'];		
 	$_SESSION['tellm']=$rr['tell'];	
  	$_SESSION['addressm']=$rr['address'];	
	  	$_SESSION['masul']=$rr['masul'];		
  $re1=$conecct->prepare("update moshaver set lastlogin=? where cod=? and pass=?");
   $re1->bindValue(1,getCurentDate());
 $re1->bindValue(2,$_POST['us']);
$re1->bindValue(3,$passn);
$re1->execute();
 if ( $re->rowCount()== 1){
 $_SESSION['mosh']=1;
 header("location:moshavercontrolpanel.php?id=".$_POST['us']);
 }
 else 
  $_SESSION['msg10']="لطفا در وارد  کردن نام کاربری یا کلمه ی عبور دقت کنید ";
 } 
 }
 }
 }
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
  <style type="text/css" media="screen">
		@import url(style.css );
		@import url(tab.css );
	body,td,th {
	color: #000;
	font-family: Tahoma, Geneva, sans-serif;
}
   </style>
   

<style type="text/css">
.about .about_body .text ul table tr td #form1 {
	text-align: center;
}
</style>
<title>ورود مشاورین املاک</title>
</head>

<body>
<table align="center">
<tr>
<td>
<div class="about"><div class="about_top"></div><div class="about_body">	
        	<div class="menu_title">
		  <h6>ورود مشاور املاک</h6></div><div class="text">		<ul>
          <form action="" method="post" >
            <table width="100%" border="1">
              <tr>
                <td colspan="2"><?php echo checkparam($_SESSION['msg10']) ?>&nbsp;</td>
                </tr>
              <tr>
                <td>کدآژانس نزد اتحادیه املاک :</td>
                <td><label for="us"></label>

                <input type="text" name="us" id="us" /></td>
              </tr>
              <tr>
                <td>کلمه ی عبور :</td>
                <td><input type="password" name="pass" id="pass" /></td>
              </tr>
              <tr>
                <td colspan="2"><img src="func/captcha.php"/>&nbsp;</td>
              </tr>
              <tr>
                <td colspan="2"><label for="captcha"></label>
                  <input type="text" name="captcha" id="captcha" /></td>
              </tr>
              <tr>
                <td colspan="2"><input name="Reset" type="reset" class="dddd" id="button" value="پاک کردن" />
                  <input name="button2" type="submit" class="dddd" id="button2" value="ورود" /></td>
              </tr>
            </table>
            </form>
          </ul>
		    <p align="center">&nbsp;</p>
</div></div><div class="about_bottom"></div></div>
</td></tr></table>
</body>
</html>