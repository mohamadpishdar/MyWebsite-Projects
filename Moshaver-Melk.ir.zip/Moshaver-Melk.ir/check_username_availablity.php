<?php
ob_start();
session_start();
include('func/connect2.php');
if($_REQUEST)
{
	if (isset ( $_REQUEST['username'])){ 
$username = $_REQUEST['username'];
$query = "select * from user where userid =?";
$re=$conecct->prepare($query);
$re->bindValue(1,$username);
 $re->execute();
if($re->rowCount()>0)
{
	$_SESSION['sabtshode']=1;
echo "<div color:'#FF0000'>این نام کاربری قبلا ثبت شده است </div>";
}
else
{
 
	$_SESSION['sabtshode']=0;

echo '<div >این نام کاربری آزاد است</div>';
}
}

if (isset ( $_REQUEST['cod'])){ 
$cod = $_REQUEST['cod'];
$query = "select * from moshaver where userid =?";
$re=$conecct->prepare($query);
$re->bindValue(1,$cod);
 $re->execute();
 if($re->rowCount()>0)
{
	$_SESSION['sabtshode']=1;

echo "<div color:'#FF0000'>این مشاور املاک قبلا ثبت شده است </div>";
}
else
{
 
$_SESSION['sabtshode']=0;
echo '<div >این کد مشاور املاک قابل ثبت می باشد</div>';
}
}
}

?>