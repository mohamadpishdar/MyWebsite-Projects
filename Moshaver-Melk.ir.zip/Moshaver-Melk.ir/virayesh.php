<?php 
ob_start();

$p='کاربر گرامی اطلاعات جدید خود را در فیلد های زیر وارد نمایید فیلد ها با مقادیر قبلی که ثبت کرده اید پر شده اند  ';
include 'func/connect2.php' ;


if (isset($_POST['sabt'])){
	$p="تغییرات با موفقیت اعمال گردید";
$result1=$conecct->prepare("update product set tozih=? ,metri= ?, gheymat= ?   where productid=?");
$result1->bindValue(1,$_POST['tozihat']);
$result1->bindValue(2,$_POST['metri']);
$result1->bindValue(3,$_POST['gheymat']);$result1->bindValue(4,$_GET['id']);$result1->execute();
	$s2=$_FILES['pic']['type'];
if ($_FILES['pic']['size']!=0 && $s2=='image/jpeg' ){
		$s1=$_FILES['pic']['size'];
		if ($s1<200000 ) {
	$s1=$_FILES['pic']['size'];
	$t1=$_FILES['pic']['type'];
	$n1=$_FILES['pic']['tmp_name'];
	$fp1=fopen($n1,'r');
	$pic1=fread($fp1,filesize($n1));
	$result2=$conecct->prepare("update product set axdo=?  where productid=?");
$result2->bindValue(1,$pic1);$result2->bindValue(2,$_GET['id']);
$result2->execute();

}
else {
			echo "<script language='javascript' > alert('لطفا به مشکلات تصاویر رسیدگی نمایید'); </script>";

	}
}

if ($_FILES['pic2']['size']!=0){	
$s2=$_FILES['pic2']['size'];$t2=$_FILES['pic2']['type'];
	if ( $s2<200000 && $t2=='image/jpeg' ) {
	$s2=$_FILES['pic2']['size'];
	$t2=$_FILES['pic2']['type'];
	$n2=$_FILES['pic2']['tmp_name'];
	$fp2=fopen($n2,'r');
	$pic2=fread($fp2,filesize($n2));
	$result1=$conecct->prepare("update product set axse=?  where productid=?");
$result1->bindValue(1,$pic2);$result1->bindValue(2,$_GET['id']);
$result1->execute();
}
else {
			echo "<script language='javascript' > alert('لطفا به مشکلات تصاویر رسیدگی نمایید'); </script>";

	}

	}
	
}

?>
<head>
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript">
function check_ax1(){	
var ax1 = $("#pic")[0].files[0].size;
if ( ax1>200000 ){
	var eror=1;
$('#Info').fadeOut();
 $('#Loading').hide();

setTimeout("finishAjax('Info', 'تصویر انتخاب شده برای فیلد تصویر داخلی اول دارای حجم زیاد میباشد ')", 450);
}else 
$('#Info').hide();

}
function check_ax2(){
var ax2 = $("#pic2")[0].files[0].size;
if ( ax2>200000 ){
	var eror=1;
$('#Info2').fadeOut();
 $('#Loading2').hide();

setTimeout("finishAjax('Info2', 'تصویر انتخاب شده برای فیلد تصویر داخلی دوم دارای حجم زیاد میباشد ')", 450);
}else 
$('#Info2').hide();
}


function finishAjax(id, response){
$('#'+id).html(unescape(response));
$('#'+id).fadeIn(1000);
}
</script>  
<title>ویرایش آگهی </title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
 <style type="text/css" media="screen">
		@import url(style.css );
		@import url(tab.css );
	body,td,th {
	color: #000;
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
}
   .middle .topmenu .content .content_bg .post .post_body table tr td p {
	text-align: right;
}
 .middle .topmenu .content .content_bg .post .post_body table tr td {
	text-align: right;
}
 </style>
<script src="js/jcarousellite_1.0.1c4.js" type="text/javascript"></script>
<script language="javascript" src="ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="js/01.js"></script>
<script type="text/javascript" src="js/02.js"></script>
<script type="text/javascript" src="js/03.js"></script>
<script type="text/javascript" src="js/general.js"></script>
<script type="text/javascript">
function getElementsByClassName(className, tag, elm){
	var testClass = new RegExp("(^|\\s)" + className + "(\\s|$)");
	var tag = tag || "*";
	var elm = elm || document;
	var elements = (tag == "*" && elm.all)? elm.all : elm.getElementsByTagName(tag);
	var returnElements = [];
	var current;
	var length = elements.length;
	for(var i=0; i<length; i++){
		current = elements[i];
		if(testClass.test(current.className)){
			returnElements.push(current);
		}
	}
	return returnElements;
}

function addClassName(elm, className){
    var currentClass = elm.className;
    if(!new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i").test(currentClass)){
        elm.className = currentClass + ((currentClass.length > 0)? " " : "") + className;
    }
    return elm.className;
}

function removeClassName(elm, className){
    var classToRemove = new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i");
    elm.className = elm.className.replace(classToRemove, "").replace(/^\s+|\s+$/g, "");
    return elm.className;
}

function activateThisColumn(column) {
	var table = document.getElementById('pricetable');
	
	// first, remove the 'on' class from all other th's
	var ths = table.getElementsByTagName('th');
	for (var g=0; g<ths.length; g++) {
		removeClassName(ths[g], 'on');
	}
	// then, remove the 'on' class from all other td's
	var tds = table.getElementsByTagName('td');
	for (var m=0; m<tds.length; m++) {
		removeClassName(tds[m], 'on');
	}
	
	// now, add the class 'on' to the selected th
	var newths = getElementsByClassName(column, 'th', table);
	for (var h=0; h<newths.length; h++) {
		addClassName(newths[h], 'on');
	}
	// and finally, add the class 'on' to the selected td
	var newtds = getElementsByClassName(column, 'td', table);
	for (var i=0; i<newtds.length; i++) {
		addClassName(newtds[i], 'on');
	}
}
</script>
</head>
<body>
<div class="top"></div>
<div class="base">
<div class="middle">
<div class="logo">&nbsp;  
</div>
<div class="topmenu">
<div class="right"></div>
<?php include 'topmenu.php'; ?>
<div class="left">
</div><!--Top Menu -->
<div class="content">
<div class="content_top"></div>
<div class="content_bg">
<div id="right2">
		<div class="about"><div class="about_top"></div><div class="about_body">		<div class="menu_title">
		  <h6>دسته بندی </h6></div><div class="text">		<ul>
        <?php 
		$r=$conecct->query("select * from cat");
while ($rows =$r->fetch(PDO::FETCH_ASSOC))
			echo  '	<li><a href="?at=0&cat='.checkparam($rows['catid']).'" title="">'.checkparam($rows['name']).'</a></li>';
			?>
              <li><a href="index.php?flag=r" title="">رهن</a></li>	
            <li><a href="index.php?flag=e" title="">اجاره</a></li>	
            <li><a href="index.php?flag=er" title="">رهن و اجاره</a></li>
            <li><a href="index.php?flag=j" title="">جدید ترین آگهی ها</a></li>
            <li><a href="indx.php?flag=p" title="">پر بازدید ترین آگهی ها</a></li>	
				</ul>

		</div></div><div class="about_bottom"></div></div><!--Menu -->
        <p>`</p>
          <?php include 'login.php' ;    if ( $_SESSION['login']!=1 && $_SESSION['mosh']!=1)
header('location:index.php'); 
if (isset($_POST['exit'])){
if ($_SESSION['login']==1)
header('location:usercontrolpanel.php?id='.$_SESSION['shparvande']);
if ($_SESSION['mosh']==1)
header('location:moshavercontrolpanel.php?id='.($_SESSION['cod']*-1));	
}?>
          <p> <font color="" >.</font></p>
          <div class="customers_title"><div class="customers_icon"></div></div>
<div class="content anyClass_01">
<ul>
<?php 
		$r=$conecct->query("select * from news");
while ($rows =$r->fetch(PDO::FETCH_ASSOC)){

echo "<li>
 <div class='bcontent'>
<div class='author'><a href='page.html' >".checkparam( $rows['onvan'])."</a></div><div class='bcontent_top'></div>
<div class='bcontent_body'><div class='text'>"
.checkparam($rows['matn'])."
 <br />
</div></div>
<div class='bcontent_bottom'></div>
</div>
</li>

";
}
?>
</ul>
</div>
<div class="box_bottom"></div>
<!--Customers box -->
</div><!--Right -->
<div class="post" >
<form action="" method="post" >
<input type="submit" name="exit" id="exit" value="بازگشت به کنترل پنل"  /></form>
<div class="post_top">
  <h2>کاربر گرامی <?php if(isset($_GET['h'])==false){ echo checkparam($_SESSION['fn']). checkparam($_SESSION['ln' ]); } else { echo checkparam($_SESSION['masul']);}?> خوش آمدید</h2></div>
<div class="post_bottom">
<?php 
$re=$conecct->prepare("select * from product where productid=?");
$re->bindValue(1,checkGetParam($_GET['id']));
$re->execute();
$row=$re->fetch(PDO::FETCH_ASSOC);
?>
<form method="post" action="" enctype="multipart/form-data" >
 <table width="100%" border="1">
  <tr>
    <td colspan="2"><?php echo $p; ?></td>
    </tr>
  <tr>
    <td>توضیحات جدید</td>
    <td><label for="tozihat"></label>
      <textarea  name="tozihat" id="tozihat" cols="45" rows="5"  value="<?php echo checkparam($row['tozih']) ?>"></textarea></td>
  </tr>
  <tr>
    <td>قیمتی متری که برای ملک خود در نظر دارید به میلیون تومان </td>
    <td><label for="metri"></label>
      <input type="text" name="metri" id="metri"  value="<?php echo checkparam($row['metri']) ?>"></td>
  </tr>
  <tr>
    <td>قیمت کل به میلیون تومان</td>
    <td><label for="gheymat"></label>
      <input type="text" name="gheymat" id="gheymat"  value="<?php echo checkparam($row['gheymat']) ?>"></td>
  </tr>
  <tr>
    <td colspan="2" bgcolor="#0099FF">  شما از طریق زیر می توانید عکس هایی که هنگام ثبت آگهی برای داخل ملک خود تعیین کردید را تغییر دهید  . حجم همه ی تصاویر باید کمتر از 200 کیلو بایت باشد در غیر این صورت تغییرات اعمال نخواهد شد . <div id="Info"  ></div><span id="Loading" ></span></div> <div id="Info2"  ></div><span id="Loading2" ></span></div></td>
    </tr>
  <tr>
    <td>تغییر عکس داخلی اول </td>
    <td><label for="pic"></label>
      <input type="file" name="pic" id="pic" onBlur="return check_ax1();" ></td></tr>
      <tr> <td>تغییر عکس داخلی دوم </td>
    <td><label for="pic2"></label>
      <input type="file" name="pic2" id="pic2" onBlur="return check_ax2();"></td></tr>
  </tr>
  <tr>
    <td colspan="2"><input type="submit" name="sabt" id="sabt" value="ثبت"></td>
    </tr>
</table>
</form>
</div>
<div id="left2">
</div><!--Left -->
</div>
<div class="content_bottom">
</div>
</div><!--Conetnt -->
<?php
include 'footer.php';
?>   
</body>
</html>
