<?php
session_start();
ob_start();
include 'func/funcs.php' ;
?>
 <style type="text/css" media="screen">
		@import url(style.css );
		@import url(tab.css );
	body,td,th {
	color: #000;
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
}
   .middle .topmenu .content .content_bg .post .post_body table tr td p {
	text-align: center;
}
 .middle .topmenu .content .content_bg .post .post_body table tr td {
	text-align: center;
}
 .dddd {
	background-color: #03C;
	color: #FFF;
	padding: 10px;
	border-top-width: 10px;
	border-right-width: 10px;
	border-bottom-width: 10px;
	border-left-width: 10px;
	border-top-color: #FF0;
	border-right-color: #FF0;
	border-bottom-color: #FF0;
	border-left-color: #FF0;
	clip: rect(auto,auto,auto,auto);
}
 </style> 
<?php 
if ( isset($_SESSION['login'])==0){
$_SESSION['login']=0;
$_SESSION['msg']="";
}
if ( $_SESSION['login']!=1 ) {
	?>
<style type="text/css">
.about .about_body .text ul table tr td #form1 {
	text-align: center;
}
</style>
<div class="about"><div class="about_top"></div><div class="about_body">	
        	<div class="menu_title">
		  <h6><img src="images/vorood.png"  height="40" /></h6></div><div class="text">		<ul>
          <form action="checkuser.php" method="post" >
            <table width="100%" border="1">
              <tr>
                <td colspan="2"><?php echo $_SESSION['msg'] ?>&nbsp;</td>
              </tr>
              <tr>
                <td bgcolor="">نام کاربری :</td>
                <td><label for="us"></label>

                <input  align="right" type="text" name="us" id="us" /></td>
              </tr>
              <tr>
                <td>کلمه ی عبور :</td>
                <td><input type="password" name="pass" id="pass" /></td>
              </tr>
              <tr>
                <td colspan="2"><img src="func/captcha.php"/>&nbsp;</td>
              </tr>
              <tr>
                <td colspan="2"><label for="captcha"></label>
                <input type="text" name="captcha" id="captcha" /></td>
              </tr>
              <tr>
                <td colspan="2"><input name="Reset" type="reset" class="dddd" id="button" value="پاک کردن" />
                  <input name="button2" type="submit" class="dddd" id="button2" value="ورود"  /></td>
                </tr>
            </table>
            </form>
          </ul>
		    <p align="center"><a href="tamas.php">رمز عبور خود را فراموش کرده ام</a></p>
		    <p align="center"><a href="register.php">ثبت نام نکرده ام</a></p>
		  </div></div><div class="about_bottom"></div></div>                      
            <?php 
}
else {
?>
           <div class="about"><div class="about_top"></div><div class="about_body">	
        	<div class="menu_title">
		  <h6><img src="images/vorood.png"  height="40" /> </h6></div><div class="text">		<ul>
          <form action="logout.php" method="post" >
            <table width="100%" border="1">
              <tr>
                <td>خوش آمدید کاربر گرامی </td>
                <td><label for="us"></label>
                  <?php echo $_SESSION['fn'].' '.$_SESSION['ln']; ?></td>
              </tr>
              <tr>
                <td>آخرین ورود شما</td>
                <td><?php echo  $_SESSION['lastlogin'] ; ?></td>
              </tr>
                 <tr>
                <td>میزان اعتبار شما</td>
                <td><?php echo $_SESSION['etebar'] ?></td>
              </tr>
               <tr>
                <td>کنترل پنل کاربر</td>
                <td><a href="usercontrolpanel.php?id=<?php echo $_SESSION['shparvande'] ?> "> کلیک کنید</a></td>
              </tr>
              <tr>
                <td colspan="2"><input name="button2" type="submit" class="dddd" id="button2" value="خروج" /></td>
              </tr>
            </table>
            </form>
          </ul>
		    <p align="center">&nbsp;</p>
</div></div><div class="about_bottom"></div></div>
<?php
}
?>
