<?php
session_start();
ob_start();
$_SESSION['adm']=0;
header('location:../index.php');
?>