<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php 
include '../../func/connect2.php' ;
 ob_start();
session_start();
if ( $_SESSION['adm']!=1)
 header ("location:../../adminlogin.php");
if (isset($_POST['sabt'])){
	$re=$conecct->prepare("INSERT INTO `shopdb`.`hesab` (`onvan`, `shomarehesab`, `bank`, `shcart`, `moojoodi`, `moojoodibehoruf`) VALUES (?,?,?,?,?,?)");
	$re->bindValue(1,$_POST['onvan']);$re->bindValue(2,$_POST['shhesab']);$re->bindValue(3,$_POST['bank']);$re->bindValue(4,$_POST['shcart']);$re->bindValue(5,$_POST['mojoodi']);$re->bindValue(6,$_POST['horof']);
$re->execute();
}



?>
<head>
<title>پنل حسابدار</title>

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
   <style type="text/css" media="screen">
		@import url(../../style.css );
		@import url(../../tab.css );
	body,td,th {
	color: #000;
}
   </style>


 <script src="../../js/jquery-1.4.2.min.js" type="text/javascript"></script>
<script src="../../js/jcarousellite_1.0.1c4.js" type="text/javascript"></script>



<script type="text/javascript" src="../../js/01.js"></script>
<script type="text/javascript" src="../../js/02.js"></script>
<script type="text/javascript" src="../../js/03.js"></script>
<script type="text/javascript" src="../../js/general.js"></script>




<script type="text/javascript">
function getElementsByClassName(className, tag, elm){
	var testClass = new RegExp("(^|\\s)" + className + "(\\s|$)");
	var tag = tag || "*";
	var elm = elm || document;
	var elements = (tag == "*" && elm.all)? elm.all : elm.getElementsByTagName(tag);
	var returnElements = [];
	var current;
	var length = elements.length;
	for(var i=0; i<length; i++){
		current = elements[i];
		if(testClass.test(current.className)){
			returnElements.push(current);
		}
	}
	return returnElements;
}

function addClassName(elm, className){
    var currentClass = elm.className;
    if(!new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i").test(currentClass)){
        elm.className = currentClass + ((currentClass.length > 0)? " " : "") + className;
    }
    return elm.className;
}

function removeClassName(elm, className){
    var classToRemove = new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i");
    elm.className = elm.className.replace(classToRemove, "").replace(/^\s+|\s+$/g, "");
    return elm.className;
}

function activateThisColumn(column) {
	var table = document.getElementById('pricetable');
	
	// first, remove the 'on' class from all other th's
	var ths = table.getElementsByTagName('th');
	for (var g=0; g<ths.length; g++) {
		removeClassName(ths[g], 'on');
	}
	// then, remove the 'on' class from all other td's
	var tds = table.getElementsByTagName('td');
	for (var m=0; m<tds.length; m++) {
		removeClassName(tds[m], 'on');
	}
	
	// now, add the class 'on' to the selected th
	var newths = getElementsByClassName(column, 'th', table);
	for (var h=0; h<newths.length; h++) {
		addClassName(newths[h], 'on');
	}
	// and finally, add the class 'on' to the selected td
	var newtds = getElementsByClassName(column, 'td', table);
	for (var i=0; i<newtds.length; i++) {
		addClassName(newtds[i], 'on');
	}
}
</script>
</head>
<body>
<div class="top"></div>
<div class="base">
<div class="middle">
<div class="logo">&nbsp; </div>
<div class="topmenu">
<div class="right"></div>
<div class="body">
<ul id="iconbar">
<li class="home"><a href="index.php">صفحه اصلی حسابدار </a></li>
<li><a href="../adminlogout.php">خروج</a></li>

</ul>

</div>
<div class="left">

</div><!--Top Menu -->

<div class="content">
<div class="content_top"></div>
<div class="content_bg">



<div id="right2">

		<div class="about"><div class="about_top"></div><div class="about_body">		<div class="menu_title"><h6> دسترسی ها </h6></div><div class="text">		<ul>
				<li><a href="index.php" title="ساکس رایگان">پنل حسابدار</a></li>
				<li><a href="hazine.php" title="تغییر آدرس سرور سوییس">مدیریت هزینه ها</a></li>
				<li><a href="daramad.php" title="سرور جدید از کشور هلند">مدیریت درآمد ها </a></li>
               
				</ul>
		</div></div><div class="about_bottom"></div></div><!--Menu -->
</div><!--Right -->


<div id="left2">

<div class="post">
<div class="post_top">
  <h2>پنل حسابدار--&gt; مدیریت حساب ها</h2>
  \kg</div>
<div class="post_body">
<div class="text">

<div class="wpcf7" id="wpcf7-f16-p17-o1"><form action="" method="post" >
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="16" />
<input type="hidden" name="_wpcf7_version" value="3.1.2" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f16-p17-o1" />
<input type="hidden" name="_wpnonce" value="e8dd44d558" />
</div>
<table width="100%" border="1">
  <tr>
    <td colspan="4" bgcolor="#00CCFF">حساب جدید </td>
    </tr>
  <tr>
    <td width="10%">عنوان</td>
    <td width="9%">شماره حساب</td>
    <td width="21%">نام بانک</td>
    <td width="22%">شماره کارت</td>
    </tr>
  <tr>
    <td><label for="onvan"></label>
      <input type="text" name="onvan" id="onvan" /></td>
    <td><label for="shhesab"></label>
      <input type="text" name="shhesab" id="shhesab" /></td>
    <td><label for="horuf"></label>
      <input type="text" name="bank" id="bank" /></td>
    <td><label for="shcart"></label>
      <input type="text" name="shcart" id="shcart" />      <label for="cat"></label></td>
    </tr>
  <tr>
    <td>موجودی</td>
    <td>به حروف</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    </tr>
  <tr>
    <td><input type="text" name="mojoodi" id="mojoodi" /></td>
    <td><input type="text" name="horof" id="horof" /></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="4"><input type="submit" name="sabt" id="sabt" value="ثبت حساب جدید" /></td>
    </tr>
    </form>
  <tr>
  <?php 
  if (isset($_GET['at'])){
		$nnp=(checkGetParam($_GET['at'])-1)*20;
$r =$conecct->prepare("select * from hesab limit ?,20");
$r->bindValue(1,$nnp, PDO::PARAM_INT);$r->execute();
	}
	else
			$r=$conecct->query("select * from hesab limit 0,20");  
			while ($rows4=$r->fetch(PDO::FETCH_ASSOC)) {
	  echo "
	  
    <td bgcolor='#00FF66'> عنوان: ".checkparam($rows4['onvan']). " </td>
    <td bgcolor='#00FF66'>شماره حساب : ".checkparam($rows4['shomarehesab'])."</td>
    <td bgcolor='#00FF66'> نام بانک: ".checkparam($rows4['bank'])."</td>
	  <td bgcolor='#00FF66'>شماره کارت: ".checkparam($rows4['shcart'])." </td>
  </tr>
    
  <tr>
  

    <td bgcolor='#00FF66'>موجودی: ".checkparam($rows4['moojoodi'])." </td>
    <td bgcolor='#00FF66'> موجودی : ".checkparam($rows4['moojoodibehoruf'])." </td>
	    

    </tr>";
	  
  }
  
  
  ?>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><label for="horof"></label></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    </tr>
</table>
</form>



<?php 

	if (isset($_GET['at']))
	echo 'صفحه ی '. $_GET['at'];
	echo '<p>&nbsp;</p>';
	
	$tedadr=$conecct->query("select * from hesab ");
		$n= $tedadr->rowCount();
$pages=ceil($n/20);	

$radifs=ceil($pages/10);
$tah=$pages;
$cradif=1;
$cpage=1;

if (isset($_GET['at'])){
$cpage=checkGetParam($_GET['at']);
$cradif=ceil($cpage/10);

if ($cradif<$radifs){
	$tah=$cradif*10;
}
else {
	$tah=$pages;
}
	
}

if ($cradif<$radifs && $cradif>1){
		echo "<a class='paging' href=?at=".((($cradif-1)*10)+1)."> <-- قبلی  </a>    "  ;		
	}
for ($i=$cradif ; $i<=$tah ; $i++ )
{
if ( isset($_GET['cat']))
{
	
echo "<a class='paging' href=?cat=".checkGetParam($_GET['cat'])."&at=".$i ."> ".($i) ."</a> |  "  ;	

}
else 
	echo "<a class='paging' href=?at=".$i ."> ".($i) ."</a> |  "  ;
}
	if ($cradif<$radifs){
		echo "<a class='paging' href=?at=".((($cradif+1)*10)+1)."> ادامه --> </a>    "  ;
		
	}

?>
<div class="wpcf7-response-output wpcf7-display-none"></div></div>

</div></div>
<div class="post_bottom"></div>
</div>


</div><!--Left -->

</div>
<div class="content_bottom"></div>
</div><!--Conetnt -->

<div class="footer">
<div class="footer_right"></div>
<div class="footer_body"><div class="text"><center>
کلیه حقوق مادی و معنوی این وب سایت برای شرکت پیشدار محفوظ می باشد.<br>
</center>
</div></div>
<div class="footer_left"></div>
</div>  

<div class="clr"></div>



</div><!--Middle -->
</div>
</body>
</html>
