<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php 
include '../../func/connect2.php' ;
 ob_start();
session_start();
if ( $_SESSION['adm']!=1)
 header ("location:../../adminlogin.php");
if (isset($_POST['sabt'])){
	$re= $conecct->prepare("INSERT INTO `shopdb`.`hazine` (`tarikh`, `mablagh`, `mablaghbehorof`, `dasteid`, `hesabid`, `fard`, `nooe`) VALUES (?,?,?,?,?,?,'1')");
	$re->bindValue(1,$_POST['tarikh']);$re->bindValue(2,$_POST['mablagh']);$re->bindValue(3,$_POST['horuf']);$re->bindValue(4,$_POST['cat']);$re->bindValue(5,$_POST['hesab']);$re->bindValue(6,$_POST['fard']);
$re->execute();
}



?>
<head>
<title>پنل حسابدار</title>

	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />	
	<style type="text/css" media="screen">
		@import url(../../style.css );
		@import url(../../tab.css );
	</style>


 <script src="../../js/jquery-1.4.2.min.js" type="text/javascript"></script>
<script src="../../js/jcarousellite_1.0.1c4.js" type="text/javascript"></script>



<script type="text/javascript" src="../../js/01.js"></script>
<script type="text/javascript" src="../../js/02.js"></script>
<script type="text/javascript" src="../../js/03.js"></script>
<script type="text/javascript" src="../../js/general.js"></script>




<script type="text/javascript">
function getElementsByClassName(className, tag, elm){
	var testClass = new RegExp("(^|\\s)" + className + "(\\s|$)");
	var tag = tag || "*";
	var elm = elm || document;
	var elements = (tag == "*" && elm.all)? elm.all : elm.getElementsByTagName(tag);
	var returnElements = [];
	var current;
	var length = elements.length;
	for(var i=0; i<length; i++){
		current = elements[i];
		if(testClass.test(current.className)){
			returnElements.push(current);
		}
	}
	return returnElements;
}

function addClassName(elm, className){
    var currentClass = elm.className;
    if(!new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i").test(currentClass)){
        elm.className = currentClass + ((currentClass.length > 0)? " " : "") + className;
    }
    return elm.className;
}

function removeClassName(elm, className){
    var classToRemove = new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i");
    elm.className = elm.className.replace(classToRemove, "").replace(/^\s+|\s+$/g, "");
    return elm.className;
}

function activateThisColumn(column) {
	var table = document.getElementById('pricetable');
	
	// first, remove the 'on' class from all other th's
	var ths = table.getElementsByTagName('th');
	for (var g=0; g<ths.length; g++) {
		removeClassName(ths[g], 'on');
	}
	// then, remove the 'on' class from all other td's
	var tds = table.getElementsByTagName('td');
	for (var m=0; m<tds.length; m++) {
		removeClassName(tds[m], 'on');
	}
	
	// now, add the class 'on' to the selected th
	var newths = getElementsByClassName(column, 'th', table);
	for (var h=0; h<newths.length; h++) {
		addClassName(newths[h], 'on');
	}
	// and finally, add the class 'on' to the selected td
	var newtds = getElementsByClassName(column, 'td', table);
	for (var i=0; i<newtds.length; i++) {
		addClassName(newtds[i], 'on');
	}
}
</script>
</head>
<body>
<div class="top"></div>
<div class="base">
<div class="middle">
<div class="logo">&nbsp; </div>
<div class="topmenu">
<div class="right"></div>
<div class="body">
<ul id="iconbar">
<li class="home"><a href="index.php">صفحه اصلی حسابدار </a></li>
<li><a href="../adminlogout.php">خروج</a></li>

</ul>

</div>
<div class="left">

</div><!--Top Menu -->

<div class="content">
<div class="content_top"></div>
<div class="content_bg">



<div id="right2">

		<div class="about"><div class="about_top"></div><div class="about_body">		<div class="menu_title"><h6> دسترسی ها </h6></div><div class="text">		<ul>
        <li><a href="index.php" title="ساکس رایگان">پنل حسابدار</a></li>
				<li><a href="daste.php" title="تغییر آدرس سرور سوییس">مدیریت حساب ها</a></li>
				<li><a href="daramad.php" title="سرور جدید از کشور هلند">مدیریت درآمد ها </a></li>
                
                 <li><a href="daste.php" title="سرور جدید از کشور هلند">مدیریت دسته بندی ها </a></li>

                
			
               
				</ul>
		</div></div><div class="about_bottom"></div></div><!--Menu -->
</div><!--Right -->


<div id="left2">

<div class="post">
<div class="post_top">
  <h2>پنل حسابدار--&gt; مدیریت هزینه ها</h2>
  \kg</div>
<div class="post_body">
<div class="text">

<div class="wpcf7" id="wpcf7-f16-p17-o1"><form action="" method="post" class="">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="16" />
<input type="hidden" name="_wpcf7_version" value="3.1.2" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f16-p17-o1" />
<input type="hidden" name="_wpnonce" value="e8dd44d558" />
</div>
<table width="100%" border="1">
  <tr>
    <td colspan="6" bgcolor="#FF0033">هزینه جدید</td>
    </tr>
  <tr>
    <td width="10%">تاریخ</td>
    <td width="9%">مبلغ</td>
    <td width="21%">مبلغ به حروف </td>
    <td width="22%">دسته بندی </td>
    <td width="19%">حساب </td>
    <td width="19%">فرد مرتبط </td>
  </tr>
  <tr>
    <td><label for="tarikh"></label>
      <input type="text" name="tarikh" id="tarikh" /></td>
    <td><label for="mablagh"></label>
      <input type="text" name="mablagh" id="mablagh" /></td>
    <td><label for="horuf"></label>
      <input type="text" name="horuf" id="horuf" /></td>
    <td><label for="cat"></label>
      <select name="cat" id="cat">
        <?php 
              $r=$conecct->query("select * from daste" );
$i=0;
while ($rows = $r->fetch(PDO::FETCH_ASSOC)) {
	echo '<option value="'.checkparam($rows['onvan']).'" >'.checkparam($rows['onvan']).'</option>';
	
}
               ?>
      </select></td>
    <td><label for="hesab"></label>
      <select name="hesab" id="hesab">
                 
                   <?php 
              $r=$conecct->query("select * from hesab" );
$i=0;
while ($rows = $r->fetch(PDO::FETCH_ASSOC)) {
	echo '<option value="'.checkparam($rows['onvan']).'" >'.checkparam($rows['onvan']).'</option>';
	
}
               ?>
      </select></td>
    <td><label for="fard"></label>
      <select name="fard" id="fard">
           <?php
             $r=$conecct->query("select * from afrad" );
$i=0;
while ($rows = $r->fetch(PDO::FETCH_ASSOC)) {
	echo '<option value="'.checkparam($rows['khanevadegi']).'" >'.checkparam($rows['khanevadegi']).'</option>';
	
}
               ?>
      </select></td>
  </tr>
  <tr>
    <td colspan="6"><input type="submit" name="sabt" id="sabt" value="ثبت هزینه جدید" /></td>
    </tr>
    </form>
  <tr>
    <td>تاریخ</td>
    <td>مبلغ</td>
    <td>مبلغ به حروف</td>
    <td>دسته</td>
     <td>حساب</td>
    <td>فرد مربوطه</td>
    
  </tr>
  <?php 
  if (isset($_GET['at'])){
		$nnp=(checkGetParam($_GET['at'])-1)*20;
$r =$conecct->prepare("select * from hazine where nooe=1  limit ?,20");
$r->bindValue(1,$nnp, PDO::PARAM_INT);$r->execute();
	}
	else
			$r=$conecct->query("select * from hazine where nooe=1 limit 0,20");
  while ($rows2=$r->fetch(PDO::FETCH_ASSOC  )) {
	  
	  echo " <tr>
    <td>".checkparam($rows2['tarikh'])."</td>
    <td>".checkparam($rows2['mablagh'])."</td>
    <td>".checkparam($rows2['mablaghbehorof'])."</td>
    <td>".checkparam($rows2['dasteid'])."</td>
	<td>".checkparam($rows2['hesabid'])."</td>
    <td>".checkparam($rows2['fard'])."</td>
	
    
  </tr>";
	  
	  
  }
  
  
  
  ?>
  
</table>
</form>



<?php 
	if (isset($_GET['at']))
	echo '<p>صفحه ی '. $_GET['at'] .'</p>';




	if (isset($_GET['at']))
	echo 'صفحه ی '. $_GET['at'];

	$tedadr=$conecct->query("select * from hazine where nooe=1 ");

	
		$n= $tedadr->rowCount();
$pages=ceil($n/20);	

$radifs=ceil($pages/10);
$tah=$pages;
$cradif=1;
$cpage=1;
$tah=$pages;

if (isset($_GET['at'])){
$cpage=checkGetParam($_GET['at']);
$cradif=ceil($cpage/10);

if ($cradif<$radifs){
	$tah=$cradif*10;
}
else {
	$tah=$pages;
}
	
}

if ($cradif<$radifs && $cradif>1){
		echo "<a class='paging' href=?at=".((($cradif-1)*10)+1)."> <-- قبلی  </a>    "  ;		
	}
for ($i=$cradif ; $i<=$tah ; $i++ )
{
if ( isset($_GET['cat']))
{
	
echo "<a class='paging' href=?cat=".checkGetParam($_GET['cat'])."&at=".$i ."> ".($i) ."</a> |  "  ;	

}
else 
	echo "<a class='paging' href=?at=".$i ."> ".($i) ."</a> |  "  ;
}
	if ($cradif<$radifs){
		echo "<a class='paging' href=?at=".((($cradif+1)*10)+1)."> ادامه --> </a>    "  ;
	
		
	}

?>
<div class="wpcf7-response-output wpcf7-display-none"></div></div>

</div></div>
<div class="post_bottom"></div>
</div>


</div><!--Left -->

</div>
<div class="content_bottom"></div>
</div><!--Conetnt -->

<div class="footer">
<div class="footer_right"></div>
<div class="footer_body"><div class="text"><center>
کلیه حقوق مادی و معنوی این وب سایت برای شرکت پیشدار محفوظ می باشد.<br>
</center>
</div></div>
<div class="footer_left"></div>
</div>  

<div class="clr"></div>



</div><!--Middle -->
</div>
</body>
</html>
