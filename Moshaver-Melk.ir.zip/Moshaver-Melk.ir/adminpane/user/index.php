<?php 
 ob_start();
session_start();
if ( $_SESSION['adm']!=1 )
 header ("location:../../adminlogin.php");
echo $_SESSION['usermodir'];
include '../../func/connect2.php' ;
$result=$conecct->prepare("select * from admins where username=? ");
$result->bindValue(1,$_SESSION['usermodir']);
$result->execute();
$rr=$result->fetch(PDO::FETCH_ASSOC);
 if ($rr['sathdastras']>1)
 header ("location:../index.php?da=1");
$re=$conecct->query("select * from user");
$num=$re->rowCount();$num=$num+5;
for ($i=1 ; $i<=$num ; $i++){
if (isset($_POST["c".$i])){ 
$result1=$conecct->prepare("select * from user where userid=? ");
$result1->bindValue(1,$_POST["c".$i]);
$result1->execute();
$r=$result1->fetch(PDO::FETCH_ASSOC);
$re=$conecct->prepare("delete from product where shparvande=?");
$re->bindValue(1,$r['shomareparvande']);
$re->execute();
$result=$conecct->prepare("delete from user where userid=? ");
$result->bindValue(1,$_POST["c".$i]);
$result->execute();
}
}
?>
<head>
<title>پنل مدیر</title>

	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />	
	<style type="text/css" media="screen">
		@import url(../../style.css );
		@import url(../../tab.css );
	</style>
 <script src="../../js/jquery-1.4.2.min.js" type="text/javascript"></script>
<script src="../../js/jcarousellite_1.0.1c4.js" type="text/javascript"></script>
<script type="text/javascript" src="../../js/01.js"></script>
<script type="text/javascript" src="../../js/02.js"></script>
<script type="text/javascript" src="../../js/03.js"></script>
<script type="text/javascript" src="../../js/general.js"></script>
<script type="text/javascript">
function getElementsByClassName(className, tag, elm){
	var testClass = new RegExp("(^|\\s)" + className + "(\\s|$)");
	var tag = tag || "*";
	var elm = elm || document;
	var elements = (tag == "*" && elm.all)? elm.all : elm.getElementsByTagName(tag);
	var returnElements = [];
	var current;
	var length = elements.length;
	for(var i=0; i<length; i++){
		current = elements[i];
		if(testClass.test(current.className)){
			returnElements.push(current);
		}
	}
	return returnElements;
}

function addClassName(elm, className){
    var currentClass = elm.className;
    if(!new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i").test(currentClass)){
        elm.className = currentClass + ((currentClass.length > 0)? " " : "") + className;
    }
    return elm.className;
}

function removeClassName(elm, className){
    var classToRemove = new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i");
    elm.className = elm.className.replace(classToRemove, "").replace(/^\s+|\s+$/g, "");
    return elm.className;
}

function activateThisColumn(column) {
	var table = document.getElementById('pricetable');
	
	// first, remove the 'on' class from all other th's
	var ths = table.getElementsByTagName('th');
	for (var g=0; g<ths.length; g++) {
		removeClassName(ths[g], 'on');
	}
	// then, remove the 'on' class from all other td's
	var tds = table.getElementsByTagName('td');
	for (var m=0; m<tds.length; m++) {
		removeClassName(tds[m], 'on');
	}
	
	// now, add the class 'on' to the selected th
	var newths = getElementsByClassName(column, 'th', table);
	for (var h=0; h<newths.length; h++) {
		addClassName(newths[h], 'on');
	}
	// and finally, add the class 'on' to the selected td
	var newtds = getElementsByClassName(column, 'td', table);
	for (var i=0; i<newtds.length; i++) {
		addClassName(newtds[i], 'on');
	}
}
</script>
</head>
<body>
<div class="top"></div>
<div class="base">
<div class="middle">
<div class="logo">&nbsp; </div>
<div class="topmenu">
<div class="right"></div>
<div class="body">
<ul id="iconbar">
<li class="home"><a href="../index.php">صفحه اصلی مدیر </a></li>
<li><a href="../adminlogout.php">خروج</a></li>
</ul>
</div>
<div class="left">
</div><!--Top Menu -->
<div class="content">
<div class="content_top"></div>
<div class="content_bg">
<div id="right2">
		<div class="about"><div class="about_top"></div><div class="about_body">		<div class="menu_title"><h6> دسترسی ها </h6></div><div class="text">		<ul>
			
        <li><a href="../product/" title="تغییر آدرس سرور سوییس">مدیریت آگهی ها</a></li>
        				<li><a href="../order/" title="ساکس رایگان">مدیریت سفارشات</a></li>
				<li><a href="../user/" title="ساکس رایگان">مدیریت کاربران</a></li>
                	<li><a href="../about.php" title="ساکس رایگان">مدیریت اطلاعات</a></li>
                                    	<li><a href="../slider.php" title="ساکس رایگان">مدیریت تصاویر</a></li>
				</ul>
		</div></div><div class="about_bottom"></div></div><!--Menu -->
</div><!--Right -->
<div id="left2">
<div class="post">
<div class="post_top">
  <h2>مدیریت کاربران</h2></div>
<div class="post_body">
<div class="text">
<div class="wpcf7" id="wpcf7-f16-p17-o1"><form action="" method="post" >
<table width="100%" border="1">
  <tr>
    <td width="23%">آیدی کاربر</td>
    <td width="19%">تعداد آگهی ها</td>
        <td width="19%">شماره پرونده</td>
    <td width="19%">آخرین ورود</td>
    <td width="16%">مشخصات بیشتر</td>
    <td width="23%"><input type="submit" name="button" id="button" value="حذف موارد انتخابی">
      </td>
  </tr>
  <?php 
	if (isset($_GET['at'])){
		$nnp=(checkGetParam($_GET['at'])-1)*20;
$r =$conecct->prepare("select * from user limit ?,20");
$r->bindValue(1,$nnp, PDO::PARAM_INT);$r->execute();
	}
	else
			$r=$conecct->query("select * from user limit 0,20");
  $i=1;
  while ($rows=$r->fetch(PDO::FETCH_ASSOC)){
	  
	     $result3=$conecct->prepare("select * from user where shomareparvande=?");
		 $result3->bindValue(1,$rows['shomareparvande']);
		 $result3->execute();
		  echo " <tr> 
    <td>".checkparam($rows['userid'])."</td>
	    <td>".checkparam($result3->rowCount())."</td>
	    <td>".checkparam($rows['shomareparvande'])."</td>
    <td>".checkparam($rows['lastlogin'])."</td>
		 <td><a href=kamel.php?id=".checkparam($rows['shomareparvande'])." >مشاهده</a></td>
	 <td>      <input name='c".$i++."' type='checkbox' id='checkbx' value='".$rows['userid']."'>
</td>";


  }
	?>
 </table>
</form>
<p>&nbsp;</p>
<?php 
	if (isset($_GET['at']))
	echo 'صفحه ی '. $_GET['at'];
	echo '<p>&nbsp;</p>';
	$tedadr=$conecct->query("select * from user ");

	
		$n= $tedadr->rowCount();
$pages=ceil($n/20);	

$radifs=ceil($pages/10);
$tah=$pages;
$cradif=1;
$cpage=1;
$tah=$pages;

if (isset($_GET['at'])){
$cpage=checkGetParam($_GET['at']);
$cradif=ceil($cpage/10);

if ($cradif<$radifs){
	$tah=$cradif*10;
}
else {
	$tah=$pages;
}
	
}

if ($cradif<$radifs && $cradif>1){
		echo "<a class='paging' href=?at=".((($cradif-1)*10)+1)."> <-- قبلی  </a>    "  ;		
	}
for ($i=$cradif ; $i<=$tah ; $i++ )
{
if ( isset($_GET['cat']))
{
	
echo "<a class='paging' href=?cat=".checkGetParam($_GET['cat'])."&at=".$i ."> ".($i) ."</a> |  "  ;	

}
else 
	echo "<a class='paging' href=?at=".$i ."> ".($i) ."</a> |  "  ;
}
	if ($cradif<$radifs){
		echo "<a class='paging' href=?at=".((($cradif+1)*10)+1)."> ادامه --> </a>    "  ;
		
	}

?>
<div class="wpcf7-response-output wpcf7-display-none">
  </div></div>
</div></div>
<div class="post_bottom"></div>
</div>
</div><!--Left -->
</div>
<div class="content_bottom"></div>
</div><!--Conetnt -->
<div class="footer">
<div class="footer_right"></div>
<div class="footer_body"><div class="text"><center>
کلیه حقوق مادی و معنوی این وب سایت برای شرکت پیشدار محفوظ می باشد.<br>
</center>
</div></div>
<div class="footer_left"></div>
</div>  
<div class="clr"></div>
</div><!--Middle -->
</div><!--base -->
</body>
</html>
