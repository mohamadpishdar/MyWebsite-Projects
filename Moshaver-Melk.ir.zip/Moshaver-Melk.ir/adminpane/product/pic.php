<?php 
include '../../func/connect2.php' ;

$id = checkGetParam($_GET['id']);



if (isset($id)){
	 
	$query="select * from product where productid =?";
	$result=$conecct->prepare($query);
	$result->bindValue(1,$id);$result->execute();
	$rows=$result->fetch(PDO::FETCH_ASSOC);
	if ( $result->rowCount()==1 ){
	exit($rows["ax"]);
	}
}
?>