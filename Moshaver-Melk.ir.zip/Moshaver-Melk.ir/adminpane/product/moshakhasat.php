<?php 
ob_start();
session_start();
if ( $_SESSION['adm']!=1)
 header ("location:../../adminlogin.php");
echo $_SESSION['usermodir'];
include '../../func/connect2.php' ;
$result=$conecct->prepare("select * from admins where username=? ");
$result->bindValue(1,$_SESSION['usermodir']);
$result->execute();
$rr=$result->fetch(PDO::FETCH_ASSOC);
 if ($rr['sathdastras']>1)
 header ("location:../index.php?da=1");
include '../../func/funcs.php';
$mess="متن پیام";
if (isset($_POST['sabt']) && $_POST['payam']!='')
$mess='پیام شما با موفقیت ثبت گردید';
if (isset($_POST['exit'])){
header('location:taeed.php');
}
?>
<head>
  <script src="../../sliderengine2/jquery.js"></script>
    <script src="../../sliderengine2/amazingslider.js"></script>
    <link rel="stylesheet" type="text/css" href="../../sliderengine2/amazingslider-1.css">
    <script src="../../sliderengine2/initslider-1.js"></script>
<title>مشخصات کامل ملک</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
 <style type="text/css" media="screen">
		@import url(../../style.css );
		@import url(../../tab.css );
	body,td,th {
	color: #000;
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
}
   .middle .topmenu .content .content_bg .post .post_body table tr td p {
	text-align: right;
}
 .middle .topmenu .content .content_bg .post .post_body table tr td {
	text-align: right;
}
 </style>
<script src="js/jcarousellite_1.0.1c4.js" type="text/javascript"></script>
<script type="text/javascript" src="../../js/01.js"></script>
<script type="text/javascript" src="../../js/02.js"></script>
<script type="text/javascript" src="../../js/03.js"></script>
<script type="text/javascript" src="../../js/general.js"></script>
<script type="text/javascript">
function getElementsByClassName(className, tag, elm){
	var testClass = new RegExp("(^|\\s)" + className + "(\\s|$)");
	var tag = tag || "*";
	var elm = elm || document;
	var elements = (tag == "*" && elm.all)? elm.all : elm.getElementsByTagName(tag);
	var returnElements = [];
	var current;
	var length = elements.length;
	for(var i=0; i<length; i++){
		current = elements[i];
		if(testClass.test(current.className)){
			returnElements.push(current);
		}
	}
	return returnElements;
}

function addClassName(elm, className){
    var currentClass = elm.className;
    if(!new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i").test(currentClass)){
        elm.className = currentClass + ((currentClass.length > 0)? " " : "") + className;
    }
    return elm.className;
}

function removeClassName(elm, className){
    var classToRemove = new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i");
    elm.className = elm.className.replace(classToRemove, "").replace(/^\s+|\s+$/g, "");
    return elm.className;
}

function activateThisColumn(column) {
	var table = document.getElementById('pricetable');
	
	// first, remove the 'on' class from all other th's
	var ths = table.getElementsByTagName('th');
	for (var g=0; g<ths.length; g++) {
		removeClassName(ths[g], 'on');
	}
	// then, remove the 'on' class from all other td's
	var tds = table.getElementsByTagName('td');
	for (var m=0; m<tds.length; m++) {
		removeClassName(tds[m], 'on');
	}
	
	// now, add the class 'on' to the selected th
	var newths = getElementsByClassName(column, 'th', table);
	for (var h=0; h<newths.length; h++) {
		addClassName(newths[h], 'on');
	}
	// and finally, add the class 'on' to the selected td
	var newtds = getElementsByClassName(column, 'td', table);
	for (var i=0; i<newtds.length; i++) {
		addClassName(newtds[i], 'on');
	}
}
</script>
</head>
<body>
<div class="top"></div>
<div class="base">
<div class="middle">
<div class="logo">&nbsp;  
</div>
<div class="right"></div>

<div class="content">
<div class="content_top"></div>
<div class="content_bg">
<form action="" method="post" id="form3" name="form3" >
<input type="submit" name="exit" id="exit" value="بازگشت به صفحه مدیریت آگهی های تایید نشده"  /></form>
<div class="box_bottom"></div>
<!--Customers box -->
</div><!--Right -->

<?php 

$id=checkGetParam($_GET['id']);
$result1=$conecct->prepare("select * from product where productid=?");
$result1->bindValue(1,$id);
$result1->execute();
$row1=$result1->fetch(PDO::FETCH_ASSOC);
?>
  <table width="100%" border="1" bgcolor="#CCCCCC">
    <tr>
      <td colspan="4"><form name="form1" method="post" action="">
        <input type="submit" name="taeed" id="taeed" value="تایید آگهی" class="dddd">
      </form></td>
      </tr>
    <tr>
      <td width="20%">آدرس کامل</td>
      <td colspan="3"><?php echo checkparam( $row1['address']) ?></td>
      </tr>
    <tr>
      <td>زیربنا به متر مربع </td>
      <td width="30%"><?php echo  checkparam($row1['zirbana']) ?></td>
      <td width="27%">نوع معامله</td>
      <td width="23%"><?php echo  checkparam($row1['moamele']) ?></td>
    </tr>
    <tr>
      <td>تعداد اتاق خواب</td>
      <td><?php echo checkparam( $row1['otagh']) ?></td>
      <td>نوع سند</td>
      <td><?php echo checkparam( $row1['sanad']) ?></td>
    </tr>
    <tr>
      <td>سال ساخت</td>
      <td><?php echo  checkparam($row1['chandsale']) ?></td>
      <td>دانگ</td>
      <td><?php echo  checkparam($row1['dang']) ?></td>
    </tr>
    <tr>
      <td>آسانسور</td>
      <td><?php echo  checkparam($row1['asansor']) ?></td>
      <td>طبقه</td>
      <td><?php echo checkparam( $row1['tabaghe']) ?></td>
    </tr>
    <tr>
      <td>سرویس بهداشتی</td>
      <td><?php echo checkparam( $row1['dastshooi']) ?></td>
      <td>واحد</td>
      <td><?php echo checkparam( $row1['vahed']) ?></td>
    </tr>
    <tr>
      <td>پارکینگ</td>
      <td><?php echo checkparam( $row1['parking']) ?></td>
      <td>سیستم گرمایش</td>
      <td><?php echo checkparam( $row1['garmayesh']) ?></td>
    </tr>
    <tr>
      <td>بالکن</td>
      <td><?php echo checkparam( $row1['balkon']) ?></td>
      <td>کف</td>
      <td><?php echo checkparam( $row1['kaf']) ?></td>
    </tr>
    <tr>
      <td>آشپزخانه</td>
      <td><?php echo checkparam( $row1['ashpazkhane']) ?></td>
      <td>جهت ملک</td>
      <td><?php echo checkparam( $row1['jahat']) ?></td>
    </tr>
    <tr>
      <td>کابینت</td>
      <td><?php echo checkparam( $row1['kabinet']) ?></td>
      <td>دیوار ملک</td>
      <td><?php echo  checkparam($row1['divar']) ?></td>
    </tr>
    <tr>
      <td>قیمت کل(نوع معامله=فروش)،قیمت رهن(نوع معامله:رهن)،قیمت اجاره(نوع معامله=اجاره)،قیمت رهن(نوع معامله=رهن واجاره</td>
      <td><?php echo  checkparam($row1['gheymat']) ?></td>
      <td>قیمت متری (نوع معامله=فروش )،قیمت اجاره (نوع معامله =رهن واجاره)،سایر مدت قرارداد به سال</td>
      <td><?php echo  checkparam($row1['metri']) ?></td>
    </tr>
    <tr>
      <td>سیستم سرمایش</td>
      <td><?php echo  checkparam($row1['cooler']) ?></td>
      <td>شماره آگهی</td>
      <td><h1><?php echo  checkparam($row1['productid']) ?></h1></td>
    </tr>
    <tr>
      <td>امکانات</td>
      <td colspan="3"><?php echo  checkparam($row1['abbarghgaz']) ?></td>
    </tr>
    <tr>
      <td>توضیحات</td>
      <td colspan="3"><p><?php echo  $row1['tozih'] ?></p>
        </td>
    </tr>
    <tr bgcolor="#00CCCC">
      <td colspan="1">
        پیام توسط
        </td>
      <td colspan="3">
        <?php echo $mess; ?>
        </td>
    </tr>
      <tr>
      <td>
      <?php 
	  
	  $re4=$conecct->prepare("update product set payam=0 where productid=?");
$re4->bindValue(1,checkparam($row1['productid']));$re4->execute();
	  $re=$conecct->prepare("select * from mokatebe where shparvande=? and productid=?");
	  $re->bindValue(1,$row1['shparvande']);$re->bindValue(2,$row1['productid']);
	  $re->execute();
	  while ($rows3=$re->fetch(PDO::FETCH_ASSOC)){
		  echo '<tr><td bgcolor="#CC3399" >'.checkparam($rows3['tavasot']).' </td><td colspan="3">'.checkParam($rows3['matn']).'</td></tr>';
	  }
		    if (isset($_POST['sabt']) && $_POST['payam']!=''){
				$re4=$conecct->prepare("update product set payam=1 where productid=?");
$re4->bindValue(1,$row1['productid']);$re4->execute();
		  $mess="پیام شما با موفقیت ثبت گردید";
		$re2=$conecct->prepare("INSERT INTO `shopdb`.`mokatebe` (`shparvande`, `productid`, `matn`,`tavasot`) VALUES (?, ?, ?,?);");  
		$re2->bindValue(1,$row1['shparvande']);$re2->bindValue(2,$row1['productid']);$re2->bindValue(3,$_POST['payam'] );$re2->bindValue(4,' مدیر تایید سایت: '.$rr['name'] );
		$re2->execute();

		  
	  }
	  	  if (isset($_POST['taeed'])){
$re1=$conecct->prepare("update product set taeed=1 where productid=?");
$re1->bindValue(1,$row1['productid']);$re1->execute();
echo '<script language="javascript">alert("آگهی مورد نظر تایید گردید");</script>';
 }

?>
      </td>
      </tr>
      <tr>
      <td colspan="5">
      <form method="post" action="" id="form2" name="form2">
        <p>
          <label for="payam"></label>
          <textarea name="payam" id="payam" cols="85" rows="5" placeholder="اگر پیامی برای آگهی دهنده دارید اینجا بنویسید و بر روی دکمه ی ثبت کلیک نمایید ...." ></textarea>
        </p>
        <p>
          <input name="sabt" type="submit" class="dddd" id="sabt" value="ثبت پیام">
        </p>
      </form></td>
      </tr>
   
    <tr>
      <td colspan="5">    
     <div id="amazingslider-wrapper-1" style="display:block;position:relative;max-width:600px:0px auto 6px;">
        <div id="amazingslider-1" style="display:block;position:relative;margin:0 auto;">
            <ul class="amazingslider-slides" style="display:none;">
               
                <li><img  src="../../pic.php?id=<?php echo $id ?>  alt="images"/ >
                </li>
                <li><img src="../../pic2.php?id=<?php echo $id ?> alt="images"/>
                </li>
                
            </ul>
       </div>   </div>  
       </td>   
      </tr>
      
  </table>
</div>
<div class="content_bottom">
  
</div>
</div><!--Conetnt -->
  
</body>
</html>