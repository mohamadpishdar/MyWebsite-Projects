 ﻿<?php
 ob_start();
session_start();
if ( $_SESSION['adm']!=1)
 header ("location:../../adminlogin.php");
echo $_SESSION['usermodir'];
include '../../func/connect2.php' ;
$result=$conecct->prepare("select * from admins where username=? ");
$result->bindValue(1,$_SESSION['usermodir']);
$result->execute();
$rr=$result->fetch(PDO::FETCH_ASSOC);
 if ($rr['sathdastras']>1)
 header ("location:../index.php?da=1");
include '../../func/funcs.php';
$r=$conecct->query("select * from news");
$num=$r->rowCount();$num=$num+5;
for ($i=1 ; $i<=$num ; $i++){
if (isset($_POST["c".$i])){ 
$result=$conecct->prepare("delete from news where newsid=? ");
$result->bindValue(1,$_POST["c".$i]);
$result->execute();}
}
if (isset($_POST['onvan'])){
$re=$conecct->prepare("INSERT INTO `shopdb`.`news` (`onvan`, `matn`, `newsid`) VALUES (?, ?, NULL);");
	$re->bindValue(1,$_POST['onvan']);	$re->bindValue(2,$_POST['matn']);
$re->execute();
}
?>
</script>
<script language="javascript" src="../../ckeditor/ckeditor.js"></script>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>مدیریت اخبار</title>

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
	<style type="text/css" media="screen">
		@import url(../../style.css );
		@import url(../../tab.css );
	.middle .topmenu .content .content_bg #left2 .post .post_body .text #wpcf7-f16-p17-o1 .wpcf7-form table {
	color: #000;
	text-align: center;
}
    .base .middle .topmenu .content .content_bg #left2 .post .post_body .text table tr td {
	text-align: center;
}
    .base .middle .topmenu .content .content_bg #left2 .post .post_body .text table tr td #form1 table tr td {
	text-align: center;
}
    body,td,th {
	color: #000;
}
    </style>
<script language="javascript">
function check (x1 ,x2  ) 
{
if (x1=='' ){
alert("لطفا عنوان خبر را وارد کنید");
document.getElementById('onvan').focus();
return false ;
}
if (x2=='' ){
alert("لطفا متن خبر را وارد کنید");
document.getElementById('matn').focus();
return false ;
}

else 
return true ;

}
</script>

 <script src="../../js/jquery-1.4.2.min.js" type="text/javascript"></script>
<script src="../../js/jcarousellite_1.0.1c4.js" type="text/javascript"></script>
<script type="text/javascript" src="../../js/01.js"></script>
<script type="text/javascript" src="../../js/02.js"></script>
<script type="text/javascript" src="../../js/03.js"></script>
<script type="text/javascript" src="../../js/general.js"></script>
<script type="text/javascript">
function getElementsByClassName(className, tag, elm){
	var testClass = new RegExp("(^|\\s)" + className + "(\\s|$)");
	var tag = tag || "*";
	var elm = elm || document;
	var elements = (tag == "*" && elm.all)? elm.all : elm.getElementsByTagName(tag);
	var returnElements = [];
	var current;
	var length = elements.length;
	for(var i=0; i<length; i++){
		current = elements[i];
		if(testClass.test(current.className)){
			returnElements.push(current);
		}
	}
	return returnElements;
}

function addClassName(elm, className){
    var currentClass = elm.className;
    if(!new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i").test(currentClass)){
        elm.className = currentClass + ((currentClass.length > 0)? " " : "") + className;
    }
    return elm.className;
}

function removeClassName(elm, className){
    var classToRemove = new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i");
    elm.className = elm.className.replace(classToRemove, "").replace(/^\s+|\s+$/g, "");
    return elm.className;
}

function activateThisColumn(column) {
	var table = document.getElementById('pricetable');
	
	// first, remove the 'on' class from all other th's
	var ths = table.getElementsByTagName('th');
	for (var g=0; g<ths.length; g++) {
		removeClassName(ths[g], 'on');
	}
	// then, remove the 'on' class from all other td's
	var tds = table.getElementsByTagName('td');
	for (var m=0; m<tds.length; m++) {
		removeClassName(tds[m], 'on');
	}
	
	// now, add the class 'on' to the selected th
	var newths = getElementsByClassName(column, 'th', table);
	for (var h=0; h<newths.length; h++) {
		addClassName(newths[h], 'on');
	}
	// and finally, add the class 'on' to the selected td
	var newtds = getElementsByClassName(column, 'td', table);
	for (var i=0; i<newtds.length; i++) {
		addClassName(newtds[i], 'on');
	}
}
</script>
</head>
<body>
<div class="top"></div>
<div class="base">
<div class="middle">
<div class="logo">&nbsp; </div>
<div class="topmenu">
<div class="right"></div>
<div class="body">
<ul id="iconbar">
<li class="home"><a href="../index.php">صفحه اصلی مدیر </a></li>
<li><a href="../adminlogout.php">خروج</a></li>
</ul>
</div>
<div class="left">
</div><!--Top Menu -->
<div class="content">
<div class="content_top"></div>
<div class="content_bg">
<div id="right2">
		<div class="about"><div class="about_top"></div><div class="about_body">		<div class="menu_title"><h6>نوشته‌های تازه </h6></div><div class="text">		<ul>
				<li><a href="../product/" title="تغییر آدرس سرور سوییس">مدیریت آگهی ها</a></li>
				<li><a href="../cat/" title="تغییر آدرس سرور سوییس">مدیریت دسته ها</a></li>
				<li><a href="../user/" title="ساکس رایگان">مدیریت کاربران</a></li>
                	<li><a href="../about.php" title="ساکس رایگان">مدیریت اطلاعات</a></li>
                                    	<li><a href="../slider.php" title="ساکس رایگان">مدیریت تصاویر</a></li>
				</ul>
		</div></div><div class="about_bottom"></div></div><!--Menu -->
</div><!--Right -->
<div id="left2">
<div class="post">
<div class="post_top" id="daste">
  <h2><a href="#">مدیریت اخبار</a></h2></div>
<div class="post_body">
<div class="text">
<table width="100%" height="332" border="1" cellpadding="2" cellspacing="0">
  <tr>
    <td colspan="5" bgcolor="#CCCCCC"><form id="form1"   name="form1" method="post"  enctype="multipart/form-data"  onsubmit="return check(onvan.value , matn.value )"  action="">
      <table width="100%" border="1">
        <tr>
          <td width="50%">عنوان خبر </td>
          <td width="50%"><label for="onvan"></label>
            <input type="text" name="onvan" id="onvan"></td>
        </tr>
        <tr>
          <td>متن خبر </td>
          <td><label for="matn"></label>
            <textarea name="matn" id="matn" cols="45" rows="5"></textarea></td>
        </tr>
        <tr>
          <td colspan="2"><input type="submit" name="button" id="button" value="ثبت خبر در سایت"></td>
          </tr>
      </table>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
    </form>
      <p>&nbsp;</p></td>
      <form action="" method="post">
    </tr>
    <form action="" method="post">
  <tr>
    <td width="6%" height="50" bgcolor="#CC66CC">ردیف</td>
    <td width="17%" height="50" bgcolor="#CC66CC">عنوان خبر</td>
    <td width="59%" height="50" bgcolor="#CC66CC">متن خبر</td>
    <td width="18%" height="50" bgcolor="#CC66CC"><input type="submit" name="button" id="button" value="حذف موارد انتخابی"></td>
    </tr>
  <?php 
if (isset($_GET['at'])){
		$nnp=(checkGetParam($_GET['at'])-1)*20;
$r =$conecct->prepare("select * from news  limit ?,20");
$r->bindValue(1,$nnp, PDO::PARAM_INT);$r->execute();
	}
	else
			$r=$conecct->query("select * from news  limit 0,20");
$i=0;$o=1;
while ($rows = $r->fetch(PDO::FETCH_ASSOC)) {
echo "<tr>";
 echo "<td>".++$i."</td> " ;
	 echo "<td>".checkparam($rows['onvan'])."</td> " ;
	 	echo "<td>".checkparam($rows['matn'])."</td> " ;
		echo "<td> <input name='c".$o++."' type='checkbox' id='checkbx' value='".$rows['newsid']."'></td> " ;
	echo "<tr/> " ;

}
  ?>
</table>
</form>
<?php 
	if (isset($_GET['at']))
	echo 'صفحه ی '. $_GET['at'];
	echo '<p>&nbsp;</p>';
	$tedadr=$conecct->query("select * from news ");

	
		$n= $tedadr->rowCount();
$pages=ceil($n/20);	

$radifs=ceil($pages/10);
$tah=$pages;
$cradif=1;
$cpage=1;
$tah=$pages;

if (isset($_GET['at'])){
$cpage=checkGetParam($_GET['at']);
$cradif=ceil($cpage/10);

if ($cradif<$radifs){
	$tah=$cradif*10;
}
else {
	$tah=$pages;
}
	
}

if ($cradif<$radifs && $cradif>1){
		echo "<a class='paging' href=?at=".((($cradif-1)*10)+1)."> <-- قبلی  </a>    "  ;		
	}
for ($i=$cradif ; $i<=$tah ; $i++ )
{
if ( isset($_GET['cat']))
{
	
echo "<a class='paging' href=?cat=".checkGetParam($_GET['cat'])."&at=".$i ."> ".($i) ."</a> |  "  ;	

}
else 
	echo "<a class='paging' href=?at=".$i ."> ".($i) ."</a> |  "  ;
}
	if ($cradif<$radifs){
		echo "<a class='paging' href=?at=".((($cradif+1)*10)+1)."> ادامه --> </a>    "  ;
		
	}

?>
<div class="wpcf7-response-output wpcf7-display-none"></div></form></div>

</div></div>
<div class="post_bottom"></div>
</div>
</div><!--Left -->
</div>
<div class="content_bottom"></div>
</div><!--Conetnt -->
<div class="footer">
<div class="footer_right"></div>
<div class="footer_body"><div class="text"><center>
کلیه حقوق مادی و معنوی این وب سایت برای شرکت پیشدار محفوظ می باشد.<br>
</center>
</div></div>
<div class="footer_left"></div>
</div>  
<div class="clr"></div>
</div><!--Middle -->
</div><!--base -->
</body>
</html>
