<?php 
ob_start();
session_start();
include '../func/connect2.php' ;
$id = checkGetParam($_GET['id']);
if (isset($id)){
	 $re=$conecct->prepare("select * from admins where  username=?");
	 $re->bindValue(1,$_SESSION['usermodir']);
     $re->execute();
	$rows=$re->fetch(PDO::FETCH_ASSOC);
	if ( $re->rowCount()== 1  ){
	exit($rows["ax"]);
	}
}
?>