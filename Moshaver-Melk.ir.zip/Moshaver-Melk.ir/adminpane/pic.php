<?php 

include '../func/connect2.php' ;

$id = checkGetParam($_GET['id']);



if (isset($id)){
	
	 $re=$conecct->prepare("select * from slider where id =?");
	 $re->bindValue(1,$id);
     $re->execute();
	$rows=$re->fetch(PDO::FETCH_ASSOC);
	if ( $re->rowCount()== 1  ){
	exit($rows["ax"]);
	}
}
?>