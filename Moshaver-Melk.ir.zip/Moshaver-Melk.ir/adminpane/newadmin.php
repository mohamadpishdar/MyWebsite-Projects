<?php 
 ob_start();
session_start();
include '../func/funcs.php';
if ( $_SESSION['adm']!=1)
 header ("location:../adminlogin.php");
include '../func/connect2.php' ;
$result=$conecct->prepare("select * from admins where username=? ");
$result->bindValue(1,$_SESSION['usermodir']);
$result->execute();
$rr=$result->fetch(PDO::FETCH_ASSOC); 
 if ($rr['sathdastras']!=0)
 header ("location:index.php?da=1");
$payam=false ;
if (isset($_POST['button']) && $_POST['name']!='' && $_POST['pass1']!='' && $_POST['tahsilat']!=''  && $_POST['semat']!=''){$s1=$_FILES['tasvir']['size'];
	$t1=$_FILES['tasvir']['type'];
	if ($s1<200000 && $t1=='image/jpeg') {
	
	$n1=$_FILES['tasvir']['tmp_name'];
	$fp1=fopen($n1,'r');
	$pic1=fread($fp1,filesize($n1));
$payam=true;
$re=$conecct->prepare("INSERT INTO `shopdb`.`admins` (`username`, `pass`, `lastlogin`,`sathdastras` ,`ax`,`name`,`tahsilat`,`semat` , `lastexit`) VALUES (?,?,?,?,?,?,?,?,?)");
$re->bindValue(1,$_POST['user']);$re->bindValue(2,hash_value($_POST['pass1'] ));$re->bindValue(3,getCurentDate());$re->bindValue(4,$_POST['sath']);
$re->bindValue(5,$pic1);$re->bindValue(6,$_POST['name']);
$re->bindValue(7,$_POST['tahsilat']);$re->bindValue(8,$_POST['semat']);
$re->bindValue(9,getCurentDate());
$re->execute();
	}
	else {
		echo '<script language="javascript">alert("شما تصویری با حجم بالای 200 کیلو بایت و یا فرمت غیر jpeg انتخاب کرده اید")</script>';
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>ثبت مدیر جدید</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />	
	<style type="text/css" media="screen">
		@import url(../style.css );
		@import url(../tab.css );
	</style>
    <script language="javascript" >   
   function check ( x1,x2 ,x3,x4,x5,x6 ) 
{
if (x1=='' ){
alert("لطفا  نام کاربری را وارد کنید");
document.getElementById('user').focus();
return false ;
}	
	
if (x2=='' ){
alert("لطفا  کلمه ی عبور را وارد کنید");
document.getElementById('pass1').focus();
return false ;
}
if (x3!=x2 ){
alert("کلمه های عبور یکسان نیستند");
document.getElementById('pass1').focus();

return false ;
}
if (x4=='' ){
alert("لطفا تحصیلات را وارد نمایید");
document.getElementById('tahsilat').focus();

return false ;
}
if (x5=='' ){
alert("لطفا سمت را وارد نمایید");
document.getElementById('semat').focus();

return false ;
}
if (x6==''){
alert("لطفا تصویر را وارد نمایید");
document.getElementById('tasvir').focus();

return false ;
}
else 
return true ;

}
</script>
 <script src="../js/jquery-1.4.2.min.js" type="text/javascript"></script>
<script src="../js/jcarousellite_1.0.1c4.js" type="text/javascript"></script>
<script type="text/javascript" src="../js/01.js"></script>
<script type="text/javascript" src="../js/02.js"></script>
<script type="text/javascript" src="../js/03.js"></script>
<script type="text/javascript" src="../js/general.js"></script>
<script type="text/javascript">
function getElementsByClassName(className, tag, elm){
	var testClass = new RegExp("(^|\\s)" + className + "(\\s|$)");
	var tag = tag || "*";
	var elm = elm || document;
	var elements = (tag == "*" && elm.all)? elm.all : elm.getElementsByTagName(tag);
	var returnElements = [];
	var current;
	var length = elements.length;
	for(var i=0; i<length; i++){
		current = elements[i];
		if(testClass.test(current.className)){
			returnElements.push(current);
		}
	}
	return returnElements;
}

function addClassName(elm, className){
    var currentClass = elm.className;
    if(!new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i").test(currentClass)){
        elm.className = currentClass + ((currentClass.length > 0)? " " : "") + className;
    }
    return elm.className;
}

function removeClassName(elm, className){
    var classToRemove = new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i");
    elm.className = elm.className.replace(classToRemove, "").replace(/^\s+|\s+$/g, "");
    return elm.className;
}

function activateThisColumn(column) {
	var table = document.getElementById('pricetable');
	
	// first, remove the 'on' class from all other th's
	var ths = table.getElementsByTagName('th');
	for (var g=0; g<ths.length; g++) {
		removeClassName(ths[g], 'on');
	}
	// then, remove the 'on' class from all other td's
	var tds = table.getElementsByTagName('td');
	for (var m=0; m<tds.length; m++) {
		removeClassName(tds[m], 'on');
	}
	
	// now, add the class 'on' to the selected th
	var newths = getElementsByClassName(column, 'th', table);
	for (var h=0; h<newths.length; h++) {
		addClassName(newths[h], 'on');
	}
	// and finally, add the class 'on' to the selected td
	var newtds = getElementsByClassName(column, 'td', table);
	for (var i=0; i<newtds.length; i++) {
		addClassName(newtds[i], 'on');
	}
}
</script>
</head>
<body>
<div class="top"></div>
<div class="base">
<div class="middle">
<div class="logo">&nbsp; </div>
<div class="topmenu">
<div class="right"></div>
<div class="body">
<ul id="iconbar">
<li class="home"><a href="index.php">صفحه اصلی مدیر </a></li>
<li><a href="adminlogout.php">خروج</a></li>
</ul>
</div>
<div class="left">
</div><!--Top Menu -->
<div class="content">
<div class="content_top"></div>
<div class="content_bg">
<div id="right2">
		<div class="about"><div class="about_top"></div><div class="about_body">		<div class="menu_title"><h6> دسترسی ها </h6></div><div class="text">		<ul>
				<li><a href="cat/" title="تغییر آدرس سرور سوییس">مدیریت دسته ها</a></li>
				<li><a href="product/" title="سرور جدید از کشور هلند">مدیریت کالا ها </a></li>
				<li><a href="user/" title="ساکس رایگان">مدیریت کاربران</a></li>
				<li><a href="order/" title="ساکس رایگان">مدیریت سفارشات</a></li>
				</ul>
		</div></div><div class="about_bottom"></div></div><!--Menu -->
</div><!--Right -->
<div id="left2">

<div class="post">
<div class="post_top">
  <h2>ثبت مدیر جدید</h2></div>
<div class="post_body">
<form action="" method="post" enctype="multipart/form-data"  onsubmit="return check(user.value , pass1.value , pass2.value,tahsilat.value ,semat.value , tasvir.value)" >
  <table width="100%" border="1" class="text">
    <tr>
      <td colspan="8"><?php if ($payam==true)echo "مدیر جدید با موفقیت ثبت گردید"; ?></td>
      </tr>
    <tr>
      <td colspan="7">نام و نام خانوادگی</td>
      <td><label for="name"></label>
        <input type="text" name="name" id="name" /></td>
    </tr>
    <tr>
      <td colspan="7">کلمه ی کاربری مدیر جدید</td>
      <td width="196"><label for="pass1"></label>
        <input type="text" name="user" id="user" /></td>
    </tr>
    <tr>
      <td colspan="7">کلمه ی عبور مدیر جدید </td>
      <td><input type="text" name="pass1" id="pass1" /></td>
    </tr>
    <tr>
      <td colspan="7">تکرار کلمه ی عبور</td>
      <td><label for="pass2"></label>
        <input type="text" name="pass2" id="pass2" /></td>
    </tr>
    <tr>
      <td colspan="7">تحصیلات</td>
      <td><label for="tahsilat"></label>
        <input type="text" name="tahsilat" id="tahsilat" /></td>
    </tr>
    <tr>
      <td colspan="7">سمت</td>
      <td><label for="semat"></label>
        <input type="text" name="semat" id="semat" /></td>
    </tr>
    <tr>
      <td colspan="7">تصویر زیر 200 کیلو بایت فرمت jpeg</td>
      <td><label for="ax"></label>
        <input type="file" name="tasvir" id="tasvir" /></td>
    </tr>
    <tr>
      <td colspan="7">سطح دسترسی</td>
      <td><label for="sath"></label>
        <select name="sath" id="sath">
          <option>1</option>
          <option>2</option>
          <option>3</option>
          </select></td>
    </tr>
    <tr>
      <td colspan="8"><input class="dddd" type="submit" name="button"  id="button" value="ثبت" /></td>
    </tr>
    <tr>
      <td width="70">نام  و نام خانوادیی</td>
      <td width="43">نام کاربری</td>
      <td width="43">تحصیلات</td>
      <td width="29">سمت</td>
      <td width="72">سطح دسترسی</td>
      <td width="52">آخرین ورود</td>
      <td width="57">آخرین خروج</td>
      <td>تصویر</td>
      </tr>
      <?php 
	  $re1=$conecct->query("select * from admins");
	  while ($row=$re1->fetch(PDO::FETCH_ASSOC)) {
		  echo '  <tr>
      <td width="91">'.$row['name'].'</td>
      <td width="51">'.$row['username'].'</td>
      <td width="45">'.$row['tahsilat'].'</td>
      <td width="31">'.$row['semat'].'</td>
      <td width="86">'.$row['sathdastras'].'</td>
      <td width="64">'.$row['lastlogin'].'</td>
      <td width="67">'.$row['lastexit'].'</td>
<td ><img src=pic2.php?id='.checkparam($row['username']).'width=100 height=100/></td></tr>';
	  }
	  
	  ?>
      
  </table>
  </form>
</div>
<div class="post_bottom"></div>
</div>
</div><!--Left -->
</div>
<div class="content_bottom"></div>
</div><!--Conetnt -->
<div class="footer">
<div class="footer_right"></div>
<div class="footer_body"><div class="text"><center>
کلیه حقوق مادی و معنوی این وب سایت برای شرکت پیشدار محفوظ می باشد.<br>
</center>
</div></div>
<div class="footer_left"></div>
</div>  
<div class="clr"></div>
</div><!--Middle -->
</div>
</body>
</html>
