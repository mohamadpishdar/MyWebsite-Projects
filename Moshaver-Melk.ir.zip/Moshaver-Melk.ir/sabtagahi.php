<?php 
ob_start();
session_start();
?>
<script language="javascript" src="ckeditor/ckeditor.js"></script>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>ثبت آگهی </title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
	<style type="text/css" media="screen">
		@import url(style.css );
		@import url(tab.css );
	.middle .topmenu .content .content_bg #left2 .post .post_body .text #wpcf7-f16-p17-o1 .wpcf7-form table {
	color: #000;
	text-align: center;
}
    .base .middle .topmenu .content .content_bg #left2 .post .post_body .text table tr td {
	text-align: center;
}
    .base .middle .topmenu .content .content_bg #left2 .post .post_body .text table tr td #form1 table tr td {
	text-align: center;
}
    body,td,th {
	color: #000;
}
    </style>
<script language="javascript">
function check (x1 ,x2 ,x3 ,x4,x5,x6,x7,x8,x9,x10) 
{
if (x1=='' ){
alert("لطفا نام خود را وارد کنید");
document.getElementById('name').focus();
return false ;
}
if (x2=='' ){
alert("لطفا تعداد اتاق را وارد کنید");
document.getElementById('otagh').focus();
return false ;
}
if (x2>50 || x2<0 ){
alert("مقدار وارد شده برای اتاق صحیح نمی باشد");
document.getElementById('otagh').focus();
return false ;
}

if (x3=='' ){
alert("لطفا فقط سال ساخت را به وارد کنید");
document.getElementById('salesakht').focus();
return false ;
}

if (x3<1300 || x3>1400 ){
alert("مقدار وارد شده برای سال ساخت صحیح نمی باشد");
document.getElementById('salesakht').focus();
return false ;
}

if (x10==0 ){
alert("لطفا نوع معامله را مشخص نمایید");
document.getElementById('moamele').focus();

return false ;
}i
if (x4=='' ){
alert("لطفا  تعداد دانگ را وارد کنید");
document.getElementById('dang').focus();
return false ;
}

if (x4>6 || x4<0 ){
alert("مقدار وارد شده برای دانگ صحیح نمی باشد");
document.getElementById('dang').focus();
return false ;
}

if (x5=='' ){
alert("تصویر اول یا نمای ساختمان مشخص نشده است");
document.getElementById('ax1').focus();

return false ;
}
if (x6=='' ){
alert("تصویر دوم تصویری از داخل ساختمان مشخص نشده است");
document.getElementById('ax2').focus();

return false ;
}
if (x7=='' ){
alert("تصویر سوم تصویری از داخل ساختمان مشخص نشده است");
document.getElementById('ax3').focus();

return false ;
}
if (x8=='' ){
alert("لطفا زیر بنا را به متر مربع وارد نمایید ");
document.getElementById('zirbana').focus();

return false ;
}

if (x8<0){
alert("مقدار وارد شده برای زیر بنا صحیح نمی باشد ");
document.getElementById('zirbana').focus();

return false ;
}

if (x9=='' ){
alert("لطفا قیمت کل را وارد نمایید");
document.getElementById('gheymat').focus();

return false ;
}
if (x9<0 ){
alert("مقدار وارد شده برای قیمت صحیح نمی باشد");
document.getElementById('gheymat').focus();

return false ;
}

else 
return true ;

}
</script>
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript">


function pp () {
	
var moamele=$("#moamele").val();	
		$.post("ajax.php",{moamele:moamele},function(data){			
			$(".nama").html(data);			
		});	
		$.post("ajax.php",{moamele2:moamele},function(data){			
			$(".nama2").html(data);			
		});		
}



$(document).ready(function() {
$('#Loading').hide();    
});

function shahr_show(){
	
	var shahr=$("#shahr").val();	
		$.post("ajax.php",{shahr1:shahr},function(data){			
			$(".namayesh").html(data);			
		});		

	
}
function check_ax1(){	

var ax1 = $("#ax1")[0].files[0].size;
if ($("#ax1")[0].files[0].type!="image/jpeg"){
setTimeout("finishAjax('Info2', 'شما فایلی به جز عکس JPEG ر برای تصویر اول انتخاب کردید ')", 450);
}
if ( ax1>200000 ){	
$('#Loading').show();
$('#Info').fadeOut();
 $('#Loading').hide();
setTimeout("finishAjax('Info', 'تصویر انتخاب شده برای فیلد نمای ملک دارای حجم زیاد میباشد ')", 450);
}
}
function check_ax2(){
var ax1 = $("#ax2")[0].files[0].size;
if ($("#ax2")[0].files[0].type!="image/jpeg"){
setTimeout("finishAjax('Info2', 'شما فایلی به جز عکس JPEG را برای تصویر دوم انتخاب کردید ')", 450);
}
if ( ax1>200000 ){
$('#Loading2').show();
$('#Info2').fadeOut();
 $('#Loading2').hide();
setTimeout("finishAjax('Info2', 'تصویر انتخاب شده برای فیلد تصویر دوم دارای حجم زیاد میباشد ')", 450);
}
}
function check_ax3(){
var ax1 = $("#ax3")[0].files[0].size;
if ($("#ax3")[0].files[0].type!="image/jpeg"){
setTimeout("finishAjax('Info2', 'شما فایلی به جز عکس JPEG را برای تصویر سوم انتخاب کردید ')", 450);

}
if ( ax1>200000 ){

$('#Loading3').show();
$('#Info3').fadeOut();
 $('#Loading3').hide();

setTimeout("finishAjax('Info3', 'تصویر انتخاب شده برای فیلد تصویر سوم دارای حجم زیاد میباشد ')", 450);
}
}

function finishAjax(id, response){
$('#'+id).html(unescape(response));
$('#'+id).fadeIn(1000);
}
</script>   
 <script src="js/jquery-1.4.2.min.js" type="text/javascript"></script>
<script src="js/jcarousellite_1.0.1c4.js" type="text/javascript"></script>
<script type="text/javascript" src="js/01.js"></script>
<script type="text/javascript" src="js/02.js"></script>
<script type="text/javascript" src="js/03.js"></script>
<script type="text/javascript" src="js/general.js"></script>
<script type="text/javascript">
function getElementsByClassName(className, tag, elm){
	var testClass = new RegExp("(^|\\s)" + className + "(\\s|$)");
	var tag = tag || "*";
	var elm = elm || document;
	var elements = (tag == "*" && elm.all)? elm.all : elm.getElementsByTagName(tag);
	var returnElements = [];
	var current;
	var length = elements.length;
	for(var i=0; i<length; i++){
		current = elements[i];
		if(testClass.test(current.className)){
			returnElements.push(current);
		}
	}
	return returnElements;
}

function addClassName(elm, className){
    var currentClass = elm.className;
    if(!new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i").test(currentClass)){
        elm.className = currentClass + ((currentClass.length > 0)? " " : "") + className;
    }
    return elm.className;
}

function removeClassName(elm, className){
    var classToRemove = new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i");
    elm.className = elm.className.replace(classToRemove, "").replace(/^\s+|\s+$/g, "");
    return elm.className;
}

function activateThisColumn(column) {
	var table = document.getElementById('pricetable');
	
	// first, remove the 'on' class from all other th's
	var ths = table.getElementsByTagName('th');
	for (var g=0; g<ths.length; g++) {
		removeClassName(ths[g], 'on');
	}
	// then, remove the 'on' class from all other td's
	var tds = table.getElementsByTagName('td');
	for (var m=0; m<tds.length; m++) {
		removeClassName(tds[m], 'on');
	}
	
	// now, add the class 'on' to the selected th
	var newths = getElementsByClassName(column, 'th', table);
	for (var h=0; h<newths.length; h++) {
		addClassName(newths[h], 'on');
	}
	// and finally, add the class 'on' to the selected td
	var newtds = getElementsByClassName(column, 'td', table);
	for (var i=0; i<newtds.length; i++) {
		addClassName(newtds[i], 'on');
	}
}
</script>
</head>
<body>
<div class="top"></div>
<div class="base">
<div class="middle">
<div class="logo">&nbsp;   
</div>
<div class="topmenu">
<div class="right"></div>
<?php include 'topmenu.php'; ?>
<div class="left">
</div><!--Top Menu -->
<div class="content">
<div class="content_bg">
<?php
if (isset($_POST['exit'])){
if ($_SESSION['login']==1)
header('location:usercontrolpanel.php?id='.$_SESSION['shparvande']);
if ($_SESSION['mosh']==1)
header('location:moshavercontrolpanel.php?id='.($_SESSION['cod']*-1));	
}
if ($_SESSION['login']!=1 && $_SESSION['mosh']!=1)
header('location:index.php');  
include 'func/connect2.php'; include 'func/funcs.php';
$too=" لطفا اطلاعات زیر را با دقت پر نمایید زیرا در صورت وارد کردن اطلاعات غیر منطقی آگهی تایید نمی شود";
if (isset($_POST['daste']) ){
	$emkanat='';
if (isset($_POST['ab']) && $_POST['ab']=='on')
	$emkanat=$emkanat."آب-";
if (isset($_POST['bargh']) && $_POST['bargh']=='on')
	$emkanat=$emkanat."برق-";
	if ( isset($_POST['gaz']) && $_POST['gaz']=='on')
	$emkanat=$emkanat."گاز-";
	if (isset($_POST['tell']) && $_POST['tell']=='on')
	$emkanat=$emkanat."تلفن-";
	$s1=$_FILES['ax1']['size'];	$s3=$_FILES['ax3']['size'];	$s2=$_FILES['ax2']['size'];
    $t1=$_FILES['ax1']['type'];$t2=$_FILES['ax2']['type'];$t3=$_FILES['ax3']['type'];
	if ($s1>200000 || $s2>200000 || $s3>200000 || $t1!="image/jpeg" || $t2!="image/jpeg" || $t3!="image/jpeg" )
	echo "<script language='javascript' > alert('لطفا به مشکلات تصاویر رسیدگی نمایید'); </script>";
	else {
	$too="آگهی شما با موفقیت به ثبت رسید و پس از تایید نمایش داده خواهد شد";
	$s1=$_FILES['ax1']['size'];
	$t1=$_FILES['ax1']['type'];
	$n1=$_FILES['ax1']['tmp_name'];
	$fp1=fopen($n1,'r');
	$pic1=fread($fp1,filesize($n1));
	$s2=$_FILES['ax2']['size'];
	$t2=$_FILES['ax2']['type'];
	$n2=$_FILES['ax2']['tmp_name'];
	$fp2=fopen($n2,'r');
	$pic2=fread($fp2,filesize($n2));
	$s3=$_FILES['ax3']['size']; 
	$t3=$_FILES['ax3']['type'];
	$n3=$_FILES['ax3']['tmp_name'];
	$fp3=fopen($n3,'r');
	$pic3=fread($fp3,filesize($n3));
	$re=$conecct->prepare("INSERT INTO `shopdb`.`product` (`productid` ,`name` ,`catid` ,`gheymat` ,`ax` ,`tozih` ,`tarikh`,`otagh` ,`chandsale` ,`asansor` ,`tabaghe` ,`vahed`,`metri`,`zirbana` ,`dastshooi` ,`parking`,`balkon` ,`ashpazkhane` ,`sanad` ,`dang`,`divar` ,`kabinet`,`address`,`moamele`,`cooler`,`axdo`,`axse`,`shparvande`, `kaf` , `garmayesh` ,`jahat` ,`abbarghgaz` )
VALUES ('',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
$re->bindValue(1,$_POST['name']);$re->bindValue(2,$_POST['daste']);
 if ( checkGetParam($_GET['h'])!=1){$re->bindValue(3,$_POST['gheymat']);}else{$re->bindValue(3,0);}
 $re->bindValue(4,$pic1);
$re->bindValue(5,$_POST['tozih']);$re->bindValue(6,getCurentDate());
$re->bindValue(7,$_POST['otagh']);$re->bindValue(8,$_POST['salesakht']);
$re->bindValue(9,$_POST['asansur']);        if ( checkGetParam($_GET['h'])!=1){$re->bindValue(10,$_POST['metri']);}else{$re->bindValue(10,0);}
$re->bindValue(11,$_POST['vahed']);$re->bindValue(12,$_POST['tabaghe']);
$re->bindValue(13,$_POST['zirbana']);$re->bindValue(14,$_POST['dastshooei']);
$re->bindValue(15,$_POST['parking']);$re->bindValue(16,$_POST['balkon']);
$re->bindValue(17,$_POST['ashpazkhane']);$re->bindValue(18,$_POST['sanad']);
$re->bindValue(19,$_POST['dang']);$re->bindValue(20,$_POST['divar']);
if ($_POST['shahr']==1)$sh='قزوین';elseif ($_POST['shahr']==2)$sh='محمدیه';elseif ($_POST['shahr']==3)$sh='آبیک';elseif ($_POST['shahr']==4)$sh='بیدستان';elseif ($_POST['shahr']==5)$sh='محمود آباد نمونه';
$re->bindValue(21,$_POST['kabinet']);$re->bindValue(22,  "استان: ".$_POST['ostan']."| شهر: ".$sh."| منطقه: ".$_POST['mantaghe']."|  ".$_POST['kooche']);
$re->bindValue(23,$_POST['moamele']);$re->bindValue(24,$_POST['cooler']);
$re->bindValue(25,$pic2);$re->bindValue(26,$pic3);$re->bindValue(27,$_SESSION['shparvande']);$re->bindValue(28,$_POST['kaf']);$re->bindValue(29,$_POST['garmayesh']);$re->bindValue(30,$_POST['jahat']);$re->bindValue(31,$emkanat);
$re->execute();
	}
}
?> <form action="" method="post" >
<input type="submit" name="exit" id="exit" value="بازگشت به کنترل پنل"  /></form>
<form id="form1"   name="form1" method="post"  enctype="multipart/form-data"  onsubmit="return check(name.value , otagh.value ,salesakht.value,dang.value,ax1.value,ax2.value,ax3.value,zirbana.value,  <?php if( checkGetParam($_GET['h'])!=1){ echo "gheymat.value";} else {echo "zirbana.value";} ?> ,moamele.value)"  action="">
  <table width="100%"  border="1"  cellpadding="2" cellspacing="0" >
  <tr>
  <td colspan="5" bgcolor="#CCCCCC">
         <table width="100%" border="0"  >
        
         <td colspan="4" class="ddd">
         <?php echo $too; ?>

         </td>
          </tr>
            <tr>

             <td>نام آگهی دهنده </td>
             <td><label for="name"></label>
               <input type="text" name="name" id="name" class="sefid"/></td>
             <td> دسته مربوطه </td>
             <td ><label for="daste"></label>
               <select name="daste" id="daste" class="sefid">
          <?php 
              $r=$conecct->query("select * from cat" );
$i=0;
while ($rows =$r->fetch(PDO::FETCH_ASSOC)) {
	echo '<option value="'.checkparam($rows['catid']).'" >'.checkparam($rows['name']).'</option>';
	
}
               ?>
               </select></td>
           </tr>
           <tr>
             <td>تعداد اتاق</td>
             <td><label for="otagh"></label>
               <input type="text" name="otagh" id="otagh" class="sefid" /></td>
             <td>سال ساخت</td>
             <td ><label for="salesakht"></label>
               <input type="text" name="salesakht" id="salesakht"  class="sefid"/></td>
           </tr>
           <tr>
             <td>آسانسور</td>
             <td><label for="asansur"></label>
               <select name="asansur" id="asansur" class="sefid">
                 <option>دارد</option>
                 <option>ندارد</option>
               </select></td>
             <td>نوع سند</td>
             <td ><label for="sanad"></label>
               <select name="sanad" id="sanad" class="sefid">
                 <option>شخصی </option>
                 <option>تجاری</option>
               </select></td>
           </tr>
           <tr>
             <td>آشپزخانه</td>
             <td><label for="ashpazkhane"></label>
               <select name="ashpazkhane" id="ashpazkhane" class="sefid">
                 <option>دارد</option>
                 <option>ندارد</option>
               </select></td>
             <td>تعداد دانگ</td>
             <td ><label for="dang"></label>
               <input type="text" name="dang" id="dang" class="sefid" /></td>
           </tr>
           <tr>
             <td>کابینت </td>
             <td><label for="kabinet"></label>
               <select name="kabinet" id="kabinet" class="sefid">
                 <option>Mdf</option>
                 <option>معمولی</option>
                 <option>ندارد</option>
               </select></td>
             <td>بالکن</td>
             <td ><label for="balkon" ></label>
               <select name="balkon" id="balkon" class="sefid">
                 <option>دارد</option>
                 <option>ندارد</option>
               </select></td>
           </tr>
           <tr>
             <td>نوع معامله</td>
             <td><label for="moamele"></label>
               <select name="moamele" id="moamele" class="sefid" onChange="pp();" >
                 <option>فروش</option>
                 <option>رهن</option>
                 <option>اجاره</option>
                  <option>رهن و اجاره</option>
                 <option selected="selected" value="0">لطفا نوع معامله را مشخص نمایید</option>
                 </select></td>
             <td>دیوار</td>
             <td ><label for="divar" ></label>
               <select name="divar" id="divar" class="sefid">
                 <option>گچ</option>
                 <option>الیاف</option>
               </select></td>
           </tr>
           <tr>
             <td>سرویس بهداشتی</td>
             <td><label for="dastshooei"></label>
               <select name="dastshooei" id="dastshooei" class="sefid">
                 <option>ایرانی</option>
                 <option>فرنگی</option>
                 <option>هم ایرانی هم فرنگی</option>
               </select></td>
             <td>پارکینگ</td>
             <td ><label for="parking"></label>
               <select name="parking" id="parking" class="sefid">
                 <option>دارد </option>
                 <option>ندارد</option>
               </select></td>
           </tr>
               <tr>
             <td>کف</td>
             <td><label for="kaf"></label>
               <select name="kaf" id="kaf" class="sefid">
                 <option>پارکت</option>
                 <option>سرامیک</option>
                 <option>سنگ</option>
                  <option>موزاییک</option>
               </select></td>
             <td width="200">سیستم گرمایشی</td>
             <td ><label for="garmayesh"></label>
               <select name="garmayesh" id="garmayesh" class="sefid">
                 <option>شوفاژ </option>
                 <option>پکیج</option>
                 <option>بخاری</option>
               </select></td>
           </tr>
           <tr>
           
             <td>طبقه</td>
             <td><label for="tabaghe"></label>
               <input type="text" name="tabaghe" id="tabaghe" class="sefid" /></td>
             <td>واحد</td>
             <td ><label for="vahed"></label>
               <input type="text" name="vahed" id="vahed" class="sefid" /></td>
           </tr>
              <tr>
             <td>آدرس استان</td>
             <td ><label for="ostan"></label>
               <select name="ostan" id="ostan" class="sefid">
                 <option>قزوین</option>
               </select></td>
             <td>شهر</td>
             <td ><label for="shahr"></label>
               <select name="shahr" id="shahr"   onChange="shahr_show();" class="sefid">
                <?php 
				$conecct->exec("SET CHARACTER SET UTF8");
		$re=$conecct->query("select DISTINCT shahrid,shahr  from map");
		$re->execute();
		while($rows2=$re->fetch(PDO::FETCH_ASSOC)){
		echo "  <option value='".checkparam($rows2['shahrid'])."'  selected='selected'>".checkparam($rows2['shahr'])."</option>" ;				
		}
		?>     
         <option selected='selected' value="قزوین" >لطفا شهر خود را انتخاب نمایید</option>
               </select></td>
           </tr>
           <tr>
             <td >منطقه</td>
             <td >
              <div class="namayesh" >
               </div>
            </td>
             <td>آدرس دقیق </td>
             <td ><label for="kooche"></label>
               <textarea name="kooche" id="kooche" class="sefid" cols="35" rows="5"></textarea></td>
           </tr>
        
           <tr>
             <td>
             سیستم سرمایشی</td>
             <td ><label for="cooler" ></label>
               <select name="cooler" id="cooler" class="sefid">
                 <option>کولر آبی</option>
                 <option>کولر گازی </option>
                 <option>پنکه سقفی </option>
                 <option>ندارد</option>
               </select></td>
                <td>جهت ملک</td>
                
             <td  ><label for="jahat"></label>
               <select name="jahat" id="jahat" class="sefid">
                 <option>شمالی</option>
                 <option>جنوبی </option>
               </select></td>
           </tr>
           
   <tr>
           <td colspan="7">  <label for="ab">آب:</label><input type="checkbox" name="ab" id="ab" /> <label for="bargh">برق:</label><input type="checkbox" name="bargh" id="bargh" /> <label for="gaz">گاز:</label><input type="checkbox" name="gaz" id="gaz" /> <label for="tell">تلفن:</label><input type="checkbox" name="tell" id="tell" />
      </td>
      </tr>
         <tr><td colspan="7">&nbsp;</td>
         </tr>
           <tr>
             <td colspan="5" class="ddd"> تصویر اول تصویری از نمای ملک می باشد و تصویر دوم و سوم تصاویر منتخب شما از درون ملک می باشد . حجم همه ی تصاویر باید کمتر از 200 کیلو بایت باشد و فرمت آنها JPEG باشد.  . <div id="Info"  ></div><span id="Loading" >
               
             </span>
             </div> <div id="Info2"  ></div><span id="Loading2" ></span></div> <div id="Info3" ></div><span id="Loading3" ></span></div><p>&nbsp;</p></td>
             </tr><tr><td colspan="7">&nbsp;</td>
         </tr>
           <tr>
             <td>تصویر اول</td>
             <td><label for="ax1"></label>
               <input type="file" name="ax1" id="ax1"  onBlur="return check_ax1();" class="sefid" /></td>
             <td>تصویر دوم</td>
             <td ><label for="ax2"></label>
               <input type="file" name="ax2" id="ax2"  onBlur="return check_ax2();"  class="sefid"/></td>
           </tr>
           <tr>
         <td>تصویر سوم</td>
             <td  ><label for="ax3"></label>
               <label for="ax3"></label>
               <input type="file" name="ax3" id="ax3"  onBlur="return check_ax3();"  class="sefid"/></td>
             <?php 
             if ( checkGetParam($_GET['h'])!=1) { echo' <td><div class="nama"></div></td>
             <td><label for="gheymat"></label>
               <input type="text" name="gheymat" id="gheymat"  class="sefid" /></td>'; } ?>
           
           <?php if (checkGetParam( $_GET['h'])!=1)  {echo '
 </tr><tr> <td><div class="nama2"></div></td>
             <td ><label for="metri"></label>
               <input type="text" name="metri" id="metri" class="sefid"  /></td> ';}?>
             <td >زیر بنا متر مربع </td>
             <td ><label for="zirbana"></label>
               <input type="text" name="zirbana" id="zirbana" class="sefid"/></td>
           </tr>
        
           <tr>
             <td>توضیحات</td>
             <td colspan="4"><label for="tozih"></label>
               <textarea name="tozih" cols="40" id="tozih" class="ckeditor" class="sefid"></textarea></td>
           </tr>
           <tr>
             <td colspan="5"><input type="submit" name="button" id="button" value="ثبت"  class="dddd"/>
               <input type="reset" name="button2" id="button2" value="پاک کردن"  class="dddd"/></td>
           </tr>
         <p>&nbsp;</p> 
              
  </form>    
    </table>
<p>&nbsp;</p>
</div><!--Left -->
</div>
<div class="content_bottom">
<?php include 'footer.php'; ?>
</div><!--Conetnt -->
</div><!--Middle -->
</div><!--base -->
</body>
</html>
