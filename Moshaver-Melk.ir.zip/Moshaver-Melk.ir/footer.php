<div class="footer" >
<table width="100%" border="0" >
    <tr>
      <td   width="39%" height="57" bgcolor="#000000"><a href="darkhast.php"><font color="#FFFFFF"> همکاری با ما</font></a></td>
      <td width="30%" bgcolor="#000000"><font color="#FFFFFF">نوسانات قیمت  در چند سال اخیر</font></td>
      <td width="31%" bgcolor="#000000"><font color="#FFFFFF">خدمات ساختمانی </font></td>
    </tr>
    <tr>
      <td height="53" bgcolor="#000000">
              <p><font color="#FFFFFF">آدرس دفتر مرکزی : قزوین خیابان شهید بابایی</font></p>
        <p><font color="#FFFFFF">صندوق پستی :565212255525</font></td>
     <td width="30%" bgcolor="#000000"><a href="map.php"><font color="#FFFFFF">نقشه ی آنلاین محله ها</font></a></td>
      <td width="31%" bgcolor="#000000"><a href="adver.php"><font  color="#FFFFFF">تبلیغات</font></a></td>
    </tr>
    <tr>
      <td height="57" bgcolor="#000000"><font color="#FFFFFF">
       تلفن تماس 24 ساعته : 0919 </font></td>
  <td width="30%" bgcolor="#000000"><a href="pishnahad.php"><font color="#FFFFFF">انتقادات و پیشنهادات</font></a></td>
      <td width="31%" bgcolor="#000000"><font color="#FFFFFF">خبرنامه پیامکی </font></td>
    </tr>
  </table>
<p class="about">&nbsp;</p>
<p class="about">&nbsp;</p>
<p class="about">&nbsp;</p>
<h1 class="about">
    </p>
  </h1>
  <p>&nbsp;</p>
  <p>کلیه حقوق مادی و معنوی این وب سایت برای شرکت پیشدار محفوظ می باشد.</p>
  <p>&nbsp;</p>
  </p>
</center>
<div class="clr"></div>
</div><!--Middle -->
</div><!--base -->



    
    