   <?php 
   ob_start();
   session_start();
      include 'func/connect2.php';
   if (isset ($_POST['shahr'])){
		$conecct->exec("SET CHARACTER SET UTF8");
		$re=$conecct->prepare("select * from map where shahrid=?");
		$re->bindValue(1,$_POST['shahr']);
		$re->execute();
		echo "  محله شما :";
		echo "<select id='mahale' name='mahale'>";
		while($rows2=$re->fetch(PDO::FETCH_ASSOC)){
		echo "  <option value='".checkparam($rows2['mahaleid'])."'  selected='selected'>".checkparam($rows2['mahale'])."</option>" ;				
		}
		echo "</select>";
   } 
    if (isset ($_POST['shahr1'])){
		$conecct->exec("SET CHARACTER SET UTF8");
		$re=$conecct->prepare("select * from map where shahrid=?");
		$re->bindValue(1,$_POST['shahr1']);
		$re->execute();
		
		echo "<select id='mantaghe' name='mantaghe' class='sefid'>";
		while($rows2=$re->fetch(PDO::FETCH_ASSOC)){
		echo "  <option   selected='selected'>".checkparam($rows2['mahale'])."</option>" ;				
		}
		echo "</select>";
   } 
       
   
   if (isset( $_POST['user'])) {
	$r=$conecct->prepare("select * from user where userid like ?");
	  $r->bindValue(1,$_POST['user']);$r->execute();$p=$r->fetch(PDO::FETCH_ASSOC);	
	   echo "این نام کاربری قبلا ثبت شده است ";	   
   }
   if(isset ($_POST['sel'])){
	if($_POST['sel']==2){		
		if (isset ($_POST['selp'])) {
			$lim=($_POST['selp']-1)*15;
			$result2=$conecct->prepare("select * from product where shparvande=? and gheymat=0 limit ?,15");
$result2->bindValue(1,$_SESSION['cod']);$result2->bindValue(2,$lim , PDO::PARAM_INT);
$result2->execute();

	$nn=$conecct->prepare("select * from product where shparvande=? and gheymat=0 ");
$nn->bindValue(1,$_SESSION['cod']);
$nn->execute();
		}
		else {
$result2=$conecct->prepare("select * from product where shparvande=? and gheymat=0 limit 0,15");
$result2->bindValue(1,$_SESSION['cod']);
$result2->execute();

$nn=$conecct->prepare("select * from product where shparvande=? and gheymat=0 ");
$nn->bindValue(1,$_SESSION['cod']);
$nn->execute();
		}
	}
	else{
			if (isset ($_POST['selp'])) {
		$lim=($_POST['selp']-1)*15;
		
$result2=$conecct->prepare("select * from product where shparvande=? and gheymat!=0 limit  ?,15");
$result2->bindValue(1,$_SESSION['cod']);$result2->bindValue(2,$lim , PDO::PARAM_INT);
$result2->execute();
$nn=$conecct->prepare("select * from product where shparvande=? and gheymat!=0 ");
$nn->bindValue(1,$_SESSION['cod']);
$nn->execute();	
	}
	else {
		$result2=$conecct->prepare("select * from product where shparvande=? and gheymat!=0 limit 0,50");
$result2->bindValue(1,$_SESSION['cod']);
$result2->execute();	
$nn=$conecct->prepare("select * from product where shparvande=? and gheymat!=0 ");
$nn->bindValue(1,$_SESSION['cod']);
$nn->execute();	
	}
	}	
	echo '  <form method="post" action="moshavercontrolpanel.php?id=1"><table width="100%" border="1">   <tr>
      <td><input type="submit" name="button" id="button" value="حذف "></td>
      <td>ویرایش</td>
      <td>تعداد بازدید</td>
	  <td>وضعیت</td>
      <td width="25">تاریخ ثبت</td>
      <td width="64">پیام مدیر </td>
      <td>آدرس</td>
    </tr>';
$n=$nn->rowCount();
$p=ceil($n/15);	
$o=1;
	while ($rows2=$result2->fetch(PDO::FETCH_ASSOC )) {		
		echo "    <tr>
		  <td><input name='c".$o++."' type='checkbox' id='checkbx' value='".$rows2['productid']."'></td>
		   <td><a href='virayesh.php?h=1&id=".checkparam($rows2['productid'])."' >ویرایش</a></td>
      <td>".checkparam($rows2['bazdid'])."</td>";
	   if (checkparam($rows2['taeed'])==0){echo "<td bgcolor='#FF0000'>No</td>";} if (checkparam($rows2['taeed'])==1){echo "<td bgcolor='#00CC33'>Ok</td>";}
  echo "    <td>".checkparam($rows2['tarikh'])."</td>"; if (checkparam($rows2['payam'])!=0){echo "<td bgcolor='#00FF66'>";}else echo "<td>";
echo   "<a href='mokatebe.php?h=1&id=".checkparam($rows2['productid'])."' >مشاهده</a></td>
	   <td>".checkparam($rows2['address'])."</td>
	  </tr> ";
		
	}
		echo '<tr><td colspan="7" bgcolor="#457896"><label for="selectpage"></label>
        <select name="selectpage" id="selectpage" onChange="bb();" >
	 <option >صفحه ی مورد نظر</option>';
	 for ($i=1 ; $i<=$p ; $i++){ echo '
      <option >'.$i.'</option>';}
     echo '   </select></td></tr>';	
   }
      if(isset ($_POST['seluser'])){	
	if($_POST['seluser']==2){		
		if (isset ($_POST['selpuser'])) {
			$lim=($_POST['selpuser']-1)*15;
			$result2=$conecct->prepare("select * from product where shparvande=? and gheymat=0 limit ?,15");
$result2->bindValue(1,$_SESSION['shparvande']);$result2->bindValue(2,$lim , PDO::PARAM_INT);

$result2->execute();
$nn=$conecct->prepare("select * from product where shparvande=? and gheymat==0 ");
$nn->bindValue(1,$_SESSION['shparvande']);
$nn->execute();
		}
		else {
$result2=$conecct->prepare("select * from product where shparvande=? and gheymat=0 limit 0,15");
$result2->bindValue(1,$_SESSION['shparvande']);
$result2->execute();

		$nn=$conecct->prepare("select * from product where shparvande=? and gheymat=0 ");
$nn->bindValue(1,$_SESSION['shparvande']);
$nn->execute();
		}
	}
	else{
			if (isset ($_POST['selpuser'])) {
		$lim=($_POST['selpuser']-1)*15;		
$result2=$conecct->prepare("select * from product where shparvande=? and gheymat!=0 limit  ?, 15");
$result2->bindValue(1,$_SESSION['shparvande']);$result2->bindValue(2,$lim,PDO::PARAM_INT);
$result2->execute();

$nn=$conecct->prepare("select * from product where shparvande=? and gheymat!=0 ");
$nn->bindValue(1,$_SESSION['shparvande']);
$nn->execute();
	}	
	else {
		$result2=$conecct->prepare("select * from product where shparvande=? and gheymat!=0 limit 0,15");
$result2->bindValue(1,$_SESSION['shparvande']);
$result2->execute();	

	$nn=$conecct->prepare("select * from product where shparvande=? and gheymat!=0 ");
$nn->bindValue(1,$_SESSION['shparvande']);
$nn->execute();	
	}
	}
	echo '  <form method="post" action="moshavercontrolpanel.php?id=1"><table width="100%" border="1">   <tr>
      <td><input type="submit" name="button" id="button" value="حذف "></td>
      <td>ویرایش</td>
      <td>تعداد بازدید</td>
	  <td>وضعیت</td>
      <td width="25">تاریخ ثبت</td>
      <td width="64">پیام مدیر </td>
      <td>آدرس</td>   
    </tr>';
	

$n=$nn->rowCount();
$p=ceil($n/15);
$o=1;
	while ($rows2=$result2->fetch(PDO::FETCH_ASSOC )) {	
		echo "    <tr>
		  <td><input name='c".$o++."' type='checkbox' id='checkbx' value='".$rows2['productid']."'></td>
		   <td><a href='virayesh.php?id=".checkparam($rows2['productid'])."' >ویرایش</a></td>
		         <td>".checkparam($rows2['bazdid'])."</td>";
       if (checkparam($rows2['taeed'])==0){echo "<td bgcolor='#FF0000'>No</td>";} if (checkparam($rows2['taeed'])==1){echo "<td bgcolor='#00CC33'>Ok</td>";}
  echo "    <td>".checkparam($rows2['tarikh'])."</td>"; if (checkparam($rows2['payam'])!=0){echo "<td bgcolor='#00FF33'>";}else echo "<td>";
echo   "<a href='mokatebe.php?id=".checkparam($rows2['productid'])."' >مشاهده</a></td>
	   <td>".checkparam($rows2['address'])."</td>
	  </tr> ";
		
	}	
		echo '<tr><td colspan="7" bgcolor="#457896"><label for="selectpage"></label>
        <select name="selectpage" id="selectpage" onChange="bb();" >
	 <option >صفحه ی مورد نظر</option>';
	 for ($i=1 ; $i<=$p ; $i++){ echo '
      <option >'.$i.'</option>';}
     echo '   </select></td></tr>';
	
   }
   
   if (isset ($_POST['moamele'])){
	  if ($_POST['moamele']=='رهن') 
	   echo " قیمت رهن به میلیون تومان" ;
	   	  if ($_POST['moamele']=='اجاره') 
	   echo "قیمت اجاره به میلیون تومان" ;
	   	  if ($_POST['moamele']=='فروش') 
	   echo "قیمت کل به میلیون تومان" ;
	   	  if ($_POST['moamele']=='رهن و اجاره') 
	   echo "قیمت رهن به میلیون تومان" ;
    }
	
	 if (isset ($_POST['moamele2'])){
	  if ($_POST['moamele2']=='رهن') 
	   echo " به مدت چند سال" ;
	   	  if ($_POST['moamele2']=='اجاره') 
	   echo "به مدت چند سال" ;
	   	  if ($_POST['moamele2']=='فروش') 
	   echo "قیمت متری به میلیون تومان" ;
	   	  if ($_POST['moamele2']=='رهن و اجاره') 
	   echo "قیمت اجاره به میلیون تومان" ;
    }
		?>

	