<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php 
include 'func/connect2.php';
?>
 <script src="sliderengine/jquery.js"></script>
<head>
<title>راهنمای سایت</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
 <style type="text/css" media="screen">
		@import url(style.css );
		@import url(tab.css );
	body,td,th {
	color: #000;
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
}
   .middle .topmenu .content .content_bg .post .post_body table tr td p {
	text-align: right;
}
 .middle .topmenu .content .content_bg .post .post_body table tr td {
	text-align: right;
}
 </style>
<script src="js/jcarousellite_1.0.1c4.js" type="text/javascript"></script>
<script type="text/javascript" src="js/01.js"></script>
<script type="text/javascript" src="js/02.js"></script>
<script type="text/javascript" src="js/03.js"></script>
<script type="text/javascript" src="js/general.js"></script>
</head>
<body>
<div class="top"></div>
<div class="base">
<div class="middle">
<div class="logo">&nbsp;  
</div>
<div class="topmenu">
<div class="right"></div>
<?php include 'topmenu.php'; ?>
<div class="left">
</div><!--Top Menu -->
<div class="content">
<div class="content_top"></div>
<div class="content_bg">
<div id="right2">
		<div class="about"><div class="about_top"></div><div class="about_body">		<div class="menu_title">
		  <h6>دسته بندی کتاب ها </h6></div><div class="text">		<ul>
        <?php 
		$r=$conecct->query("select * from cat" );

while ($rows =$r->fetch(PDO::FETCH_ASSOC )) 
			echo  '	<li><a href="index.php?at=0&cat='.checkparam($rows['catid']).'" title="">'.checkparam($rows['name']).'</a></li>';
			?>
              <li><a href="index.php?flag=r" title="">رهن</a></li>	
            <li><a href="index.php?flag=e" title="">اجاره</a></li>	
            <li><a href="index.php?flag=er" title="">رهن و اجاره</a></li>
            <li><a href="index.php?flag=j" title="">جدید ترین آگهی ها</a></li>
            <li><a href="indx.php?flag=p" title="">پر بازدید ترین آگهی ها</a></li>	
				</ul>
		</div></div><div class="about_bottom"></div></div><!--Menu -->
        <p>`</p>
          <?php include 'login.php' ;?>         
        <p> <font color="" >.</font></p>          
          <div class="customers_title"><div class="customers_icon"></div></div>
<div class="content anyClass_01">
<ul>
<?php 
$result3 = $conecct->query("select * from news ");
			while (	$rows3=$result3->fetch(PDO::FETCH_ASSOC)){ 
echo "<li>
 <div class='bcontent'>
<div class='author'><a href='page.html' >".checkparam( $rows3['onvan'])."</a></div><div class='bcontent_top'></div>
<div class='bcontent_body'><div class='text'>"
.checkparam($rows3['matn'])."
 <br />
</div></div>
<div class='bcontent_bottom'></div>
</div>
</li>
";
}
?>
</ul>
</div>
<div class="box_bottom"></div>
<!--Customers box -->
</div><!--Right -->
<div class="post" >
<div class="post_body">
</form>
</div>
<div class="post_bottom"></div>
</div>
<div id="left2">
  <p>&nbsp;</p>
  <table width="100%" border="20">
    <tr>
      <td><div>
        <table width="100%" border="1">
          <tr>
            <td> <p><h3>راهنمای استفاده</h3>
              <p>مشاورین املاک و کاربران عادی می توانند از این سایت استفاده نمایند . با ثبت نام کردن از قسمت ثبت نام آنها می توانند به خانواده ی مشاور املاک قزوین بپیوندند و با ورود به سایت که برای مشاورین املاک در منوی زیر گزینه ی ثبت نام در بالای سایت و کاربران عادی در سمت راست سایت به کنترل پنل خود هدایت می شوند و در آن قسمت می نوانند آگهی های خود را به دو شکل آگهی های حراج یا عادی بدهند . و آگهی های قبلی خود را از لحاظ تایید شدن یا نشدن توسط مدیریت ، تعداد بازدید ویژه تا این لحظه و ... ، همچنین آنها می توانند آگهی های خود را حذف و یا ویرایش نمایند . و همچنین در سایت امکانات ویژه ای از جمله انجمن گفتگو در مورد ملک و املاک مشاهده ی منطقه ها از طریق گوگل مپ و .... وجود دارد . در منوی بالا و در قسمت مشاورین املاک در زیر منو امکانات سایت مشاورین املاک پیوسته به ما را می توان دید . </p>
              <p>در صورت هر گونه سوال از طریق گزینه ی تماس با ما می توانید با ما مکاتبه نمایید.</p>
              <p>آگهی های قرار گرفته شده در سایت در اکثر موارد همان آگهی های مشاورین املاک می باشد که به صورت دیجیتال در آمده است .</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              </p></td>
          </tr>
          <tr>
            <td> <p>
              <p>              
              <h3>قوانین مربوط به کاربران عادی</h3>
              <p>در آینده ممکن است به دلیل سیاست های به کار گرفته شده توسط مدیریت سایت هزینه ای برای ثبت آگهی اخذ گردد و یا محدودیت هایی اعمال گردد .</p>
              <p>آگهی های با مضمون غیر منطقی و غیر اخلاقی ... مورد تایید قرار نمی گیرند و حتی ممکن است به طور جدی برخورد شود . </p>
              <p>برای بهره گیری از قیمت بروز املاک می توانید از قسمت انجمن کمک گرفته شود .</p>
              <p>برای انتخاب هرچه بهنر میتوانید از قسمت انجمن استفاده نمایید.</p>
              <p>برای ثبت هر ملک سه تصویر یکی از نمای ساختمان و دو عدد از داخل ملک ضروری می باشد .</p>
              <p>استفاده از هر گونه پیام های غیر اخلاقی در انجمن به طور جدی برخورد را در پی دارد .
                </p>
              </p>
              <p>&nbsp;</p>
              <p>&nbsp;</p></td>
          </tr>
          <tr>
            <td> <p>
              <p>              
              <h3>قوانین مربوط به مشاورین املاک</h3>
              <p>در آینده ممکن است به دلیل سیاست های به کار گرفته شده توسط مدیریت سایت هزینه ای برای ثبت آگهی جدید اخذ گردد . و یا محدودیت هایی اعمال گردد .</p>
              <p>آگهی های با مضمون غیر منطقی و غیر اخلاقی ... مورد تایید قرار نمی گیرند و حتی ممکن است به طور جدی برخورد شود . </p>
              <p>برای بهره گیری از قیمت بروز املاک می توانید از قسمت انجمن کمک گرفته شود .</p>
              <p>برای انتخاب هرچه بهنر میتوانید از قسمت انجمن استفاده نمایید.</p>
              <p>برای ثبت هر ملک سه تصویر یکی از نمای ساختمان و دو عدد از داخل ملک ضروری می باشد .</p>
<p>برای بهتر شدن خدمات حتما در بحث های انجمن شرکت نمایید .              </p>
<p>استفاده از هر گونه پیام های غیر اخلاقی در انجمن به طور جدی برخورد را در پی دارد .
  </p>
</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
              </p></td>
          </tr>
          <tr>
            <td><p>&nbsp;</p>
              <p><h3>نکات مهم در قرارداد</h3>
              <p>&nbsp;</p>
              </p>
              <p>قرارداد پیش فروش ساختمان :بر اساس قانون ، هر قراردادی به هر   عنوان که به موجب آن مالک رسمی زمین  (پیش فروشنده ) متعهد به احداث بنا یا   تکمیل  واحد ساختمانی مشخص در آن زمین با هر نوع کاربری در مقابل پیش   خریدار گردد را گویند .<br />
              </p>
              <p>نکات : </p>
              <p>در قرار داد بایستی پلاک و مشخصات ثبتی ملک ، نشانی ، تعداد   اتاق ، شماره طبقه ، واحد ، پارکینگ ، نوع کاربری و مساحت کل عرصه و اعیان ،   همچنین مصالح ساختمانی و سیستم گرمایش و سرمایش، تماما&quot; به طور دقیق قید   </p>
              <p>گردد.این موارد باید بر اساس پروانه ساخت و شناسه فنی هر واحد باشد.</p>
              <p>&nbsp;</p>
              <p>مبلغ قرارداد، میزان اقساط ، تعداد قبوض اقساطی و زمان تحویل باید در قرارداد تصریح گردد.</p>
              <p>تنظیم قرارداد پیش فروش در صلاحیت دفتر خانه های اسناد رسمی و تنظیم صورت جلسه مقدماتی در صلاحیت بنگاه های املاک می باشد.</p>
              <p>تنظیم قرارداد پیش فروش ساختمان نیاز به ارائه گواهی مالیاتی از طرف پیش فروشنده ندارد و صرفا&quot; حق التحریری خاص به آن تعلق می گیرد.<br />
              </p>
<p>&nbsp;</p>
              <p>میزان خسارت تاخیر پیش فروشنده در انجام دادن تعهداتش در   قرارداد تعیین می گردد، اما چنانچه طرفین به مبلغی بیشتر توافق کنند این   توافق معتبر است.</p>
              <p>طرفین می توانند در نحوه ی پرداخت اقساط توافق نمایند اما باید   توجه کنند حداقل 10 در صد بها، همزمان با تنظیم سند قطعی قابل وصول خواهد   بود و نمی توانند خلاف آن توافق نمایند.</p>
              <p>پیش خریدار می تواند پرداخت باقی مانده اقساط را منوط به تایید   مهندس ناظر ساختمان کند. شایان ذکر است پیش خریدار، به نسبت اقساطی که   پرداخت نموده ،مالک ملک پیش فروش شناخته می شود.</p>
              <p>پیش فروشنده فقط با رضایت همه ی مالکان می تواند تمام یا بخشی از حقوق و تعهدات خود را به دیگری واگذار نماید.</p></td>
          </tr>
        </table>
        <br />
        </div>
        <ol>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
      </ol>
        <p>&nbsp;</p>
        <p>&nbsp;</p></td>
    </tr>
  </table>
  <p>&nbsp;</p>
</div>
<div class="content_bottom">
</div>
</div><!--Conetnt -->
<?php
include 'footer.php';
?>
</div><!--base -->   
</body>
</html>
