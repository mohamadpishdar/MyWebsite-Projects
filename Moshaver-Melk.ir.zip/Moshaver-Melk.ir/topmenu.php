<script type="text/javascript">
$(document).ready(function () {		
	$('#nav li').hover(
		function () {
			//show its submenu
			$('ul', this).slideDown(100);

		}, 
		function () {
			//hide its submenu
			$('ul', this).slideUp(100);			
		}
	);
	
});
</script>
<style type="text/css">
	
/* remove the list style */
#nav {
	margin:0; 
	padding:0; 
	list-style:none;
}	

.t {
	width:811px;
	height:57px;
	float:right;
	background:url(images/topmenu_bg.png) repeat-x;
}
	
	/* make the LI display inline */
	/* it's position relative so that position absolute */
	/* can be used in submenu */
	#nav li {
		float:right; 
		display:block; 
		width:130px; 
		position:relative;
		z-index:500; 
		margin:0 1px;
	}
		
	/* this is the parent menu */
	#nav li a {
		display:block; 
		font-weight:700;  
		height:50px; 
		text-decoration:none; 
		text-align:center; 
	}



	#nav li a:hover {
	
	}

		/* submenu, it's hidden by default */
		#nav ul {
			position:absolute; 
			left:0; 
			display:none; 
			margin:0 1px 0 -1px; 
			padding:0; 
			list-style:none;
		}
		
		#nav ul li {
			width:100px; 
			float:left; 
		}
		
		/* display block will make the link fill the whole area of LI */
		#nav ul a {
			display:block;  
			height:40px;
			
		}
		
		#nav ul a:hover {
			text-decoration:underline;	
		}

/* fix ie6 small issue */
/* we should always avoid using hack like this */
/* should put it into separate file : ) */
*html #nav ul {
	margin:0 0 0 -2px;
}
</style>
<div class="t">

<ul id="nav">
	<li><a href="index.php"><img src="images/nokhost.png"  width="130"  height="50"/></a></li>

	<li><a href="index.php" class="selected"><img src="images/sabtnam.png"  width="130"  height="50"/></a>
		<ul style="display: none;">
			<li "><a href="moshaverregister.php" ><img src="images/amlak.png"  width="130"  height="50"/></a></li>
			<li><a href="register.php" class="selected"><img src="images/adi.png"  width="130"  height="50"/></a></li>
            <li><a href="moshavarlogin.php" class="selected"><img src="images/login.png"  width="130"  height="50"/></a></li>		
		</ul>
		<div class="clear"></div>
	</li>
	<li><a href="index.php"><img src="images/emkanat.png" width="130"  height="50" /></a>
	<ul style="display: none;">
		<li><a href="anjoman/"><img src="images/anjoman.png"  width="130"  height="50"/></a></li>
		<li><a href="haraj.php"><img src="images/vije.png"  width="130"  height="50"/></a></li>
		<li><a href="help.php"><img src="images/help.png"  width="130"  height="50"/></a></li>
		<li><a href="moshaverin.php"><img src="images/moshaverin.png"  width="130"  height="50"/></a></li>
        <li><a href="estelam.php"><img src="images/estelam.png"  width="130"  height="50"/></a></li>
        <li><a href="#"><img src="images/marakez.png"  width="130"  height="50"/></a></li>
<li><a href="#"><img src="images/taghaza.png"  width="130"  height="50"/></a></li>
	</ul>			
		<div class="clear"></div>
	</li>
	<li><a href="search.php"><img src="images/searh.png".png" width="130"  height="50" /></a></li>
    <li><a href="about.php"><img src="images/darbare.png".png" width="130"  height="50"  /></a></li>
<li><a  href="tamas.php"><img src="images/tamas.png" width="130"  height="50"  /></a></li>
</ul>

</div>
