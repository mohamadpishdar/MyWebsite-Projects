$( function()
{
    $( '.anyClass_02' ).jCarouselLite(
    {
        vertical: true,
        visible:  3,
        auto:     4000,
        speed:    1000,
        scroll:   1,
		btnPrev: '.previous_02',
		btnNext: '.next_02'
    });
});
