$( function()
{
    $( '.anyClass_03' ).jCarouselLite(
    {
        vertical: true,
        visible:  1,
        auto:     5500,
        speed:    1000,
        scroll:   1,
		btnPrev: '.previous_03',
		btnNext: '.next_03',

    });
});
