﻿﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
﻿<?php 
include 'func/connect2.php';
?>
<head>
 <script src="sliderengine/jquery.js"></script>
    <script src="sliderengine/amazingslider.js"></script>
    <link rel="stylesheet" type="text/css" href="sliderengine/amazingslider-1.css">
    <script src="sliderengine/initslider-1.js"></script>
    <mata name="keywords" content:"خرید،فروش،رهن،اجاره،ثبت آگهی ملک،قزوین،محمدیه،شریف آباد،آوج،آبیک،مشاور ،املاک،خانه،زمین،مغازه">
<title>خرید ، فروش ،رهن ،اجاره</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
 <style type="text/css" media="screen">
		@import url(style.css );
		@import url(tab.css );
	body,td,th {
	color: #000;
	font-family: Tahoma, Geneva, sans-serif;	font-size: 12px;
}
   .middle .topmenu .content .content_bg .post .post_body table tr td p {
	text-align: right;
	font-family: Tahoma, Geneva, sans-serif;
				font-size: 12px;
}
 .middle .topmenu .content .content_bg .post .post_body table tr td {
	text-align: right;
	font-family: Tahoma, Geneva, sans-serif;
				font-size: 12px;
}
 a {
	text-align: right;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 13px;
}
 h1,h2,h3,h4,h5,h6 {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
}
 </style>
<script src="js/jcarousellite_1.0.1c4.js" type="text/javascript"></script>
<script type="text/javascript" src="js/01.js"></script>
<script type="text/javascript" src="js/02.js"></script>
<script type="text/javascript" src="js/03.js"></script>
<script type="text/javascript" src="js/general.js"></script>
<script type="text/javascript">
function getElementsByClassName(className, tag, elm){
	var testClass = new RegExp("(^|\\s)" + className + "(\\s|$)");
	var tag = tag || "*";
	var elm = elm || document;
	var elements = (tag == "*" && elm.all)? elm.all : elm.getElementsByTagName(tag);
	var returnElements = [];
	var current;
	var length = elements.length;
	for(var i=0; i<length; i++){
		current = elements[i];
		if(testClass.test(current.className)){
			returnElements.push(current);
		}
	}
	return returnElements;
}

function addClassName(elm, className){
    var currentClass = elm.className;
    if(!new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i").test(currentClass)){
        elm.className = currentClass + ((currentClass.length > 0)? " " : "") + className;
    }
    return elm.className;
}

function removeClassName(elm, className){
    var classToRemove = new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i");
    elm.className = elm.className.replace(classToRemove, "").replace(/^\s+|\s+$/g, "");
    return elm.className;
}

function activateThisColumn(column) {
	var table = document.getElementById('pricetable');
	
	// first, remove the 'on' class from all other th's
	var ths = table.getElementsByTagName('th');
	for (var g=0; g<ths.length; g++) {
		removeClassName(ths[g], 'on');
	}
	// then, remove the 'on' class from all other td's
	var tds = table.getElementsByTagName('td');
	for (var m=0; m<tds.length; m++) {
		removeClassName(tds[m], 'on');
	}
	
	// now, add the class 'on' to the selected th
	var newths = getElementsByClassName(column, 'th', table);
	for (var h=0; h<newths.length; h++) {
		addClassName(newths[h], 'on');
	}
	// and finally, add the class 'on' to the selected td
	var newtds = getElementsByClassName(column, 'td', table);
	for (var i=0; i<newtds.length; i++) {
		addClassName(newtds[i], 'on');
	}
}
</script>
</head>
<body>
<div class="top"></div>
<div class="base">
<div class="middle">
<div class="logo">&nbsp;  
</div>
<div class="topmenu">
   <div id="amazingslider-wrapper-1" style="display:block;position:relative;max-width:900px;margin:0px auto 0px;">
        <div id="amazingslider-1" style="display:block;position:relative;margin:0 auto;">
            <ul class="amazingslider-slides" style="display:none;">
            <?php 
			$result = $conecct->query("select * from slider ");
			while (	$rows1=$result->fetch(PDO::FETCH_ASSOC)){
			echo "<li><a href=moshakhasat.php?id=".checkGetParam($rows1['sh'])."><img src='adminpane/pic.php?id=".checkGetParam($rows1['id'])." ' alt='".$rows1['matn']."' /></a>
                </li>";					
			}
		echo "	  </ul>
            <ul class='amazingslider-thumbnails' style='display:none;'>
              <li><img src='adminpane/pic.php?id=".checkGetParam($rows1['id'])." ' alt='".checkparam($rows1['matn'])."' />
                </li>
            </ul>";			
			?>          
        <div class="amazingslider-engine"><a href="http://amazingslider.com" title="Responsive jQuery Content Slider">Responsive jQuery Content Slider</a></div>
        </div>
    </div>
<div class="right"></div>
<?php include 'topmenu.php'; ?>
<div class="left">  
</div><!--Top Menu -->
<div class="content">
<div class="content_top"></div>
<div class="content_bg">
<div id="right2">
		<div class="about"><div class="about_top"></div><div class="about_body">		<div class="menu_title">
		  <h6><img src="images/daste.png"  height="40" </h6></div><div class="text">		<ul>
        <?php 
$result2 = $conecct->query("select * from cat ");
			while (	$rows2=$result2->fetch(PDO::FETCH_ASSOC)){
			echo  '	<li><a href="?at=1&cat='.checkparam($rows2['catid']).'" title="">'.checkparam($rows2['name']).'</a></li>';
			}
			?>
            <li><a href="?flag=r" title="">رهن</a></li>	
            <li><a href="?flag=e" title="">اجاره</a></li>	
            <li><a href="?flag=er" title="">رهن و اجاره</a></li>	
            <li><a href="?flag=j" title="">جدید ترین آگهی ها</a></li>
            <li><a href="?flag=p" title="">پر بازدید ترین آگهی ها</a></li>
	
				</ul>
		</div></div><div class="about_bottom"></div></div><!--Menu -->
<p>`</p>
          <?php include 'login.php' ;
		if (isset($_SESSION['gheirmojaz']) && $_SESSION['gheirmojaz']==1 )   echo "<script language='javascript' > alert('لطفا ابتدا وارد حساب کاربری خو شوید')</script>";
		$_SESSION['gheirmojaz']=0;		  
		  ?>         
      <p> <font color="" >.</font></p>          
          <div class="customers_title"><div class="menu_title">
	  <h6><img src="images/news.png"  height="40" </h6></div><div class="customers_icon"></div></div>
<div class="about">
<div class="content anyClass_01">
<ul>
<?php 
$result3 = $conecct->query("select * from news ");
			while (	$rows3=$result3->fetch(PDO::FETCH_ASSOC)){ 
echo "<li>
 <div class='bcontent'>
<div class='author'><a href='page.html' >".checkparam( $rows3['onvan'])."</a></div><div class='bcontent_top'></div>
<div class='bcontent_body'><div class='text'>"
.checkparam($rows3['matn'])."
 <br />
</div></div>
<div class='bcontent_bottom'></div>
</div>
</li>
";
}
?>
</ul>
</div>
</div>
<div class="box_bottom"></div>
<!--Customers box -->
</div><!--Right -->
<div class="post" >
<div class="post_body">
</form>
</div>
<div class="post_bottom"></div>
</div>
<div id="left2">
<form action="" method="post" >
<table width="100%" border="1" bgcolor="#00CCCC"> 
  <tr>
    <td bgcolor="#00FFCC" >استان</td>
    <td bgcolor="#00FFCC">شهر</td>
    <td bgcolor="#00FFCC">منطقه</td>
    <td bgcolor="#00FFCC">نوع معامله</td>
    <td bgcolor="#00FFCC">دسته</td>
    <td bgcolor="#00FFCC">متراژ</td>
    <td colspan="2" bgcolor="#00FFCC">قیمت</td>
    </tr>
  <tr>
    <td bgcolor="#00FFCC"><label for="ostan"></label>
      <select name="ostan" id="ostan">
        <option>قزوین</option>
      </select></td>
    <td bgcolor="#00FFCC"><label for="shahr"></label>
      <select name="shahr" id="shahr">
<option>قزوین</option>
<option>محمدیه</option>
        <option>آبیک</option>
</select></td>
    <td bgcolor="#00FFCC"><label for="mantaghe"></label>
      <input type="text" name="mantaghe" id="mantaghe" placeholder="منطقه مورد نظر..."/></td>
    <td bgcolor="#00FFCC"><label for="moamele"></label>
      <select name="moamele" id="moamele">
        <option>فروش</option>
        <option>رهن</option>
        <option>اجاره</option>
        
      </select></td>
    <td bgcolor="#00FFCC"><label for="daste"></label>
      <select name="daste" id="daste">
              <?php 
              $r=$conecct->query("select * from cat" );
$i=0;
while ($rows =$r->fetch(PDO::FETCH_ASSOC)) {
	echo '<option value="'.checkparam($rows['catid']).'" >'.checkparam($rows['name']).'</option>';
	
}
               ?>
      </select></td>
    <td bgcolor="#00FFCC"><label for="zirbana"></label>
      <select name="zirbana" id="zirbana">
        <option value="0">زیر 50 متر</option>
        <option value="50">از 50 تا 100</option>
        <option value="100">از 100 تا 150</option>
        <option value="150">از 150 تا 200</option>
        <option value="200">از 200 تا 250</option>
        <option value="250">از 250 تا 300</option>
        <option value="300">بالای 300 متر</option>
      </select></td>
    <td bgcolor="#00FFCC"><label for="gheymat"></label>
      <select name="gheymat" id="gheymat">
        <option value="0">زیر 50 میلیون</option>
        <option value="50">بین 50 تا 100 میلیون</option>
        <option value="100">بین 100 تا 150</option>
        <option value="150">بین 150 تا 200</option>
        <option value="200">بین 200 تا 250</option>
        <option value="250">بین 250 تا 300</option>
        <option value="300">بالای 300 میلیون</option>
      </select></td></tr><tr bgcolor="#00CCFF">
    <td height="37" colspan="7" bgcolor="#00FFCC"><input type="submit" name="sabt" id="sabt" value="جستجو" />
 
</table>
</form>
<?php 

if (isset($_POST["sabt"])){
	if(checkparam($_POST['zirbana'])==300)
	$bala=100000000000000;
	else
	$bala=checkparam($_POST['zirbana'])+50;
	
	if(checkparam($_POST['gheymat'])==300)
	$gh=100000000000000;
	else
	$gh=checkparam($_POST['gheymat'])+50;
$rows=$conecct->prepare("select * from product where taeed=1 and   address like '%استان: ".checkparam($_POST['ostan'] )."| شهر: ".checkparam($_POST['shahr'] )."| منطقه: ".checkparam($_POST['mantaghe'])."%' and moamele=? and catid=? and zirbana>=".checkparam($_POST['zirbana'] )." and zirbana<=".checkparam($bala) ." and gheymat>=".checkparam($_POST['gheymat'] )." and gheymat<=".checkparam($gh )." order by tarikh desc limit 0,30");	
$rows->bindValue(1,$_POST['moamele']);$rows->bindValue(2,$_POST['daste']);
$rows->execute();
} 
 else if ( isset( $_GET[ "cat" ] )) {
	 $nnn1=((checkGetParam($_GET['at']))-1)*8;
			$rows=$conecct->prepare("select * from product where catid=? and taeed=1   order by tarikh desc limit ?,8");
	$rows->bindValue(1,checkGetParam($_GET['cat'] ));$rows->bindValue(2,$nnn1,PDO::PARAM_INT);
	$rows->execute();
	$tedadr=$conecct->prepare("select * from product where catid=? and taeed=1   ");
	$tedadr->bindValue(1,checkGetParam($_GET['cat'] ));
	$tedadr->execute(); 
 }
else if (isset ($_GET["flag"])){
	if ($_GET["flag"]=="j")
	$rows=$conecct->query("select * from product where taeed=1   order by tarikh desc limit 0,8");
	if ($_GET["flag"]=="p")
		$rows=$conecct->query("select * from product where taeed=1   order by bazdid desc limit 0,8");	
	if ($_GET["flag"]=="e"){
	$rows=$conecct->query("select * from product where taeed=1 and moamele='اجاره'  order by tarikh desc");
		$tedadr=$conecct->query("select * from product where taeed=1 and moamele='اجاره'  order by tarikh desc");
		if (isset($_GET['at'])){
		$nnp=(checkGetParam($_GET['at'])-1)*8;
$rows = $conecct->prepare("select * from product where taeed=1 and moamele='اجاره'  order by tarikh desc limit ?, 8" );
		$rows->bindValue(1,$nnp, PDO::PARAM_INT);$rows->execute();
	}
		
	}
	if ($_GET["flag"]=="r"){
				$rows=$conecct->query("select * from product where taeed=1 and moamele='رهن'  order by tarikh desc");	
$tedadr=$conecct->query("select * from product where taeed=1 and moamele='رهن'  order by tarikh desc");
		if (isset($_GET['at'])){
		$nnp=(checkGetParam($_GET['at'])-1)*8;
$rows = $conecct->prepare("select * from product where taeed=1 and moamele='رهن'  order by tarikh desc limit ?, 8" );
		$rows->bindValue(1,$nnp, PDO::PARAM_INT);$rows->execute();}
	}
	if ($_GET["flag"]=="er"){
				$rows=$conecct->query("select * from product where taeed=1 and moamele='رهن و اجاره'   order by tarikh desc");	
$tedadr=$conecct->query("select * from product where taeed=1 and moamele='رهن و اجاره'  order by tarikh asc");
		if (isset($_GET['at'])){
		$nnp=(checkGetParam($_GET['at'])-1)*8;
$rows = $conecct->prepare("select * from product where taeed=1 and moamele='رهن و اجاره'  order by tarikh desc limit ?, 8" );
		$rows->bindValue(1,$nnp, PDO::PARAM_INT);$rows->execute();}
	}
}	
else {
		$tedadr=$conecct->query("select * from product where gheymat>0 and taeed=1");
		if (isset($_GET['at'])){
		$nnp=(checkGetParam($_GET['at'])-1)*8;
		$rows = $conecct->prepare("select * from product where gheymat>0 and taeed=1 order by tarikh desc limit ?, 8" );
		$rows->bindValue(1,$nnp, PDO::PARAM_INT);$rows->execute();
	}
	else{
			$rows=$conecct->query("select * from product where taeed=1 and gheymat>0 order by tarikh desc limit 0,8");
}
}
if ($rows->rowCount()==0){
	echo '
<div class="post" >متاسفیم چنین موردی در حال حاضر در سایت وجود ندارد</div>
';
}
while ($r=$rows->fetch(PDO::FETCH_ASSOC))
{
	$p=$conecct->prepare("select * from cat where catid =?");
	$p->bindValue(1,$r['catid']);
	$p->execute();
$k=$p->fetch(PDO::FETCH_ASSOC);
echo '
<div class="post" >
<div class="post_top"  ><font color="#fff" ><h2>  آدرس : '.checkparam($r['address']).'</h2></font></div>
<div class="post_body">
  <table width="100%" border="1" bordercolor="#000000" cellpadding="10"   >
    <tr><td bgcolor="#00FFCC" height="22" colspan="2">';
	
	if (checkparam($r['gheymat'])==0){
	$pppp="توافقی";echo '<p><font size="+3" color="#ffffff">آگهی ویژه</font></p>';}
	else 
	$pppp=checkparam($r['gheymat']) ;
	if ($r['gheymat']!=0){
  echo '  <p>&nbsp;</p>   
        <p>'; if ($r['moamele']=='فروش')echo ' قیمت متری: ';elseif($r['moamele']=='رهن')echo'قیمت رهن: ';elseif($r['moamele']=='اجاره')echo'قیمت اجاره ماهیانه: '; elseif($r['moamele']=='رهن و اجاره')echo'قیمت رهن : ';   echo checkparam($r['metri']).' میلیون تومان</p>';}
    echo'    <p>زیر بنا : '.checkparam($r['zirbana']).'  متر مربع</p>
        <p>نوع آگهی : '.checkparam($r['moamele']).'</p>
		  <p>تعداد اتاق : '.checkparam($r['otagh']).' عدد</p></td>
      <td bgcolor="#00FFCC" rowspan="2"><img src="adminpane/product/pic.php?id='.$r['productid'].'"width=200 height=200 </td>
    </tr> <tr>'; echo '  <td bgcolor="#00FFCC">';
   if ($r['gheymat']!=0){
   if($r['moamele']=='فروش')echo'قیمت کل: ';elseif($r['moamele']=='رهن و اجاره')echo'قیمت اجاره: ';else echo'به مدت: ';   echo $pppp ;  if($r['moamele']=='اجاره')echo' سال ';  elseif($r['moamele']=='رهن')echo' سال  ';else{ echo 'میلیون تومان';}}
	else echo "قیمت : توافقی";
echo '	  <p>تاریخ انتشار : '.checkparam($r['tarikh']).'</p></td>
      <td bgcolor="#00FFCC">نوع دسته : : '.checkparam($k['name']).'<p>شماره ی آگهی : '.checkparam($r['productid']).'</p> </td>
      </tr>';	  
	   if( $_SESSION['login']!=1){
	   echo '	  <tr ><td bgcolor="FF6633" colspan="3"><h1>  برای مشاهده داخل ملک و مشخصات کامل لطفا وارد حساب خود شوید</h1> </td></tr>;' ;
       }
	    else {
			 echo '  
	  <tr><td bgcolor="CCFF66" colspan="3" > <a href=moshakhasat.php?id='.$r['productid'].'> <img src="images/home.png" width=50 height=50  /><h1>برای مشاهده داخل ملک و اطلاعات بیشتر کلیک نمایید   </h1></a> </td></tr>';		
		}
		echo '
  </table>
</div>
<div class="post_bottom"></div>
</div>';
}
 	if (isset($_GET['at']))
	echo 'صفحه ی  '. $_GET['at'];
	echo '<p>&nbsp;</p>';


	if (isset($_POST['sabt'])==false){
		$n= $tedadr->rowCount();
		
$pages=ceil($n/8);	

$radifs=ceil($pages/10);
$tah=$pages;
$cradif=1;
$cpage=1;
$tah=$pages;

if (isset($_GET['at'])){
$cpage=checkGetParam($_GET['at']);
$cradif=ceil($cpage/10);

if ($cradif<$radifs){
	$tah=$cradif*10;
}
else {
	$tah=$pages;
}
	
}

if ($cradif<$radifs && $cradif>1){
		echo "<a class='paging' href=?at=".((($cradif-1)*10)+1)."> <-- قبلی  </a>    "  ;		
	}
for ($i=$cradif ; $i<=$tah ; $i++ )
{
if ( isset($_GET['cat']))
{
	
echo "<a  class='paging' href=?cat=".checkGetParam($_GET['cat'])."&at=".$i ."> ".($i) ."</a> |  "  ;	

}
elseif ( isset($_GET['flag']))
{

echo "<a  class='paging' href=?flag=".$_GET['flag']."&at=".$i ."> ".($i) ."</a> |  "  ;	

}
else 
	echo "<a  class='paging' href=?at=".$i ."> ".($i) ."</a> |  "  ;
}
	if ($cradif<$radifs){
		echo "<a  class='paging' href=?at=".((($cradif+1)*10)+1)."> ادامه --> </a>    "  ;
		
	}
	}
?>
<p>.</p>
</div><!--Left -->
</div>
<div class="content_bottom">
<?php
include 'footer.php';
?>
</div>
</div><!--Conetnt -->   
</body>
</html>
