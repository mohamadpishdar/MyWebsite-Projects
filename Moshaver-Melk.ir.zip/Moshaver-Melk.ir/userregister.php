﻿<?php
ob_start();
session_start();
 include 'func/connect2.php';
$result=$conecct->query("select * from user");
if (isset($_SESSION['captcha']) && isset($_POST['captcha'])) {
 if (strcmp(strtoupper($_POST['captcha']),$_SESSION['captcha']))
 {
	 	 $_SESSION['msg']="لطفا در وارد کردن تصویر امنیتی دقت نمایید";
	 header('location:register.php');
 }
elseif (($_POST['un']!="") && ($_POST['pass']!="") && ($_POST['pass2']!="") &&  ($_POST['tell']!="") &&  ($_POST['ln']!="") &&  $_SESSION['sabtshode']!=1)
{
		$p1=$conecct->prepare("INSERT INTO `shopdb`.`user` (`userid`, `fname`, `lname`, `tell`, `address`,  `pass`,  `shomareparvande`) VALUES (? ,?, ?, ?, ?,  ?,?)");
	$p1->bindValue(1,$_POST['un']);	$p1->bindValue(2, $_POST['fn']);
	$p1->bindValue(3,$_POST['ln']);
	$p1->bindValue(4,$_POST['tell']);
	$p1->bindValue(5,$_POST['address']);
	$passn=hash_value($_POST['pass']);
	$p1->bindValue(6,$passn);
	$p1->bindValue(7,$result->rowCount());
	$p3=$p1->execute();
	if ($p3)
$_SESSION['msg']="<font color=green> ثبت نام شما با موفقیت انجام شد برای استفاده از امکانات سایت با اطلاعات خود وارد شوید</font>";
else 
$_SESSION['msg']="<font color=red> خطا در ثبت اطلاعات </font>";
	 header('location:register.php');
}
elseif ($_SESSION['sabtshode']==1)
$_SESSION['msg']="<font color=red>  لطفا در وارد کردن اطلاعات دقت نمایید </font>";
}
header('location:register.php');
?>