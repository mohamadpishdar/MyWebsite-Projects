 <?php
 ob_start();
 session_start(); 
 include 'func/connect2.php';
if (isset($_SESSION['captcha']) && isset($_POST['captcha'])) {
 if (strcmp(strtoupper($_POST['captcha']),$_SESSION['captcha']))
 {
	 	 $_SESSION['msg2']="لطفا در وارد کردن تصویر امنیتی دقت نمایید";
	 header('location:tamas.php');

 }
}
elseif (isset($_POST['nam']) && isset($_POST['matn'])){
$_SESSION['check']=1;
$re=$conecct->prepare("INSERT INTO `shopdb`.`tamas` (`nam` ,`moozoo` ,`email`,`matn`)VALUES ( ?, ?,? ,?);");
$re->bindValue(1,$_POST['nam']);$re->bindValue(2,$_POST['moozoo']);
$re->bindValue(3,$_POST['email']);$re->bindValue(4,$_POST['matn']);
$re->execute();
}
 header('location:tamas.php');
?>