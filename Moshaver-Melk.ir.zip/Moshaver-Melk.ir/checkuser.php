<?php 
ob_start();
session_start();
include 'func/funcs.php';
  include 'func/connect2.php';
 if (strcmp(strtoupper($_POST['captcha']),$_SESSION['captcha']))
 {
	 $_SESSION['msg']="لطفا در وارد کردن تصویر امنیتی دقت نمایید";
	 header('location:index.php');
 }
 else {
 $re=$conecct->prepare("select * from user where userid=? and pass=?");
 $re->bindValue(1,$_POST['us']);
 $passn=hash_value($_POST['pass']);
 $re->bindValue(2,$passn);
$re->execute(); 
 $rr=$re->fetch(PDO::FETCH_ASSOC);
  $re1=$conecct->prepare("update user set lastlogin='".getCurentDate ()."'where userid=? and pass=?");
 $re1->bindValue(1,$_POST['us']);
$re1->bindValue(2,$passn);
$re1->execute();
 if ( $re->rowCount()== 1){
 $_SESSION['login']=1;
 $_SESSION['uid']=$_POST['us'];
 $_SESSION['fn']=$rr['fname'];
 $_SESSION['ln']=$rr['lname'];
 $_SESSION['lastlogin']=$rr['lastlogin'];
 $_SESSION['msg']="";
 $_SESSION['shparvande']=$rr['shomareparvande'];
 $_SESSION['etebar']=$rr['etebar'];
  $_SESSION['address']=$rr['address'];
   $_SESSION['tell']=$rr['tell']; 
 }
 else
$_SESSION['login']=0;
 $_SESSION['msg']="لطفا در وارد  کردن نام کاربری یا کلمه ی عبور دقت کنید ";
header('location:index.php');
 }
?>