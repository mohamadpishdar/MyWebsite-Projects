<?php 
 include 'func/connect2.php' ;
$id = intval($_GET["id"]);



if (isset($id)){
	$p= $conecct->prepare("select * from product where productid =?");
	 $p->bindValue(1,$id);
	$p->execute();
	$rows=$p->fetch(PDO::FETCH_ASSOC);
	if ( $p->rowCount()== 1  ){
	exit($rows["axdo"]);
	}
}
?>