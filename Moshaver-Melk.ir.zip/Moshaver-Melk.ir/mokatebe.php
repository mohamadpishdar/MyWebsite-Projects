<?php 
ob_start();

$p='کاربر گرامی اطلاعات جدید خود را در فیلد های زیر وارد نمایید فیلد ها با مقادیر قبلی که ثبت کرده اید پر شده اند  ';
include 'func/connect2.php' ;
$re3=$conecct->prepare("select * from product where productid=?");
$re3->bindValue(1,checkGetParam($_GET['id']));$re3->execute();
$p=$re3->fetch(PDO::FETCH_ASSOC);
$payam=$p['payam'];
if ($payam==0){echo "<script language'javascript'0 >alert('پیام جدیدی برای این آگهی از طرف مدیر وجود ندارد');</script>)";}
$re4=$conecct->prepare("update product set payam=0 where productid=?");
$re4->bindValue(1,checkGetParam($_GET['id']));$re4->execute();


?>
<head>  
<title>ویرایش آگهی </title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
 <style type="text/css" media="screen">
		@import url(style.css );
		@import url(tab.css );
	body,td,th {
	color: #000;
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
}
   .middle .topmenu .content .content_bg .post .post_body table tr td p {
	text-align: right;
}
 .middle .topmenu .content .content_bg .post .post_body table tr td {
	text-align: right;
}
 </style>
<script src="js/jcarousellite_1.0.1c4.js" type="text/javascript"></script>
<script language="javascript" src="ckeditor/ckeditor.js"></script>
<script type="text/javascript" src="js/01.js"></script>
<script type="text/javascript" src="js/02.js"></script>
<script type="text/javascript" src="js/03.js"></script>
<script type="text/javascript" src="js/general.js"></script>
<script type="text/javascript">
function getElementsByClassName(className, tag, elm){
	var testClass = new RegExp("(^|\\s)" + className + "(\\s|$)");
	var tag = tag || "*";
	var elm = elm || document;
	var elements = (tag == "*" && elm.all)? elm.all : elm.getElementsByTagName(tag);
	var returnElements = [];
	var current;
	var length = elements.length;
	for(var i=0; i<length; i++){
		current = elements[i];
		if(testClass.test(current.className)){
			returnElements.push(current);
		}
	}
	return returnElements;
}

function addClassName(elm, className){
    var currentClass = elm.className;
    if(!new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i").test(currentClass)){
        elm.className = currentClass + ((currentClass.length > 0)? " " : "") + className;
    }
    return elm.className;
}

function removeClassName(elm, className){
    var classToRemove = new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i");
    elm.className = elm.className.replace(classToRemove, "").replace(/^\s+|\s+$/g, "");
    return elm.className;
}

function activateThisColumn(column) {
	var table = document.getElementById('pricetable');
	
	// first, remove the 'on' class from all other th's
	var ths = table.getElementsByTagName('th');
	for (var g=0; g<ths.length; g++) {
		removeClassName(ths[g], 'on');
	}
	// then, remove the 'on' class from all other td's
	var tds = table.getElementsByTagName('td');
	for (var m=0; m<tds.length; m++) {
		removeClassName(tds[m], 'on');
	}
	
	// now, add the class 'on' to the selected th
	var newths = getElementsByClassName(column, 'th', table);
	for (var h=0; h<newths.length; h++) {
		addClassName(newths[h], 'on');
	}
	// and finally, add the class 'on' to the selected td
	var newtds = getElementsByClassName(column, 'td', table);
	for (var i=0; i<newtds.length; i++) {
		addClassName(newtds[i], 'on');
	}
}
</script>
</head>
<body>
<div class="top"></div>
<div class="base">
<div class="middle">
<div class="logo">&nbsp;  
</div>
<div class="topmenu">
<div class="right"></div>
<?php include 'topmenu.php'; ?>
<div class="left">
</div><!--Top Menu -->
<div class="content">
<div class="content_top"></div>
<div class="content_bg">
<div id="right2">
		<div class="about"><div class="about_top"></div><div class="about_body">		<div class="menu_title">
		  <h6>دسته بندی </h6></div><div class="text">		<ul>
        <?php 
		$r=$conecct->query("select * from cat");
while ($rows =$r->fetch(PDO::FETCH_ASSOC))
			echo  '	<li><a href="?at=0&cat='.checkparam($rows['catid']).'" title="">'.checkparam($rows['name']).'</a></li>';
			?>
              <li><a href="index.php?flag=r" title="">رهن</a></li>	
            <li><a href="index.php?flag=e" title="">اجاره</a></li>	
            <li><a href="index.php?flag=er" title="">رهن و اجاره</a></li>
            <li><a href="index.php?flag=j" title="">جدید ترین آگهی ها</a></li>
            <li><a href="indx.php?flag=p" title="">پر بازدید ترین آگهی ها</a></li>	
				</ul>

		</div></div><div class="about_bottom"></div></div><!--Menu -->
        <p>`</p>
          <?php include 'login.php' ;    if ( $_SESSION['login']!=1 && $_SESSION['mosh']!=1)
header('location:index.php'); 
if (isset($_POST['exit'])){
if ($_SESSION['login']==1)
header('location:usercontrolpanel.php?id='.$_SESSION['shparvande']);
if ($_SESSION['mosh']==1)
header('location:moshavercontrolpanel.php?id='.($_SESSION['cod']*-1));	
}?>
          <p> <font color="" >.</font></p>
          <div class="customers_title"><div class="customers_icon"></div></div>
<div class="content anyClass_01">
<ul>
<?php 
		$r=$conecct->query("select * from news");
while ($rows =$r->fetch(PDO::FETCH_ASSOC)){

echo "<li>
 <div class='bcontent'>
<div class='author'><a href='page.html' >".checkparam( $rows['onvan'])."</a></div><div class='bcontent_top'></div>
<div class='bcontent_body'><div class='text'>"
.checkparam($rows['matn'])."
 <br />
</div></div>
<div class='bcontent_bottom'></div>
</div>
</li>

";
}
?>
</ul>
</div>
<div class="box_bottom"></div>
<!--Customers box -->
</div><!--Right -->
<div class="post" >
<form action="" method="post" >
<input type="submit" name="exit" id="exit" value="بازگشت به کنترل پنل"  /></form>
<div class="post_top">
  <h2>کاربر گرامی <?php if(isset($_GET['h'])==false){ echo checkparam($_SESSION['fn']). checkparam($_SESSION['ln' ]); } else { echo checkparam($_SESSION['masul']);}?> خوش آمدید</h2></div>
<div class="post_bottom">
<?php 
$re=$conecct->prepare("select * from product where productid=?");
$re->bindValue(1,checkGetParam($_GET['id']));
$re->execute();
$row=$re->fetch(PDO::FETCH_ASSOC);
?>
<form method="post" action="" enctype="multipart/form-data" >
 <table width="100%" border="1">
      <?php 
	  $mess="";
	  if (isset($_GET['h']))
	  $shparvande=($_SESSION['cod']);
	  else 
	  $shparvande=$_SESSION['shparvande'];
	  $re=$conecct->prepare("select * from mokatebe where shparvande=? and productid=?");
	  $re->bindValue(1,$shparvande);$re->bindValue(2,checkGetParam($_GET['id']));
	  $re->execute();
	  while ($rows3=$re->fetch(PDO::FETCH_ASSOC)){
		  echo '<tr><td bgcolor="#CC3399" >'.checkparam($rows3['tavasot']).' </td><td colspan="3">'.checkParam($rows3['matn']).'</td></tr>';
	  }
		    if (isset($_POST['sabt']) && $_POST['payam']!=''){
				$re4=$conecct->prepare("update product set payam=1 where productid=?");
$re4->bindValue(1,checkGetParam($_GET['id']));$re4->execute();
		  $mess="پیام شما با موفقیت ثبت گردید";
		$re2=$conecct->prepare("INSERT INTO `shopdb`.`mokatebe` (`shparvande`, `productid`, `matn`,`tavasot`) VALUES (?, ?, ?,?);");  
		$re2->bindValue(1,$shparvande);$re2->bindValue(2,checkGetParam($_GET['id']));$re2->bindValue(3,$_POST['payam'] );$re2->bindValue(4,' پاسخ کاربر: ' );
		$re2->execute();
	  
		  
	  }

?>
  <tr>      <td colspan="5">
      <form method="post" action="">
        <p>
          <label for="payam"></label>
          <textarea name="payam" id="payam" cols="85" rows="5" placeholder="اگر پیامی برای مدیر دارید اینجا بنویسید و بر روی دکمه ی ثبت کلیک نمایید ...." ></textarea>
        </p>
        <p>
          <input name="sabt" type="submit" class="dddd" id="sabt" value="ثبت پیام">
        </p>
</td>
    </tr>
     <tr >
 <td colspan="5" bgcolor="#00FFFF"><?php echo $mess; ?></td></tr>
</table>
</form>
</div>
<div id="left2">
</div><!--Left -->
</div>
<div class="content_bottom">
</div>
</div><!--Conetnt -->
<?php
include 'footer.php';
?>   
</body>
</html>
