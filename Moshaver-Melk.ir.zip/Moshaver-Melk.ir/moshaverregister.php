<script language="javascript">
function check (x1 ,x2 ,x3 ,x4,x5,x6,x7) 
{
if (x1=='' ){
alert("لطفا کد آژانس نزد اتحادیه املاک را وارد کنید");
document.getElementById('cod').focus();
return false ;
}
if (x2=='' ){
alert("لطفا نام آزانس را وارد کنید");
document.getElementById('name').focus();
return false ;
}
if (x3=='' ){
alert("لطفا نام خانوادگی مسئول آزانس را وارد کنید");
document.getElementById('masul').focus();
return false ;
}
if (x4=='' ){
alert("لطفا  کلمه ی عبور را وارد کنید");
document.getElementById('pass').focus();
return false ;
}
if (x5!=x4 ){
alert("کلمه های عبور یکسان نیستند");
document.getElementById('pass').focus();
return false ;
}
if (x6=='' ){
alert("لطفا منطقه را وارد کنید");
document.getElementById('pass').focus();
return false ;
}
if (x7=='' ){
alert("لطفا  تلفن همراه را وارد کنید");
document.getElementById('pass').focus();
return false ;
}
else 
return true ;
}
</script>
<script src="jquery.min.js" type="text/javascript" ></script>
<script type="text/javascript" >
$(document).ready(function (){
	$(".shahr").change(function(){
	var shahr=$(this).val();	
		$.post("ajax.php",{shahr:shahr},function(data){
			$(".namayesh").html(data);			
		});		
	});	
});
</script>
<head>
<title>ثبت نام مشاورین املاک</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
   <style type="text/css" media="screen">
		@import url(style.css );
		@import url(tab.css );
	body,td,th {
	color: #000;
}
   .middle .topmenu .content .content_bg #left2 table tr td strong {
	color: #FFF;
}
   .middle .topmenu .content .content_bg #left2 form p {
	text-align: center;
}
   </style>
<script src="js/jcarousellite_1.0.1c4.js" type="text/javascript"></script>
<script type="text/javascript" src="js/01.js"></script>
<script type="text/javascript" src="js/02.js"></script>
<script type="text/javascript" src="js/03.js"></script>
<script type="text/javascript" src="js/general.js"></script>
<script type="text/javascript">
function getElementsByClassName(className, tag, elm){
	var testClass = new RegExp("(^|\\s)" + className + "(\\s|$)");
	var tag = tag || "*";
	var elm = elm || document;
	var elements = (tag == "*" && elm.all)? elm.all : elm.getElementsByTagName(tag);
	var returnElements = [];
	var current;
	var length = elements.length;
	for(var i=0; i<length; i++){
		current = elements[i];
		if(testClass.test(current.className)){
			returnElements.push(current);
		}
	}
	return returnElements;
}

function addClassName(elm, className){
    var currentClass = elm.className;
    if(!new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i").test(currentClass)){
        elm.className = currentClass + ((currentClass.length > 0)? " " : "") + className;
    }
    return elm.className;
}

function removeClassName(elm, className){
    var classToRemove = new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i");
    elm.className = elm.className.replace(classToRemove, "").replace(/^\s+|\s+$/g, "");
    return elm.className;
}

function activateThisColumn(column) {
	var table = document.getElementById('pricetable');
	
	// first, remove the 'on' class from all other th's
	var ths = table.getElementsByTagName('th');
	for (var g=0; g<ths.length; g++) {
		removeClassName(ths[g], 'on');
	}
	// then, remove the 'on' class from all other td's
	var tds = table.getElementsByTagName('td');
	for (var m=0; m<tds.length; m++) {
		removeClassName(tds[m], 'on');
	}
	
	// now, add the class 'on' to the selected th
	var newths = getElementsByClassName(column, 'th', table);
	for (var h=0; h<newths.length; h++) {
		addClassName(newths[h], 'on');
	}
	// and finally, add the class 'on' to the selected td
	var newtds = getElementsByClassName(column, 'td', table);
	for (var i=0; i<newtds.length; i++) {
		addClassName(newtds[i], 'on');
	}
}
</script>
</head>
<body>
<div class="top"></div>
<div class="base">
<div class="middle">
<div class="logo">&nbsp; </div>
<div class="topmenu">
<div class="right"></div>
<script src="jquery.min.js" type="text/javascript" ></script>
<?php 
include 'topmenu.php';
include 'func/connect2.php';
?>
<div class="left">
</div><!--Top Menu -->
<div class="content">
<div class="content_top"></div>
<div class="content_bg">
<div id="right2">
		<div class="about"><div class="about_top"></div><div class="about_body">		<div class="menu_title">
		  <h6>دسته بندی کتاب ها </h6></div><div class="text">		<ul>
        <?php 
		$r=$conecct->query("select * from cat" );

while ($rows = $r->fetch(PDO::FETCH_ASSOC)) 
			echo  '	<li><a href="index.php?cat='.checkparam($rows['catid']).'&at=0" title="">'.checkparam($rows['name']).'</a></li>';
			?>	
            
              <li><a href="index.php?flag=r" title="">رهن</a></li>	
            <li><a href="index.php?flag=e" title="">اجاره</a></li>	
            <li><a href="index.php?flag=er" title="">رهن و اجاره</a></li>
            <li><a href="index.php?flag=j" title="">جدید ترین آگهی ها</a></li>
            <li><a href="indx.php?flag=p" title="">پر بازدید ترین آگهی ها</a></li>
				</ul>
		</div></div><div class="about_bottom"></div></div><!--Menu -->
        <p>`</p>
       <?php include 'login.php' ;?>
</div><!--Right -->
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {
$('#Loading').hide();    
});
function check_username(){
var cod = $("#cod").val();
if(cod.length < 4){
$('#Loading').show();
$('#Info').fadeOut();
 $('#Loading').hide();
setTimeout("finishAjax('Info', 'کد حداقل باید 4 کاراکتر باشد')", 450);
}
if(cod.length > 4){
$('#Loading').show();
$.post("check_username_availablity.php", {
cod: $('#cod').val(),
}, function(response){
$('#Info').fadeOut();
 $('#Loading').hide();
setTimeout("finishAjax('Info', '"+escape(response)+"')", 450);
});
return false;
}
}
function finishAjax(id, response){
$('#'+id).html(unescape(response));
$('#'+id).fadeIn(1000);
}
</script> 
<div id="left2" align="center" >
<form action="moshaverr.php" method="post"  onsubmit="return check(cod.value ,name.value,masul.value, pass.value , pass2.value ,mantaghe.value , tell.value)" >
<p ><?php if (isset($_SESSION['msg'])) echo  $_SESSION['msg'] ;  ?></p>
<p ><font color="#CCCCCC"> .</font> </p>
  <table width="500" border="2" align="center" cellpadding="10">
    <tr>
      <td height="33" colspan="3" bgcolor="#00CC66"><p><strong>لطفا فرم زیر را با دقت پر نمایید زیرا اطلاعات شما در هنگام معرفی مشتری به محل شما خیلی اهمیت دارد.</strong></p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <div id="Info" class="sefid" ></div>
<span id="Loading" ></span>
</div>
      
      </td>
      </tr> 
    
    <tr>
   
      <td width="183" bgcolor="#33CCFF">*کد آژانس نزد اتحادیه املاک :</td>
      <td colspan="2" bgcolor="#33CCFF"><label for="un"></label>
        <input type="text" name="cod" id="cod"  class="u" onBlur="return check_username();"/></td>
    </tr>
    <tr>
      <td height="45" bgcolor="#33CCFF">*نام  آژانس:</td>
      <td colspan="2" bgcolor="#33CCFF"><input type="text" name="name" id="name" /></td>
    </tr>
    <tr>
      <td bgcolor="#33CCFF"><p>*نام خانوادگی</p>
        <p> مسئول آژانس:</p></td>
      <td colspan="2" bgcolor="#33CCFF"><input type="text" name="masul" id="masul" /></td>
    </tr>
    <tr>
      <td bgcolor="#33CCFF">*کلمه عبور :</td>
      <td colspan="2" bgcolor="#33CCFF"><input type="password" name="pass" id="pass" /></td>
    </tr>
    <tr>
      <td bgcolor="#33CCFF">*تکرار کلمه عبور :</td>
      <td colspan="2" bgcolor="#33CCFF"><input type="password" name="pass2" id="pass2" /></td>
    </tr>
    <tr>
      <td bgcolor="#33CCFF">پست الکترونیک :</td>
      <td colspan="2" bgcolor="#33CCFF"><label for="mail"></label>
        <input type="text" name="mail" id="mail"></td>
    </tr>
    <tr>
      <td bgcolor="#33CCFF">*آدرس:</td>
      <td width="43" bgcolor="#33CCFF"><label for="shahr"></label>
        <label for="محله"></label>
        <label for="shahr">شهر</label>
        <select name="shahr" id="shahr" class="shahr">      
          <?php 
		$conecct->exec("SET CHARACTER SET UTF8");
		$re=$conecct->query("select DISTINCT shahrid,shahr  from map");
		$re->execute();
		while($rows2=$re->fetch(PDO::FETCH_ASSOC)){
		echo "  <option value='".$rows2['shahrid']."'  selected='selected'>".checkparam($rows2['shahr'])."</option>" ;				
		}
		?>
         <option value=''  selected='selected'>لطفا شهر را انتخاب نمایید</option>
        </select>                
        <div class="namayesh">
        </div>       
</td>
      <td width="196" bgcolor="#33CCFF"><label for="mantaghe">منطقه ی فعالیت</label>
        <input type="text" name="mantaghe" id="mantaghe"></td>
    </tr>
    <tr>
      <td bgcolor="#33CCFF">تلفن همراه :</td>
      <td colspan="2" bgcolor="#33CCFF"><label for="mobile"></label>
        <input type="text" name="mobile" id="mobile"></td>
    </tr>
    <tr>
      <td bgcolor="#33CCFF">*شماره تماس:</td>
      <td colspan="2" bgcolor="#33CCFF"><input type="text" name="tell" id="tell" class="tell" /></td>
    </tr>
    <tr>
      <td colspan="3" bgcolor="#CCFF33">لطفا پس از خواندن قوانین مربوط به مشاورین املاک در قسمت راهنمای سایت بر روی دکمه ی ثبت نام کلیک نمایید.</td>
    </tr>
    <tr>
      <td colspan="3" bgcolor="#CCFF33"><img src="func/captcha.php"/>&nbsp;</td>
    </tr>
    <tr>
      <td colspan="3" bgcolor="#CCFF33"><label for="captcha"></label>
                <input type="text" name="captcha" id="captcha" />
        </td>
    </tr>
    <tr>
      <td colspan="3" bgcolor="#990000"><input name="button3" type="reset" class="dddd" id="button3" value="پاک کردن" />
        <input type="submit" name="button" id="sabt" class="dddd" value="ثبت نام"  /></td>
      </tr>
  </table>
  </form>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>
<!--Left -->
</div>
<div class="content_bottom"></div>
</div><!--Conetnt -->
<?php
include 'footer.php';
?>
</body>
</html>
