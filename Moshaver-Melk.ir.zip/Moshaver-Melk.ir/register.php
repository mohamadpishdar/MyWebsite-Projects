﻿<script language="javascript">
function check (x1 ,x2 ,x3 ,x4,x5,x6) 
{
if (x1=='' ){
alert("لطفا نام کاربری را وارد کنید");
document.getElementById('un').focus();
return false ;
}
if (x2=='' ){
alert("لطفا نام  را وارد کنید");
document.getElementById('fn').focus();
return false ;
}
if (x3=='' ){
alert("لطفا نام خانوادگی را وارد کنید");
document.getElementById('ln').focus();
return false ;
}
if (x4=='' ){
alert("لطفا  کلمه ی عبور را وارد کنید");
document.getElementById('pass').focus();
return false ;
}
if (x5!=x4 ){
alert("کلمه های عبور یکسان نیستند");
document.getElementById('pass').focus();

return false ;
}
if (x6=='' ){
alert("لطفا شماره تماس خود را وارد نمایید");
document.getElementById('pass').focus();

return false ;
}
else 
return true ;

}
</script>
<head>
<title>ثبت نام کاربران عادی</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
   <style type="text/css" media="screen">
		@import url(style.css );
		@import url(tab.css );
	body,td,th {
	color: #000;
}
   .middle .topmenu .content .content_bg #left2 table tr td strong {
	color: #FFF;
}
   .middle .topmenu .content .content_bg #left2 form p {
	text-align: center;
}
   </style>
 <script src="js/jquery-1.4.2.min.js" type="text/javascript"></script>
<script src="js/jcarousellite_1.0.1c4.js" type="text/javascript"></script>
 <script src="sliderengine/jquery.js"></script>
<script type="text/javascript" src="js/01.js"></script>
<script type="text/javascript" src="js/02.js"></script>
<script type="text/javascript" src="js/03.js"></script>
<script type="text/javascript" src="js/general.js"></script>
<script type="text/javascript">
function getElementsByClassName(className, tag, elm){
	var testClass = new RegExp("(^|\\s)" + className + "(\\s|$)");
	var tag = tag || "*";
	var elm = elm || document;
	var elements = (tag == "*" && elm.all)? elm.all : elm.getElementsByTagName(tag);
	var returnElements = [];
	var current;
	var length = elements.length;
	for(var i=0; i<length; i++){
		current = elements[i];
		if(testClass.test(current.className)){
			returnElements.push(current);
		}
	}
	return returnElements;
}

function addClassName(elm, className){
    var currentClass = elm.className;
    if(!new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i").test(currentClass)){
        elm.className = currentClass + ((currentClass.length > 0)? " " : "") + className;
    }
    return elm.className;
}

function removeClassName(elm, className){
    var classToRemove = new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i");
    elm.className = elm.className.replace(classToRemove, "").replace(/^\s+|\s+$/g, "");
    return elm.className;
}

function activateThisColumn(column) {
	var table = document.getElementById('pricetable');
	
	// first, remove the 'on' class from all other th's
	var ths = table.getElementsByTagName('th');
	for (var g=0; g<ths.length; g++) {
		removeClassName(ths[g], 'on');
	}
	// then, remove the 'on' class from all other td's
	var tds = table.getElementsByTagName('td');
	for (var m=0; m<tds.length; m++) {
		removeClassName(tds[m], 'on');
	}
	
	// now, add the class 'on' to the selected th
	var newths = getElementsByClassName(column, 'th', table);
	for (var h=0; h<newths.length; h++) {
		addClassName(newths[h], 'on');
	}
	// and finally, add the class 'on' to the selected td
	var newtds = getElementsByClassName(column, 'td', table);
	for (var i=0; i<newtds.length; i++) {
		addClassName(newtds[i], 'on');
	}
}
</script>
</head>
<body>
<div class="top"></div>
<div class="base">
<div class="middle">
<div class="logo">&nbsp; </div>
<div class="topmenu">
<div class="right"></div><script type="text/javascript" src="jquery.min.js"></script>
<?php 
include 'topmenu.php';
include 'func/connect2.php';
?>
<div class="left">
</div><!--Top Menu -->
<div class="content">
<div class="content_top"></div>
<div class="content_bg">
<div id="right2">
		<div class="about"><div class="about_top"></div><div class="about_body">		<div class="menu_title">
		  <h6>دسته بندی کتاب ها </h6></div><div class="text">		<ul>
        <?php 
		$r=$conecct->query("select * from cat" );

while ($rows = $r->fetch(PDO::FETCH_ASSOC)) 
			echo  '	<li><a href="index.php?cat='.checkparam($rows['catid']).'&at=0" title="">'.checkparam($rows['name']).'</a></li>';
			?>	
            
              <li><a href="index.php?flag=r" title="">رهن</a></li>	
            <li><a href="index.php?flag=e" title="">اجاره</a></li>	
            <li><a href="index.php?flag=er" title="">رهن و اجاره</a></li>
            <li><a href="index.php?flag=j" title="">جدید ترین آگهی ها</a></li>
            <li><a href="indx.php?flag=p" title="">پر بازدید ترین آگهی ها</a></li>
				</ul>
		</div></div><div class="about_bottom"></div></div><!--Menu -->
        <p>`</p>
       <?php include 'login.php' ;?>
</div><!--Right -->
<script type="text/javascript">
$(document).ready(function() {
$('#Loading').hide();    
});
function check_username(){
var username = $("#username").val();
if(username.length < 2){
$('#Loading').show();
$('#Info').fadeOut();
 $('#Loading').hide();
setTimeout("finishAjax('Info', 'نام کاربری حداقل باید 2 کاراکتر باشد')", 450);
<?php 
	$_SESSION['sabtshode']=1;
	?>
}
if(username.length > 2){
	<?php 
	$_SESSION['sabtshode']=0;
	?>
$('#Loading').show();
$.post("check_username_availablity.php", {
username: $('#username').val(),
}, function(response){
$('#Info').fadeOut();
 $('#Loading').hide();
setTimeout("finishAjax('Info', '"+escape(response)+"')", 450);
});
return false;
}
}
function finishAjax(id, response){
$('#'+id).html(unescape(response));
$('#'+id).fadeIn(1000);
}
</script> 
<div id="left2" align="center" >
<form action="userregister.php" method="post"  onsubmit="return check(un.value ,fn.value,ln.value, pass.value , pass2.value,tell.value)" >
<p ><?php if (isset($_SESSION['msg'])) echo $_SESSION['msg'] ;  ?></p>
<p ><font color="#CCCCCC"> .</font> </p>
  <table width="500" border="2" align="center" cellpadding="10">
    <tr>
      <td height="33" colspan="2" bgcolor="#00CC66"><p><strong>لطفا فرم زیر را با دقت پر نمایید زیرا اطلاعات زیر در هنگام نوبت دهی بازدید حضوری ثبت خواهد شد . بدیهی است به اطلاعات غلط نوبت تعلق نمی گیرد .</strong></p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <div id="Info" class="sefid" ></div>
<span id="Loading" ></span>
</div>     
      </td>
      </tr>    
    <tr>   
      <td width="170" bgcolor="#33CCFF">*نام کاربری:</td>
      <td width="314" bgcolor="#33CCFF"><label for="un"></label>
        <input type="text" name="un" id="username"  class="u" onBlur="return check_username();"/></td>
    </tr>
    <tr>
      <td height="45" bgcolor="#33CCFF">*نام :</td>
      <td bgcolor="#33CCFF"><input type="text" name="fn" id="fn" /></td>
    </tr>
    <tr>
      <td bgcolor="#33CCFF">*نام خانوادگی :</td>
      <td bgcolor="#33CCFF"><input type="text" name="ln" id="ln" /></td>
    </tr>
    <tr>
      <td bgcolor="#33CCFF">*کلمه عبور :</td>
      <td bgcolor="#33CCFF"><input type="password" name="pass" id="pass" /></td>
    </tr>
    <tr>
      <td bgcolor="#33CCFF">*تکرار کلمه عبور :</td>
      <td bgcolor="#33CCFF"><input type="password" name="pass2" id="pass2" /></td>
    </tr>
    <tr>
      <td bgcolor="#33CCFF">آدرس:</td>
      <td bgcolor="#33CCFF"><textarea name="address" id="address"></textarea></td>
    </tr>
    <tr>
      <td bgcolor="#33CCFF">*شماره تماس:</td>
      <td bgcolor="#33CCFF"><input type="text" name="tell" id="tell" class="tell" /></td>
    </tr>
    <tr>
      <td colspan="2" bgcolor="#CCFF33">لطفا پس از خواندن قوانین مربوط به کاربران عادی در قسمت راهنمای سایت بر روی دکمه ی ثبت نام کلیک نمایید.</td>
    </tr>
    <tr>
      <td colspan="2" bgcolor="#CCFF33"><img src="func/captcha.php"/>&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2" bgcolor="#CCFF33"><label for="captcha"></label>
                <input type="text" name="captcha" id="captcha" />
        </td>
    </tr>
    <tr>
      <td colspan="2" bgcolor="#990000"><input name="button3" type="reset" class="dddd" id="button3" value="پاک کردن" />
        <input type="submit" name="button" id="sabt" class="dddd" value="ثبت نام"  /></td>
      </tr>
  </table>
  </form>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>
<!--Left -->
</div>
<div class="content_bottom"></div>
</div><!--Conetnt -->
<?php
include 'footer.php';
?>
</body>
</html>
