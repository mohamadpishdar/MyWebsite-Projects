﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
﻿<?php 
include 'func/connect2.php';
?>
<head>
 <script src="sliderengine/jquery.js"></script>
<title>جستجو</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
 <style type="text/css" media="screen">
		@import url(style.css );
		@import url(tab.css );
	body,td,th {
	color: #000;
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
}
   .middle .topmenu .content .content_bg .post .post_body table tr td p {
	text-align: right;
}
 .middle .topmenu .content .content_bg .post .post_body table tr td {
	text-align: right;
}
 </style>
<script src="js/jcarousellite_1.0.1c4.js" type="text/javascript"></script>
<script type="text/javascript" src="js/01.js"></script>
<script type="text/javascript" src="js/02.js"></script>
<script type="text/javascript" src="js/03.js"></script>
<script type="text/javascript" src="js/general.js"></script>
<script type="text/javascript">
function getElementsByClassName(className, tag, elm){
	var testClass = new RegExp("(^|\\s)" + className + "(\\s|$)");
	var tag = tag || "*";
	var elm = elm || document;
	var elements = (tag == "*" && elm.all)? elm.all : elm.getElementsByTagName(tag);
	var returnElements = [];
	var current;
	var length = elements.length;
	for(var i=0; i<length; i++){
		current = elements[i];
		if(testClass.test(current.className)){
			returnElements.push(current);
		}
	}
	return returnElements;
}

function addClassName(elm, className){
    var currentClass = elm.className;
    if(!new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i").test(currentClass)){
        elm.className = currentClass + ((currentClass.length > 0)? " " : "") + className;
    }
    return elm.className;
}

function removeClassName(elm, className){
    var classToRemove = new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i");
    elm.className = elm.className.replace(classToRemove, "").replace(/^\s+|\s+$/g, "");
    return elm.className;
}

function activateThisColumn(column) {
	var table = document.getElementById('pricetable');
	
	// first, remove the 'on' class from all other th's
	var ths = table.getElementsByTagName('th');
	for (var g=0; g<ths.length; g++) {
		removeClassName(ths[g], 'on');
	}
	// then, remove the 'on' class from all other td's
	var tds = table.getElementsByTagName('td');
	for (var m=0; m<tds.length; m++) {
		removeClassName(tds[m], 'on');
	}
	
	// now, add the class 'on' to the selected th
	var newths = getElementsByClassName(column, 'th', table);
	for (var h=0; h<newths.length; h++) {
		addClassName(newths[h], 'on');
	}
	// and finally, add the class 'on' to the selected td
	var newtds = getElementsByClassName(column, 'td', table);
	for (var i=0; i<newtds.length; i++) {
		addClassName(newtds[i], 'on');
	}
}
</script>
</head>
<body>
<div class="top"></div>
<div class="base">
<div class="middle">
<div class="logo">&nbsp;   
</div>
<div class="topmenu"> 
<div class="right"></div>
<?php include 'topmenu.php'; ?>
<div class="left">
</div><!--Top Menu -->
<div class="content">
<div class="content_top"></div>
<div class="content_bg">
<div id="right2">
		<div class="about"><div class="about_top"></div><div class="about_body">		<div class="menu_title">
		  <h6>دسته بندی کتاب ها </h6></div><div class="text">		<ul>
        <?php 
		$r=$conecct->query("select * from cat" );

while ($rows = $r->fetch(PDO::FETCH_ASSOC)) 
			echo  '	<li><a href="index.php?at=0&cat='.checkparam($rows['catid']).'" title="">'.checkparam($rows['name']).'</a></li>';
			?>
              <li><a href="index.php?flag=r" title="">رهن</a></li>	
            <li><a href="index.php?flag=e" title="">اجاره</a></li>	
            <li><a href="index.php?flag=er" title="">رهن و اجاره</a></li>
            <li><a href="index.php?flag=j" title="">جدید ترین آگهی ها</a></li>
            <li><a href="indx.php?flag=p" title="">پر بازدید ترین آگهی ها</a></li>	
				</ul>
		</div></div><div class="about_bottom"></div></div><!--Menu -->
        <p>`</p>
          <?php include 'login.php' ;?>         
          <p> <font color="" >.</font></p>          
          <div class="customers_title"><div class="customers_icon"></div></div>
<div class="about">
<div class="content anyClass_01">
<ul>
<?php 
$rows =$conecct->query("select * from news " );
while ($result= $rows->fetch(PDO::FETCH_ASSOC) ){ 
echo "<li>
 <div class='bcontent'>
<div class='author'><a href='page.html' >". checkparam($result['onvan'])."</a></div><div class='bcontent_top'></div>
<div class='bcontent_body'><div class='text'>"
.checkparam($result['matn'])."
 <br />
</div></div>
<div class='bcontent_bottom'></div>
</div>
</li>
";
}
?>
</ul>
</div>
</div>
<div class="box_bottom"></div>
<!--Customers box -->
</div><!--Right -->
<div class="post" >
<div class="post_top"><h2>جستجو</h2></div>
<div class="post_body">
<form action="" method="post">
  <table width="100%" border="0" bordercolor="#000000" cellpadding="10" align="right"   >
    <tr>
      <td   height="22" bgcolor="#0099FF"><label for="moamele">جستجو در آگهی های  :</label>
        <select name="moamele" id="moamele">
          <option>فروش</option>
          <option>رهن</option>
          <option>اجاره</option>
        </select></td>
      <td height="22" bgcolor="#0099FF">آدرس استان : 
        <label for="ostan"></label>
        <select name="ostan" id="ostan">
          <option>قزوین</option>
        </select></td>
      <td height="22" bgcolor="#0099FF">&nbsp;</td>
    </tr>
    <tr>
      <td   height="22" bgcolor="#33CCFF">آدرس شهر : 
        <label for="shahr"></label>
        <select name="shahr" id="shahr">
          <option>قزوین</option>
        </select></td>
      <td height="22" bgcolor="#33CCFF">منطقه : 
        <label for="mantaghe"></label>
        <select name="mantaghe" id="mantaghe">
          <option>مینودر</option>
          <option>کوثر</option>
        </select></td>
      <td height="22" bgcolor="#33CCFF">&nbsp;</td>
    </tr>
    <tr>
      <td   height="22" bgcolor="#0099FF">سند:
        <label for="sanad"></label>
        <select name="sanad" id="sanad">
          <option>شخصی</option>
          <option>تجاری</option>
        </select>
      <td height="22" bgcolor="#0099FF">ملک مورد نظر شما بالکن : 
        <label for="balkon2"></label>
        <select name="balkon" id="balkon2">
          <option>دارد</option>
          <option>ندارد</option>
        </select></td>
      <td height="22" bgcolor="#0099FF">&nbsp;</td>
    </tr>
    <tr>
      <td width="43%"   height="22" bgcolor="#33CCFF"><p>&nbsp;</p>
        
        <p>سرویس بهداشتی :
          <label for="nkala"></label>
          <label for="servis"></label>
          <select name="servis" id="servis">
            <option>ایرانی</option>
            <option>فرنگی</option>
            <option>هم ایرانی هم فرنگی</option>
          </select>
        </p>
        <p>&nbsp;</p></td>
      <td height="22" bgcolor="#33CCFF">دسته : <select name="daste" id="daste">       
        <?php 
              $r=$conecct->query("select * from cat" );
$i=0;
while ($rows = $r->fetch(PDO::FETCH_ASSOC )) {
	echo '<option value="'.checkparam($rows['catid']).'" >'.checkparam($rows['name']).'</option>';
	
}
               ?>
      </select></td>
      <td height="22" bgcolor="#33CCFF">&nbsp;</td>
      </tr>
    <tr>
      <td bgcolor="#0099FF"><label for="otagh">تعداد اتاق خواب :</label>
        <input type="text" name="otagh" id="otagh" /></td>
      <td bgcolor="#0099FF"><label for="nosaz">ملک مورد نظر شما </label>
        آسانسور 
          <label for="asansor2"></label>
          <select name="asansor" id="asansor2">
            <option>دارد</option>
            <option>ندارد</option>
          </select>
          <label for="asansor"></label></td>
      <td bgcolor="#0099FF">&nbsp;</td>
    </tr>
    <tr>
      <td bgcolor="#33CCFF">ملک مورد نظر شما پارکینگ : 
        <label for="parking2"></label>
        <select name="parking" id="parking2">
          <option>دارد</option>
          <option>ندارد</option>
        </select>
        <label for="parking"></label></td>
      <td bgcolor="#33CCFF"><label for="metraz"></label>
        <label for="tabaghe">طبقه:</label>
        <input type="text" name="tabaghe" id="tabaghe" /></td>
      <td bgcolor="#33CCFF">&nbsp;</td>
    </tr>
    <tr>
      <td bgcolor="#0099FF"><label for="metraz">متراژ از</label>
        <input name="metraz" type="text" id="metraz" value="0" /></td>
      <td bgcolor="#0099FF"><label for="metrta">متراژ تا :</label>
        <input name="metrta" type="text" id="metrta" value="1000000" /></td>
      <td bgcolor="#0099FF">&nbsp;</td>
    </tr>
    <tr>
      <td bgcolor="#33CCFF">ملک مورد نظر شما آشپزخانه : 
        <label for="ashpazkhane3"></label>        <select name="ashpazkhane" id="ashpazkhane3">
          <option>دارد</option>
          <option>ندارد</option>
        </select>        <label for="ashpazkhane"></label></td>
      <td bgcolor="#33CCFF">&nbsp;</td>
      <td bgcolor="#33CCFF">&nbsp;</td>
    </tr>
    <tr>
      <td bgcolor="#0099FF">سال ساخت از سال :  
        <label for="salaz"></label>
        <input name="salaz" type="text" id="salaz" value="1370" />        <label for="nosaz"></label></td>
      <td bgcolor="#0099FF">تا سال : 
        <label for="salta"></label>
        <input name="salta" type="text" id="salta" value="1394" /></td>
      <td bgcolor="#0099FF">&nbsp;</td>
    </tr>
    <tr>
      <td bgcolor="#33CCFF"><label for="kabinet">کابینت :</label>
        <select name="kabinet" id="kabinet">
          <option>معمولی</option>
          <option>mdf</option>
        </select></td>
      <td bgcolor="#33CCFF">دیوار : 
        <label for="divar"></label>
        <select name="divar" id="divar">
          <option>گچ</option>
          <option>الیاف</option>
        </select></td>
      <td bgcolor="#33CCFF">&nbsp;</td>
    </tr>
    <tr>
      <td bgcolor="#0099FF">قیمت کل از 
        
        <label for="az"></label>
        <input name="az" type="text" id="az" value="0" /></td>
      <td width="41%" bgcolor="#0099FF">تا 
        <label for="ta"></label>
        <input name="ta" type="text" id="ta" value="100000000000" /></td>
      <td width="16%" bgcolor="#0099FF"><input name="sub" type="submit" class="dddd" id="sub" style="left: 554px; top: 2493px;"  value="جستجو" /></td>
    </tr>	  
	   	  </table>
</form>
</div>
<div class="post_bottom"></div>
</div>
<div id="left2">
<?php 
$k12=false;
if (isset($_POST["sub"])){
	$pp="select * from product where taeed=1 and catid=? and moamele like ?  and parking like ?  and sanad like ?  and divar like ? and balkon like ?   and otagh like ?  and dastshooi like ?   and asansor like ?  and ashpazkhane like ? and gheymat>=? and gheymat<=? and zirbana>=? and zirbana<=? and chandsale>=? and chandsale<=? and address like ? limit 0,30" ;	
	$rows=$conecct->prepare($pp);
	$rows->bindValue(1,$_POST['daste']);$rows->bindValue(2,$_POST['moamele']);$rows->bindValue(3,$_POST['parking']);$rows->bindValue(4,$_POST['sanad']);$rows->bindValue(5, $_POST['divar']);$rows->bindValue(6,$_POST['balkon']);$rows->bindValue(7,$_POST['otagh']);$rows->bindValue(8,$_POST['servis']);$rows->bindValue(9,$_POST['asansor']);$rows->bindValue(10,$_POST['ashpazkhane']);$rows->bindValue(11,$_POST['az']);$rows->bindValue(12,$_POST['ta']);$rows->bindValue(13,$_POST['metraz']);$rows->bindValue(14,$_POST['metrta']);$rows->bindValue(15,$_POST['salaz']);$rows->bindValue(16,$_POST['salta']);
	$rows->bindValue(17,"%استان: ".$_POST['ostan']."| شهر: ".$_POST['shahr']."| منطقه: ".$_POST['mantaghe']."%" );
	$rows->execute();
	$k12=true;	
}
if ($k12==true){	
if ($rows->rowCount()==0){
	echo '
<div class="post" >متاسفیم چنین موردی در حال حاضر در سایت وجود ندارد</div>
';	
}
while ($r=$rows->fetch(PDO::FETCH_ASSOC ))
{	
$p=$conecct->prepare("select * from cat where catid =?");
$p->bindValue(1,$r['catid']);$p->execute();
$k=$p->fetch(PDO::FETCH_ASSOC);
echo '
<div class="post" >
<div class="post_top"><h2><a href="#">آدرس : '. checkparam($r['address']).'</a></h2></div>
<div class="post_body">
  <table width="100%" border="1" bordercolor="#000000" cellpadding="10"   >
    <tr>
      <td height="22" colspan="2"><p>&nbsp;</p>
        <p>قیمت متری : '.checkparam($r['metri']).' تومان</p>
        <p>زیر بنا : '.checkparam($r['zirbana']).'  متر مربع</p>
        <p>نوع آگهی : '.checkparam($r['moamele']).'</p>
		  <p>تعداد اتاق : '.checkparam($r['otagh']).' </p></td>
      <td rowspan="2"><img src="adminpane/product/pic.php?id='.checkparam($r['productid']).'"width=200 height=200 </td>
    </tr>
    <tr>
      <td>قیمت کل : '.checkparam($r['gheymat']).' تومان 
	   <p>تاریخ انتشار: '.checkparam($r['tarikh']).'</p></td>
      <td>نوع دسته : '.checkparam($k['name']).' </td>
      </tr>';	  
	   if( $_SESSION['login']!=1){
	   echo '	 <tr ><td colspan="3">برای مشاهده داخل ملک و مشخصات کامل لطفا وارد حساب خود شوید </td></tr>;' ;
       }
	    else {
			 echo '  
	  
	  <tr align="left"><td colspan="3"> <a href=moshakhasat.php?id='.checkparam($r['productid']).'> <img src="images/home.png" width=50 height=50  />برای مشاهده داخل ملک و اطلاعات بیشتر کلیک نمایید </a> </td></tr>';
		
		}
		echo '
  </table>

</div>
<div class="post_bottom"></div>
</div>';
}
}
?>

</div><!--Left -->
</div>
<div class="content_bottom">
</div>
</div><!--Conetnt -->
<?php
include 'footer.php';
?>   
</body>
</html>
