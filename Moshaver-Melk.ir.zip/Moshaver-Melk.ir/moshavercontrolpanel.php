<?php 
ob_start();
$peygham="لطفا اطلاعات زیر را با دقت پر نمایید";
include 'func/connect2.php' ;
if (isset($_POST['tell']) &&$_POST['tell']!="" ) {
	$re=$conecct->prepare("update user set tell=? where cod=?");
	$re->bindValue(1,$_POST['tell']);	$re->bindValue(2,$_GET['id']);
$re->execute();
	$peygham="تغییرات با موفقیت ثبت گردید";
}
if (isset($_POST['pass']) && $_POST['pass']!="") {
	$re=$conecct->prepare("update user set pass=? where cod=?");
	$passn=hash_value($_POST['pass']);
	$re->bindValue(1,$passn);	$re->bindValue(2,$_GET['id']);
$re->execute();		$peygham="تغییرات با موفقیت ثبت گردید";}
$r=$conecct->query("select * from product");
$num=$r->rowCount();$num=$num+5;
for ($i=1 ; $i<=$num ; $i++){
if (isset($_POST["c".$i])){ 
$result=$conecct->prepare("delete from product where productid=? ");
$result->bindValue(1,$_POST["c".$i]);
$result->execute();}
}
$rows3=$conecct->prepare("select * from moshaver where cod =?");
$rows3->bindValue(1,$_GET['id']);
$rows3->execute();$rows3=$rows3->fetch(PDO::FETCH_ASSOC);
?>
<head>
 <script src="sliderengine/jquery.js"></script>
    <script src="sliderengine/amazingslider.js"></script>
    <link rel="stylesheet" type="text/css" href="sliderengine/amazingslider-1.css">
    <script src="sliderengine/initslider-1.js"></script>

<title>کنترل پنل مشاور املاک</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	

 <style type="text/css" media="screen">
		@import url(style.css );
		@import url(tab.css );
	body,td,th {
	color: #000;
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
}
   .middle .topmenu .content .content_bg .post .post_body table tr td p {
	text-align: right;
}
 .middle .topmenu .content .content_bg .post .post_body table tr td {
	text-align: right;
}
 </style>
<script src="js/jcarousellite_1.0.1c4.js" type="text/javascript"></script>
<script type="text/javascript" src="js/01.js"></script>
<script type="text/javascript" src="js/02.js"></script>
<script type="text/javascript" src="js/03.js"></script>
<script type="text/javascript" src="js/general.js"></script>
<script type="text/javascript">
function getElementsByClassName(className, tag, elm){
	var testClass = new RegExp("(^|\\s)" + className + "(\\s|$)");
	var tag = tag || "*";
	var elm = elm || document;
	var elements = (tag == "*" && elm.all)? elm.all : elm.getElementsByTagName(tag);
	var returnElements = [];
	var current;
	var length = elements.length;
	for(var i=0; i<length; i++){
		current = elements[i];
		if(testClass.test(current.className)){
			returnElements.push(current);
		}
	}
	return returnElements;
}

function addClassName(elm, className){
    var currentClass = elm.className;
    if(!new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i").test(currentClass)){
        elm.className = currentClass + ((currentClass.length > 0)? " " : "") + className;
    }
    return elm.className;
}

function removeClassName(elm, className){
    var classToRemove = new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i");
    elm.className = elm.className.replace(classToRemove, "").replace(/^\s+|\s+$/g, "");
    return elm.className;
}

function activateThisColumn(column) {
	var table = document.getElementById('pricetable');
	
	// first, remove the 'on' class from all other th's
	var ths = table.getElementsByTagName('th');
	for (var g=0; g<ths.length; g++) {
		removeClassName(ths[g], 'on');
	}
	// then, remove the 'on' class from all other td's
	var tds = table.getElementsByTagName('td');
	for (var m=0; m<tds.length; m++) {
		removeClassName(tds[m], 'on');
	}
	
	// now, add the class 'on' to the selected th
	var newths = getElementsByClassName(column, 'th', table);
	for (var h=0; h<newths.length; h++) {
		addClassName(newths[h], 'on');
	}
	// and finally, add the class 'on' to the selected td
	var newtds = getElementsByClassName(column, 'td', table);
	for (var i=0; i<newtds.length; i++) {
		addClassName(newtds[i], 'on');
	}
}
</script>
</head>
<body>
<div class="top"></div>
<div class="base">
<div class="middle">
<div class="logo">&nbsp; 
  
</div>
<div class="topmenu">

  
<div class="right"></div>
<?php include 'topmenu.php'; ?>
<div class="left">

</div><!--Top Menu -->

<div class="content">
<div class="content_top"></div>
<div class="content_bg">
<div id="right2">
		<div class="about"><div class="about_top"></div><div class="about_body">		<div class="menu_title">
		  <h6>دسته بندی </h6></div><div class="text">		<ul>
        <?php 
		$r=$conecct->query("select * from cat");
while ($rows =$r->fetch(PDO::FETCH_ASSOC)) 
			echo  '	<li><a href="index.php?at=0&cat='.checkparam($rows['catid']).'" title="">'.checkparam($rows['name']).'</a></li>';
			?>
              <li><a href="index.php?flag=r" title="">رهن</a></li>	
            <li><a href="index.php?flag=e" title="">اجاره</a></li>	
            <li><a href="index.php?flag=er" title="">رهن و اجاره</a></li>
            <li><a href="index.php?flag=j" title="">جدید ترین آگهی ها</a></li>
            <li><a href="indx.php?flag=p" title="">پر بازدید ترین آگهی ها</a></li>	
				</ul>
		</div></div><div class="about_bottom"></div></div><!--Menu -->
        <p>`</p>
          <?php include 'login.php' ;
		  if (isset($_POST['exit']))
		  $_SESSION['mosh']=0;
 if ( $_SESSION['mosh']!=1)
header('location:index.php');
          ?>
          <script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript">
var sel=-1;
function cc() {	
	sel=$("#select").val();
$.post("ajax.php" , {sel:sel } , function (data) {
$(".namayesh").html(data);	
});
}
function bb() {	
var selp=$("#selectpage").val();
$.post("ajax.php" , {selp:selp ,sel:sel} , function (data1) {
$(".namayesh").html(data1);

	});
}
</script> 
         <p> <font color="" >.</font></p>         
          <div class="customers_title"><div class="customers_icon"></div></div>
<div class="content anyClass_01">
<ul>
<?php $n="n"; 
$rows =$conecct->query("select * from news limit 0,5");
while ($result= $rows->fetch(PDO::FETCH_ASSOC)){ 
echo "<li>
 <div class='bcontent'>
<div class='author'><a href='page.html' >".checkparam( $result['onvan'])."</a></div><div class='bcontent_top'></div>
<div class='bcontent_body'><div class='text'>"
.checkparam($result['matn'])."
 <br />
</div></div>
<div class='bcontent_bottom'></div>
</div>
</li>
";
}
?>
</ul>
</div>
<div class="box_bottom"></div>
<!--Customers box -->
</div><!--Right -->
<div class="post" >
<div class="post_top">
  <h2>مشاور املاک <?PHP ECHO checkparam($_SESSION['namemosh']) ;?>  خوش آمدید</h2></div>
</div>
<div id="left2">
<form method="post" action="" >
  <table width="100%" border="1">
    <tr>
      <td bgcolor="#0033CC" colspan="5"><font color="#FFFFFF"><?php echo checkparam($peygham); ?></font></td><td>   <input type="submit" name="exit" id="exit" value="خروج" class="dddd"</td>
      </tr>
    <tr>
      <td colspan="2">تلفن تماس جدید</td>
      <td><label for="tell"></label>
        <input type="text" name="tell" id="tell" placeholder="تلفن تماس جدید خود را وارد نمایید"></td>
      <td colspan="2">کلمه ی عبور جدید</td>
      <td><label for="pass"></label>
        <input type="text" name="pass" id="pass"></td>
    </tr>
    <tr>
      <td colspan="2">تلفن تماس فعلی</td>
      <td><?php echo checkparam($_SESSION['tellm']); ?></td>
      <td colspan="2"  bgcolor="#00CCCC">نام مسئول</td>
      <td bgcolor="#00CCCC"><?php echo $_SESSION['masul'];?>
    </tr>
    <tr>
      <td colspan="2">آدرس فعلی شما</td>
      <td colspan="3"><?php echo checkparam( $_SESSION['addressm']); ?></td>
      <td><textarea name="address" id="address" cols="35" rows="5" placeholder="آدرس جدید خود را اینجا وارد نمایید"></textarea></td>
      <tr>
        <td colspan="6"><input type="submit" name="sabt" id="sabt" value="ثبت تغییرات"></td>
        </tr>
      <tr>
      <td colspan="2">میزان اعتبار شما</td>
      <td width="148"></td>
      <td colspan="2">خرید اعتبار</td>
      <td width="249">لینک </td>
    </tr>
    <tr>
    </tr>
    <tr>
    <td width="170" colspan="2"> ثبت آگهی حراج</td>
    <td colspan="4" bgcolor="#0066FF"><a href="sabtagahi.php?h=1"  ><font color="#FFFFFF" >برای ثبت اگهی فروش حراج جدید اینجا کلیک کنید</font></a> </td>
    </tr>
    <tr>  
      <td width="114" colspan="2">ثبت آگهی</td>
      <td colspan="4" bgcolor="#FF0066"><a href="sabtagahi.php?h=0"  >برای ثبت اگهی جدید اینجا کلیک کنید</a> </td>
    </tr>    
    <tr>
      <td colspan="6">&nbsp;</td>
    </tr>
    <tr>
    <td colspan="7">آگهی های شما </td>   
    </tr>
       <tr ><td colspan="7">
        <label for="search">جستجو بر اساس شماره آگهی</label>
        <input type="text" name="search" id="search">
        <input type="submit" name="sub2" id="sub2" value="جستجو" ></td>
      </tr>
    <tr> 
      <td bgcolor="#CC6633" colspan="7"><label for="select"></label>
        <select name="select" id="select" onChange="cc();">
          <option>نوع نمایش را انتخاب نمایید</option>
          <option  value="1">نمایش آگهی های عادی</option>
          <option value="2">نمایش آگهی های حراج</option>
        </select></td></tr>
  </table>
      </form>   
<div class="namayesh"></div></table> </form>
</div><!--Left -->
</div>
<div class="content_bottom">
</div>
</div><!--Conetnt -->
<?php
include 'footer.php';
?>   
</body>
</html>
