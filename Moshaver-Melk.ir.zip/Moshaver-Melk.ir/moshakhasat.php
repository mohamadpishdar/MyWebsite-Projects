<?php 
ob_start();
include 'func/connect2.php' ;
if (isset($_GET['id'])) {
	$id=checkGetParam($_GET['id']);
	$re=$conecct->prepare("update product set bazdid=(bazdid+1) where productid=?");
	$re->bindValue(1,$id);
	$re->execute();	
}
$tell="برای نمایش تلفن و ثبت مشخصات شما برای نوبت بازدید بر روی دکمه ی زیر کلیک نمایید";
?>
<head>
  <script src="sliderengine2/jquery.js"></script>
    <script src="sliderengine2/amazingslider.js"></script>
    <link rel="stylesheet" type="text/css" href="sliderengine2/amazingslider-1.css">
    <script src="sliderengine2/initslider-1.js"></script>
<title>مشخصات کامل ملک</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
 <style type="text/css" media="screen">
		@import url(style.css );
		@import url(tab.css );
	body,td,th {
	color: #000;
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
}
   .middle .topmenu .content .content_bg .post .post_body table tr td p {
	text-align: right;
}
 .middle .topmenu .content .content_bg .post .post_body table tr td {
	text-align: right;
}
 </style>
<script src="js/jcarousellite_1.0.1c4.js" type="text/javascript"></script>
<script type="text/javascript" src="js/01.js"></script>
<script type="text/javascript" src="js/02.js"></script>
<script type="text/javascript" src="js/03.js"></script>
<script type="text/javascript" src="js/general.js"></script>
<script type="text/javascript">
function getElementsByClassName(className, tag, elm){
	var testClass = new RegExp("(^|\\s)" + className + "(\\s|$)");
	var tag = tag || "*";
	var elm = elm || document;
	var elements = (tag == "*" && elm.all)? elm.all : elm.getElementsByTagName(tag);
	var returnElements = [];
	var current;
	var length = elements.length;
	for(var i=0; i<length; i++){
		current = elements[i];
		if(testClass.test(current.className)){
			returnElements.push(current);
		}
	}
	return returnElements;
}

function addClassName(elm, className){
    var currentClass = elm.className;
    if(!new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i").test(currentClass)){
        elm.className = currentClass + ((currentClass.length > 0)? " " : "") + className;
    }
    return elm.className;
}

function removeClassName(elm, className){
    var classToRemove = new RegExp(("(^|\\s)" + className + "(\\s|$)"), "i");
    elm.className = elm.className.replace(classToRemove, "").replace(/^\s+|\s+$/g, "");
    return elm.className;
}

function activateThisColumn(column) {
	var table = document.getElementById('pricetable');
	
	// first, remove the 'on' class from all other th's
	var ths = table.getElementsByTagName('th');
	for (var g=0; g<ths.length; g++) {
		removeClassName(ths[g], 'on');
	}
	// then, remove the 'on' class from all other td's
	var tds = table.getElementsByTagName('td');
	for (var m=0; m<tds.length; m++) {
		removeClassName(tds[m], 'on');
	}
	
	// now, add the class 'on' to the selected th
	var newths = getElementsByClassName(column, 'th', table);
	for (var h=0; h<newths.length; h++) {
		addClassName(newths[h], 'on');
	}
	// and finally, add the class 'on' to the selected td
	var newtds = getElementsByClassName(column, 'td', table);
	for (var i=0; i<newtds.length; i++) {
		addClassName(newtds[i], 'on');
	}
}
</script>
</head>
<body>
<div class="top"></div>
<div class="base">
<div class="middle">
<div class="logo">&nbsp;  
</div>
<div class="topmenu">  
<div class="right"></div>
<?php include 'topmenu.php'; ?>
<div class="left">
</div><!--Top Menu -->
<div class="content">
<div class="content_top"></div>
<div class="content_bg">
<div id="right2">
		<div class="about"><div class="about_top"></div><div class="about_body">		<div class="menu_title">
		  <h6>دسته بندی کتاب ها </h6></div><div class="text">		<ul>
        <?php 
		$r=$conecct->query("select * from cat" );

while ($rows = $r->fetch(PDO::FETCH_ASSOC)) 
			echo  '	<li><a href=index.php?at=0&cat='.checkparam($rows['catid']).'" title="">'.checkparam($rows['name']).'</a></li>';
			?>
              <li><a href="index.php?flag=r" title="">رهن</a></li>	
            <li><a href="index.php?flag=e" title="">اجاره</a></li>	
            <li><a href="index.php?flag=er" title="">رهن و اجاره</a></li>
            <li><a href="index.php?flag=j" title="">جدید ترین آگهی ها</a></li>
            <li><a href="indx.php?flag=p" title="">پر بازدید ترین آگهی ها</a></li>	
				</ul>
		</div></div><div class="about_bottom"></div></div><!--Menu -->
        <p>`</p>
          <?php include 'login.php' ;
		  if ($_SESSION['login']!=1) {
			  $_SESSION['gheirmojaz']=1;
		  header('location:index.php');		  
		  }
		  ?>         
          <p> <font color="" >.</font></p>
         <div class="customers_title"><div class="customers_icon"></div></div>
<div class="content anyClass_01">
<ul>
<?php 
$rows =$conecct->query("select * from news " );
while ($result= $rows->fetch(PDO::FETCH_ASSOC)){ 
echo "<li>
 <div class='bcontent'>
<div class='author'><a href='page.html' >".checkparam( $result['onvan'])."</a></div><div class='bcontent_top'></div>
<div class='bcontent_body'><div class='text'>"
.checkparam($result['matn'])."
 <br />
</div></div>
<div class='bcontent_bottom'></div>
</div>
</li>
";
}
?>
</ul>
</div>
<div class="box_bottom"></div>
<!--Customers box -->
</div><!--Right -->
<div class="post" >
<div class="post_top">
  <h2>مشخصات کامل</h2></div>
<div class="post_bottom">
</div>
</div>
<?php 
if (isset($_POST['sabt']) ){
$tell="تلفن  تماس : 09199286674";
$id=checkGetParam($_GET['id']);
$r=$conecct->prepare("INSERT INTO `shopdb`.`ordertbl` (`tarikh`, `saat`, `tell`, `fname`, `priductid`) VALUES (?,?,?,?,?);");$r->bindValue(1,getCurentDate());$r->bindValue(2,1);$r->bindValue(3,$_SESSION['tell']);$r->bindValue(4,$_SESSION['fn']);$r->bindValue(5,$id);$r->execute();
}
$id=checkGetParam($_GET['id']);
$result1=$conecct->prepare("select * from product where productid=?");
$result1->bindValue(1,$id);
$result1->execute();
$row1=$result1->fetch(PDO::FETCH_ASSOC);
?>
<div id="left2">
  <table width="100%" border="1">
    <tr>
      <td width="20%">آدرس کامل</td>
      <td colspan="3"><?php echo checkparam( $row1['address']) ?></td>
      </tr>
    <tr>
      <td>زیربنا به متر مربع </td>
      <td width="30%"><?php echo  checkparam($row1['zirbana']) ?></td>
      <td width="27%">نوع معامله</td>
      <td width="23%"><?php echo  checkparam($row1['moamele']) ?></td>
    </tr>
    <tr>
      <td>تعداد اتاق خواب</td>
      <td><?php echo checkparam( $row1['otagh']) ?></td>
      <td>نوع سند</td>
      <td><?php echo checkparam( $row1['sanad']) ?></td>
    </tr>
    <tr>
      <td>سال ساخت</td>
      <td><?php echo  checkparam($row1['chandsale']) ?></td>
      <td>دانگ</td>
      <td><?php echo  checkparam($row1['dang']) ?></td>
    </tr>
    <tr>
      <td>آسانسور</td>
      <td><?php echo  checkparam($row1['asansor']) ?></td>
      <td>طبقه</td>
      <td><?php echo checkparam( $row1['tabaghe']) ?></td>
    </tr>
    <tr>
      <td>سرویس بهداشتی</td>
      <td><?php echo checkparam( $row1['dastshooi']) ?></td>
      <td>واحد</td>
      <td><?php echo checkparam( $row1['vahed']) ?></td>
    </tr>
    <tr>
      <td>پارکینگ</td>
      <td><?php echo checkparam( $row1['parking']) ?></td>
      <td>سیستم گرمایش</td>
      <td><?php echo checkparam( $row1['garmayesh']) ?></td>
    </tr>
    <tr>
      <td>بالکن</td>
      <td><?php echo checkparam( $row1['balkon']) ?></td>
      <td>کف</td>
      <td><?php echo checkparam( $row1['kaf']) ?></td>
    </tr>
    <tr>
      <td>آشپزخانه</td>
      <td><?php echo checkparam( $row1['ashpazkhane']) ?></td>
      <td>جهت ملک</td>
      <td><?php echo checkparam( $row1['jahat']) ?></td>
    </tr>
    <tr>
      <td>کابینت</td>
      <td><?php echo checkparam( $row1['kabinet']) ?></td>
      <td>دیوار ملک</td>
      <td><?php echo  checkparam($row1['divar']) ?></td>
    </tr>
    <tr>
      <td>سیستم سرمایش</td>
      <td colspan="3"><?php echo  checkparam($row1['cooler']) ?></td>
    </tr>
    <tr>
      <td>امکانات</td>
      <td colspan="3"><?php echo  checkparam($row1['abbarghgaz']) ?></td>
    </tr>
    <tr>
      <td>توضیحات</td>
      <td colspan="3"><p><?php echo  $row1['tozih'] ?></p>
        </td>
    </tr>
    <tr>
      <td>شماره تماس</td>
      <td colspan="3"><?php echo $tell; ?>
 
      <?php 
	  if (isset($_POST['sabt'])==false){
		  echo "
        <form id='form2' name='form2' method='post' action=''>
          <input type='submit' name='sabt' id='sabt' value='نمایش تلفن تماس' />
        </form>
		";
	  }		
	?>
        </td>
    </tr>
    <tr>
      <td colspan="4">    
     <div id="amazingslider-wrapper-1" style="display:block;position:relative;max-width:600px:0px auto 6px;">
        <div id="amazingslider-1" style="display:block;position:relative;margin:0 auto;">
            <ul class="amazingslider-slides" style="display:none;">
               
                <li><img  src="pic.php?id=<?php echo $id ?>  alt="images"/ >
                </li>
                <li><img src="pic2.php?id=<?php echo $id ?> alt="images"/>
                </li>
                
            </ul>
       </div>   </div>     
      </tr>
  </table>
  </div><!--Left -->
</div>
<div class="content_bottom">
</div>
</div><!--Conetnt -->
<?php
include 'footer.php';
?>   
</body>
</html>