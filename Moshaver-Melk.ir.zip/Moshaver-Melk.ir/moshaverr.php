a<?php
ob_start();
session_start();
 include 'func/connect2.php';
if (isset($_SESSION['captcha']) && isset($_POST['captcha'])) {
 if (strcmp(strtoupper($_POST['captcha']),$_SESSION['captcha']))
 {
	 	 $_SESSION['msg']="لطفا در وارد کردن تصویر امنیتی دقت نمایید";
	 header('location:moshaverregister.php');
 }
elseif ( ($_POST['cod']!="") &&  ($_POST['pass']!="") &&  ($_POST['pass2']!="")  &&  ($_POST['name']!="") &&  ($_POST['shahr']!="")  &&  ($_POST['mahale']!="")  &&  ($_POST['mantaghe']!="") &&  ($_POST['tell']!="")  &&  ($_POST['masul']!="")  &&  ($_SESSION['sabtshode']!=1)    )
{	
	$p1=$conecct->prepare("INSERT INTO `shopdb`.`moshaver` (`cod`, `name`, `masul`, `pass`, `mail`,  `mobile`,  `tell` ,`shahr`, `mahale`, `mantaghe`) VALUES (? ,?, ?, ?, ?, ?,? ,? ,?,?)");
	$p1->bindValue(1,(-1)*($_POST['cod']));	
	$p1->bindValue(2,$_POST['name']);
	$p1->bindValue(3,$_POST['masul']);
	$passn=hash_value($_POST['pass']);
	$p1->bindValue(4,$passn);
	$p1->bindValue(5,$_POST['mail']);
	$p1->bindValue(6,$_POST['mobile']);
	$p1->bindValue(7,$_POST['tell']);
	$p1->bindValue(8,$_POST['shahr']);
	$p1->bindValue(9,$_POST['mahale']);
	$p1->bindValue(10,$_POST['mantaghe']);
	$p3=$p1->execute();
if ($p3)
$_SESSION['msg']="<font color=green> ثبت نام شما با موفقیت انجام شد برای استفاده از امکانات سایت با اطلاعات خود وارد شوید</font>";
else 
$_SESSION['msg']="<font color=red> خطا در ثبت اطلاعات </font>";
	 header('location:register.php');
}
elseif ($_SESSION['sabtshode']==1)
$_SESSION['msg']="<font color=red>  لطفا در وارد کردن اطلاعات دقت نمایید </font>";
}
header('location:moshaverregister.php');
?>